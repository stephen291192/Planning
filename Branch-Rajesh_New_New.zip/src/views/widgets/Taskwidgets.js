import React from 'react'
import {
  CCard,
  CCardBody,
  CCardFooter,
  CCardTitle,
  CCol,
  CCardText,
  CRow,
  CContainer,
} from '@coreui/react'

const Widgets = () => {
  // const random = (min, max) => Math.floor(Math.random() * (max - min + 1) + min)

  return (
    <CContainer>
      <CCardBody>
        {/* <CRow>
        <CCol className="box">
          <div className="TaskGreenBox">
            <div>
              <p className="number">00</p>
              <span className="counttext">Count</span>
            </div>
            <div className="WhiteBoxGreentext">
              <p>Today Task</p>
            </div>
          </div>
        </CCol>
        <CCol className="box">
          <div className="TaskBlueBox">
            <div>
              <p className="number">00</p>
              <span className="counttext">Count</span>
            </div>
            <div className="WhiteBoxBluetext">
              <p>Pending Task</p>
            </div>
          </div>
        </CCol>
      </CRow> */}
        <CRow xs={{ cols: 3, gutter: 4 }} md={{ cols: 3 }}>
          <CCol xs>
            <CCard>
              <CCardBody className="TaskGreenBox">
                <CCardTitle className="number">00</CCardTitle>
                <CCardText className="counttext">Count</CCardText>
              </CCardBody>
              <CCardFooter className="WhiteBoxGreentext">
                <span>Today Task</span>
              </CCardFooter>
            </CCard>
          </CCol>
          <CCol xs>
            <CCard>
              <CCardBody className="TaskBlueBox">
                <CCardTitle className="number">00</CCardTitle>
                <CCardText className="counttext">Count</CCardText>
              </CCardBody>
              <CCardFooter className="WhiteBoxBluetext">
                <span>Pending Task</span>
              </CCardFooter>
            </CCard>
          </CCol>
        </CRow>
      </CCardBody>
    </CContainer>
  )
}

export default Widgets
