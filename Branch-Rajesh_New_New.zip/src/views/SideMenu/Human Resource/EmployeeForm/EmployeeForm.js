
import axios from 'axios'
import React, { useState, useContext, useEffect } from 'react'
import { toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import FilterOption from './FilterOption'
import DEFAULT_IMAGE from 'src/assets/images/picture.png'
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CForm,
  CFormCheck,
  CFormInput,
  CFormLabel,
  CFormFeedback,
  CRow,
} from '@coreui/react'
import '@coreui/coreui/dist/css/coreui.min.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'react-datepicker/dist/react-datepicker.min.css'
import Select from 'react-select'
import { GlobalContext } from 'src/context'
import { USERTOKEN } from 'src/constants/localstorage'
import validator from 'validator'
import { URL } from 'src/services/URL'
import {
  repotingtoemp,
  getBloodGroup,
  AllemployeeTable,
  LocationPincodeAPI,
  changeEmployee,
  getalldepartment,
  getalldesignation,
  addEmployee,
} from 'src/services/ApiServices'
import moment from 'moment'
import 'react-datepicker/dist/react-datepicker.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import { getValue, TYPES } from 'src/services/utility'
// import { set } from 'core-js/core/dict'
import AWS from 'aws-sdk'

function EmployeeForm() {
  const [emailError, setEmailError] = useState('')
  const [emailErrorCom, setEmailErrorCom] = useState('')
  const { state, dispatch } = useContext(GlobalContext)
  const [update, setupdate] = useState(false)
  const [newData, setNewData] = useState(true)
  const [addScreen, setAddScreen] = useState(true)
  const [sameAddress, setSameAddress] = useState(false)
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [gender, setGender] = useState('')
  const [files, setFiles] = useState('')
  const [logo, setLogo] = useState(null)
  const [fatherName, setFatherName] = useState('')
  const [EmpMobileNo, setEmpMobileNo] = useState('')
  const [EmpEmailId, setEmpEmailId] = useState('')
  const [dob, setDob] = useState('')
  const [dobError, setdobError] = useState('')
  const [filename, setFileName] = useState('')
  const [companyId, setCompanyId] = useState('')
  const [maritalStatus, setMaritalStatus] = useState('')
  const [bloodGroup, setBloodGroup] = useState('')
  const [profilePicture, setProfilePicture] = useState(null)
  const [departmentId, setDepartmentId] = useState('')
  const [designationId, setDesignationId] = useState('')
  const [reportingToId, setReportingToId] = useState('')
  const [departmentName, setDepartmentName] = useState([])
  const [userReportName, setUserReportName] = useState([])

  const [location, setLocation] = useState([])

  const [locationArea, setLocationArea] = useState([])

  // console.log("SDFFSDf",locationArea)

  const [designationName, setDesignationName] = useState([])
  const [spouceName, setSpouceName] = useState('')
  const [spouceNameId, setSpouceNameId] = useState(false)
  const [empId, setEmpId] = useState([])
  const [mobileNo, setMobileNo] = useState('')
  const [pincode, setPincode] = useState('')

  const [permanantAddress, setPermanantAddress] = useState({
    address1: '',
    address2: '',
    stateId: '',
    cityId: '',
    areaNameId: '',
    countryId: '',
    pincode: '',
    // emailId: '',
    // mobileNo: '',
    landlineNo: '',
  })
  const [communicationAddress, setCommunicationAddress] = useState({
    
    address1: '',
    address2: '',
    stateId: '',
    cityId: '',
    areaNameId: '',
    countryId: '',
    pincode: '',
    // emailId: '',
    // mobileNo: '',
    landlineNo: '',
    

  })
  const [countryName, setCountryName] = useState([])
  const [countryId, setCountryId] = useState('')
  const [stateName, setStateName] = useState([])
  const [stateId, setStateId] = useState('')
  const [cityId, setCityId] = useState(null)
  const [cityName, setCityName] = useState([])
  const [areaName, setAreaName] = useState([])
  const [areaNameId, setAreaNameId] = useState(null)
  const [bloodGroupList, setBloodGroupList] = useState([])
  const [isPermanentAddress, setIsPermanentAddress] = useState(false)
  const [dobshow, setdobshow] = useState(false)
  const [validateFirstName, setValidateFirstName] = useState('')
  const [pinCodeValue, setPinCodeValue] = useState('')

  // console.log(state, 'STATEEEEEEEEEEEEEEEEEEEEEEEEE')
  const [doj, setDoj] = useState('')

  
  const validateDob = (e) => {
    const enteredDate = moment(e.target.value, 'YYYY-MM-DD');
    const currentDate = moment();
  
    if (enteredDate.isValid()) {
      // Calculate age
      const age = currentDate.diff(enteredDate, 'years');
  
      if (age >= 18) {
        setDob(e.target.value);
      setdobError()

      } else {
        // Handle case where age is less than 18 (e.g., show an error message)
        setdobError("You must be at least 18 years old.");
        setDob('');
      }
    } else {
      // Handle invalid date (e.g., show an error message)
      setdobError()

      setDob(e.target.value);
    }
  }

  useEffect(() => {
    showDepartment()
    // selectCountry()
    getAllBloodGroup()
    showReportingName(state.companyId)
    // UploadImage()
  }, [])

  const clearFun = () => {
    setFirstName('')
    setLastName('')
    setGender('')
    setFatherName('')
    setEmpMobileNo('')
    setEmpEmailId('')
    setDob('')
    setDoj('')
    setMaritalStatus('')
    setBloodGroup('')
    setProfilePicture('')
    setDepartmentId('')
    setEmpId('')
    setDesignationId('')
    setReportingToId('')
    setSpouceName('')
    setMobileNo('')
    setPincode('')
    setPermanantAddress('')
    setLocation([])
    setLocationArea([])
    setupdate(false)
    setIsPermanentAddress(false)
    setPictureDelete(false);
    setCommunicationAddress('')
    setPinCodeValue('')
    setSpouceName('')
    setPinCodeValue('')
    setEmpMobileNo('')
    setEmpEmailId('')
    setPicture()
  }

  const validateEmail = (e) => {
    var email = e.target.value
    if (validator.isEmail(email)) {
      setEmailError()
    } else {
      setEmailError('Invalid Email!')
    }
  }

  const validateEmailCom = (e) => {
    var email = e.target.value
    if (validator.isEmail(email)) {
      setEmailErrorCom()
    } else {
      setEmailErrorCom('Invalid Email!')
    }
  }

  const handleNumChange = (e) => {
    const limit = 10
    const data = setEmpMobileNo(e.target.value.slice(0, limit))
  }

  const validatePhoneNo = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 10) {
      setMobileNo('PhoneNo should be 10 digits')
    } else {
      setMobileNo()
    }
  }

  const handleNumChanges = (event) => {
    const limit = 11
    setPermanantAddress({
      ...permanantAddress,
      landlineNo: event.target.value.slice(0, limit),
    })
  }

  const handlePinCode = (event) => {
    const limit = 6
    setPermanantAddress({
      ...permanantAddress,
      pincode: event.target.value.slice(0, limit),
    })
  }

  const validatePincode = (e) => {
    const data = e.target.value

    if (data.length < 6) {
      setPincode('Pincode should be 6 digits')
      setLocationArea([])
      setLocation([])
      setAreaNameId(null)
    } else {
      setPincode()
      AllLocationFun(data)
    }
  }

  const today = moment()
  const disableFutureDt = (current) => {
    return current.isBefore(today)
  }

  const keyenter = (e) => {
    setDob('')
  }

  // console.log("Loction",location.countryName)

  const AllLocationFun = async (postData) => {
    setLocationArea([])
    // setLocation({});

    const body = {
      postalId: postData,
    }

    var response
    try {
      response = await LocationPincodeAPI(body)

      if (response) {
        if (response.status === 'SUCCESS') {
          // console.log("countryNamecountryName", response.value.countryName);

          const data = response.value
          const dataArea = response.value.areaDetailsList.map((area) => ({
            label: area,
            value: area,
          }))

          // const data = response.value.map((x, i) => {
          //   return {
          //     SNo: x,
          //     countryName: x.countryName,
          //     provincesName: x.provincesName,
          //     regionName: x.regionName,
          //     cityName: x.cityName,
          //   };
          // });
          setLocationArea(dataArea)
          setLocation(data)

          // console.log('Processed Data Value', data)
        } else {
          toast.error('No Data Found')
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success === false) {
          // toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        // toast.error('Something Went Wrong' + err)
      }
    }
  }

  const selectCountry = async () => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      axios
        .get(`${URL}/countries`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        })
        .then((response) => {
          if (response) {
            const data = response.data.countries.map((x) => {
              return {
                value: x._id,
                label: x.countryName,
              }
            })
            setCountryName(data)
          }
        })
    } catch (e) {
      console.log(e)
    }
  }

  const selectState = async (id) => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      axios
        .get(`${URL}/states/${id}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        })
        .then((response) => {
          if (response) {
            const data = response.data.states.map((x) => {
              return {
                value: x._id,
                label: x.stateName,
              }
            })
            setStateName(data)
          }
        })
    } catch (e) {
      console.log(e)
    }
  }

  const selectCity = async (countryId, stateId) => {
    const token = await localStorage.getItem('USERTOKEN')

    try {
      axios
        .get(`${URL}/cities/${countryId}/${stateId}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        })
        .then((response) => {
          if (response) {
            const data = response.data.cities.map((x) => {
              return {
                value: x._id,
                label: x.cityName,
              }
            })
            setCityName(data)
          }
        })
    } catch (e) {
      console.log(e)
    }
  }

  const selectArea = async (cityId, stateId) => {
    const token = await localStorage.getItem('USERTOKEN')
    // console.log(cityId, stateId, 'SJSPJO')

    try {
      axios
        .get(`${URL}/areas/${countryId?.value}/${stateId?.value}/${cityId}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        })
        .then((response) => {
          if (response) {
            const value = response.data.areas.map((x) => {
              return {
                label: x.areaName,
                value: x._id,
              }
            })
            setAreaName(value)
          }
        })
    } catch (e) {
      console.log(e)
    }
  }

  // const validateDepartmentAbbriName = (e) => {
  //   const phone = e.target.value.trim()
  //   if (phone.length < 3) {
  //     setDepartNameAbbriError('Department Abbreviation should be 3 letters')
  //   } else {
  //     setDepartNameAbbriError()
  //   }
  // }

  // Show department data GET API method

  const showDepartment = async () => {
    setDesignationId(null)
    var response
    try {
      response = await getalldepartment()
      if (response) {
        // console.log("SDFSDFSDFsdf",response.data)
        if (response) {
          const data = response.data.map((x) => {
            return {
              value: x._id,
              label: x?.departmentName,
            }
          })
          setDepartmentName(data)
        } else {
          // setParentDepartment([])
        }
      }
    } catch (e) {
      console.log(e)
    }
  }

  const showDesignation = async (departmentId) => {
    // console.log("sdfsdfsdf",departmentId)
    let companyId = state.companyId
    var response
    setDesignationId(null)
    setDesignationName([])
    try {
      response = await getalldesignation(companyId, departmentId)

      // console.log(response, 'bdddddddddddd')
      if (response) {
        if (response.data) {
          const data = response.data.map((x) => {
            return {
              value: x._id,
              label: x.designationName,
            }
          })
          setDesignationName(data)
          // console.log(data, 'daaaadddaaaa')
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }
  const getAllBloodGroup = async () => {
    try {
      const response = await getBloodGroup()

      // console.log('BLOODG', response)

      if (response.success) {
        const dropDownData = getValue(response.data, TYPES.ARRAY, []).map((bloodgroup) => {
          return {
            label: getValue(bloodgroup.bloodGroup, TYPES.STRING, ''),
            value: bloodgroup._id,
          }
        })
        setBloodGroupList(dropDownData)
      } else {
        setBloodGroupList([])
      }
    } catch (err) {
      console.error(err)
    }
  }

  const showDesignationold = async (departmentId) => {
    const token = await localStorage.getItem('USERTOKEN')
    setDesignationId(null)
    setDesignationName([])
    try {
      await axios({
        method: 'Get',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },

        // url: `${URL}/designations/${state.companyId}/${departmentId}`,
        url: `${URL}/designation/${state.companyId}/${departmentId}`,
      }).then((response) => {
        if (response) {
          // console.log('dsfsdfsdfsdf', response)
          if (response.data.success) {
            // toast.success(response?.data.message)
            const data = response.data.data.map((x) => {
              return {
                value: x._id,
                label: x.designationName,
              }
            })
            setDesignationName(data)
            // console.log('llllllll', data)
          } else {
            toast.error(response?.data.error)
          }
        }
      })
    } catch (e) {
      console.log(e)
    }
  }
  // repotingtoemp

  const showReportingName = async () => {
    var response
    try {
      response = await AllemployeeTable(state.companyId)
      if (response) {
        if (response.success) {
          if (response.employees) {
            // console.log('updatedata', response.employees)
            const data = response.employees.map((x) => {
              return {
                value: x._id,
                label: `${x?.firstName} ${x?.lastName}`,
              }
            })
            setUserReportName(data)
          }
          // toast.success(response.message)
        } else {
          // toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success === false) {
          // toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  // const showReportingName = async (departmentId, designationId) => {
  //   var response
  //   setUserReportName([])
  //   try {
  //     response = await repotingtoemp(departmentId, designationId)
  //     if (response) {
  //       const data = response.data.map((x) => {
  //         return {
  //           value: x._id,
  //           label: `${x?.firstName} ${x?.lastName}`,
  //         }
  //       })
  //       setUserReportName(data)
  //       console.log('ZZZZ', data)
  //     }
  //   } catch (e) {
  //     console.log(e)
  //   }
  // }
  //   const token = await localStorage.getItem('USERTOKEN')
  //   setUserReportName()
  //   try {
  //     axios
  //       .get(`${URL}/users/get/${departmentId.value}/${designationId}`, {
  //         headers: {
  //           'Content-Type': 'application/json',
  //           Authorization: token,
  //         },
  //       })
  //       .then((response) => {
  //         if (response) {
  //           console.log('AAAA', response.data)
  //           const data = response.data.data.map((x, i) => {
  //             return {
  //               value: x._id,

  //               label: `${x.firstName} ${x.lastName}`,
  //             }
  //           })
  //           setUserReportName(data)
  //         }
  //       })
  //   } catch (e) {
  //     console.log(e)
  //   }
  // }

  // ................photo...................

  const handleSave = async (file) => {
    console.log(file, 'PROFILE')
    if (file === undefined) {
      let e = 'cancelled'
      return console.log(e)
    }
    if (file.size > 1048576) {
      return toast.warning('Please choose below 1 MB file')
    } else if (
      file.type === 'image/png' ||
      file.type === 'image/jpeg' ||
      file.type === 'image/jpg'
    ) {
      setProfilePicture(file)
    } else {
      return toast.warning('File type should be .jpeg, .png, .jpg')
    }
  }

  const handleClick = (e) => {
    e.preventDefault()
    document.getElementById('profileImage').click()
  }

  // ..............END .......................

  const handleAdd = (e) => {
    setNewData(!newData)
  }

  // data 01
  const updateEmployee = (data) => {
    try {
      console.log(data, 'UPDATE DATA')
      // AllLocationFun()
      setAddScreen(!addScreen)
      if (data.maritalStatus === 'Married') {
        setSpouceNameId(true)
        setSpouceName(data.spouceName)
      } else {
        setSpouceNameId(false)
        setSpouceName(data.spouceName)
      }
      setPictureDelete(true);
      setPicture(data.profilePicture)
      setupdate(true)
      setFirstName(data.firstName)
      setLastName(data.lastName)
      setMaritalStatus(data.maritalStatus)
      setGender(data.gender)
      setFatherName(data.fatherName)
      setDob(data.dob)
      setEmpEmailId(data.emailId)
      setEmpMobileNo(data.mobileNo)
      setDoj(moment(data.doj).format('YYYY-MM-DD'))
      setCompanyId(data.companyId)

      setDepartmentId({
        value: data.departmentId._id,
        label: data.departmentId.departmentName,
      })
      setDesignationId({
        value: data.designationId._id,
        label: data.designationId.designationName,
      })
     
      // setAreaNameId({
      //   label: data?.permanantAddress?.area,
      //   value: data?.permanantAddress?.area,
      // })

      if (data.reportingToId === undefined) {
        setReportingToId('')
      } else {
        // alert()
        setReportingToId({ value: data.reportingToId })
      }
      setPinCodeValue(data.permanantAddress.pincode)
      const event = {
        target: {
          value: data.permanantAddress.pincode,
        },
      }

      setLocation({
        ...data?.permanantAddress,
      })

      // setLocationArea({
      //   ...data?.permanantAddress,
      // })

      setIsPermanentAddress(data.sameAddress)
      setMaritalStatus(data.maritalStatus)
      if (typeof data.profilePicture === 'object' && data.profilePicture === null) {
        setProfilePicture(null)
      } else {
        setProfilePicture(data.profilePicture)
      }
      setEmpId({ value: data.employeeId })
         validatePincode(event)
      handlePinCode(event)
      if (data.sameAddress) {
        setCommunicationAddress({
          ...data?.communicationAddress,
          ...{

            area: {
              label: data?.permanantAddress?.area,
              value: data?.permanantAddress?.area,
            },
            city: {
              label: data?.permanantAddress?.city,
              value: data?.permanantAddress?.city,
            },
            country: {
              label: data?.permanantAddress?.country,
              value: data?.permanantAddress?.country,
            },
            state: {
              label: data?.permanantAddress?.state,
              value: data?.permanantAddress?.state,
            },
          },
        })
        setPermanantAddress({
          ...data?.permanantAddress,
          address1 : data.permanantAddress?.address1,
          
          ...{
            area: {
              label: data?.permanantAddress?.area,
              value: data?.permanantAddress?.area,
            },
            city: {
              label: data?.permanantAddress?.city,
              value: data?.permanantAddress?.city,
            },
            country: {
              label: data?.permanantAddress?.country,
              value: data?.permanantAddress?.country,
            },
            state: {
              label: data?.permanantAddress?.state,
              value: data?.permanantAddress?.state,
            },
          },
        })

        setAreaNameId({
          label: data?.permanantAddress?.area,
          value: data?.permanantAddress?.area,
        })
        
      } else {
        setPermanantAddress({
          ...data?.permanantAddress,
          address1 : data.permanantAddress?.address1,
          ...{
            area: {
              label: data?.permanantAddress?.area,
              value: data?.permanantAddress?.area,
            },
            city: {
              label: data?.permanantAddress?.city,
              value: data?.permanantAddress?.city,
            },
            country: {
              label: data?.permanantAddress?.country,
              value: data?.permanantAddress?.country,
            },
            state: {
              label: data?.permanantAddress?.state,
              value: data?.permanantAddress?.state,
            },
          },
        })
      }       setAreaNameId({
        label: data?.permanantAddress?.area,
        value: data?.permanantAddress?.area,
      })
   
      setBloodGroup(data.bloodGroup._id)
    } catch (err) {
      console.error(err)
    }
  }

  // profile Picture

  // const UploadImage = () => {

  const [selectedFile, setSelectedFile] = useState(null)
  const [picture, setPicture] = useState()
  const [pictureShow, setPictureShow] = useState(true)
  const [pictureDelete, setPictureDelete] = useState(false)
  const handleFileInput = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
    setPictureShow(false);    

    // Delete the old file if a new one is selected
    if (picture) {
      deleteFileFromS3a(picture);
    }

    if (file) {
      uploadFile(file);
    }
  };

  const uploadFile = async (file) => {
    const config = {
      accessKeyId: 'AKIAX2Q7RHVTQQS5EC5T', // Replace with your AWS access key
      secretAccessKey: '0YgHSLT6MIz1tYtPdK8bhAJDRKvDhYlEtW0f1Z80', // Replace with your AWS secret access key
      region: 'ap-south-1', // Replace with your S3 region
    };

    AWS.config.update(config);
    const s3 = new AWS.S3();

    const params = {
      Bucket: 'katbookv2.0',
      Key: file.name,
      Body: file,
      ContentType: file.type, // Use the file's actual content type
    };

    try {
      const response = await s3.upload(params).promise();
      console.log('File uploaded successfully:', response);
      setPicture(response.Location);
    } catch (error) {
      console.error('Error uploading file to S3:', error);
    }
  }

  const deleteFileFromS3a = async (fileUrl) => {
    const config = {
      accessKeyId: 'AKIAX2Q7RHVTQQS5EC5T', // Replace with your AWS access key
      secretAccessKey: '0YgHSLT6MIz1tYtPdK8bhAJDRKvDhYlEtW0f1Z80', // Replace with your AWS secret access key
      region: 'ap-south-1', // Replace with your S3 region
    };

    AWS.config.update(config);
    const s3 = new AWS.S3();

    const urlParts = fileUrl.split('/');
    const fileName = urlParts[urlParts.length - 1];

    const params = {
      Bucket: 'katbookv2.0',
      Key: fileName,
    };

    try {
      await s3.deleteObject(params).promise();
      console.log('File deleted from S3:', fileName);
    } catch (error) {
      console.error('Error deleting file from S3:', error);
    }
  };


  const deleteFileFromS3 = async (fileKey) => {
    const config = {
      accessKeyId: 'AKIAX2Q7RHVTQQS5EC5T', // Replace with your AWS access key
      secretAccessKey: '0YgHSLT6MIz1tYtPdK8bhAJDRKvDhYlEtW0f1Z80', // Replace with your AWS secret access key
      region: 'ap-south-1', // Replace with your AWS region
    }

    AWS.config.update(config)

    const s3 = new AWS.S3()

    const params = {
      Bucket: 'katbookv2.0', // Replace with your S3 bucket name
      Key: fileKey, // The key (filename) of the file you want to delete
    }

    try {
      await s3.deleteObject(params).promise()
      setPictureShow(true)
      setPictureDelete(false)
      setPicture(null)
      console.log(`File ${fileKey} deleted successfully.`)
    } catch (error) {
      console.error(`Error deleting file ${fileKey}:`, error)
    }
  }

  // }

  // END

  const saveEmployee = async () => {

    const body = {
      firstName,
      lastName,
      gender,
      fatherName,
      dob,
      doj,
      profilePicture: picture,
      companyId: state.companyId,
      departmentId: departmentId.value,
      designationId: designationId?.value,
      reportingTo: reportingToId?.value ? reportingToId?.value : null,
      maritalStatus,
      bloodGroup,
      spouceName,
      mobileNo: EmpMobileNo,
      emailId: EmpEmailId,
      permanantAddress: {
        ...permanantAddress,
        area: areaNameId?.value,
        city: location.cityName,
        country: location.countryName,
        state: location.regionName,
      },

      sameAddress: String(isPermanentAddress),

      communicationAddress: isPermanentAddress
        ? {
            ...permanantAddress,
            area: areaNameId?.value,
            city: location.cityName,
            country: location.countryName,
            state: location.regionName,
          }
        : {
            ...communicationAddress,
            area: communicationAddress?.areaNameId?.value,
            city: communicationAddress?.cityId?.value,
            country: communicationAddress?.countryId?.value,
            state: communicationAddress?.stateId?.value,
          },
    }
    console.log('EmployeeSaveData', body)
    try {
      const response = await addEmployee(body)

      if (response && response.success === true) {
        toast.success(response.message)
        setFirstName('')
        setLastName('')
        setGender('')
        setFatherName('')
        setDob('')
        setDoj('')
        setCompanyId('')
        setDepartmentId('')
        setDesignationId('')
        setMaritalStatus('')
        setBloodGroup('')
        setProfilePicture('')
        setSpouceName('')
        setPermanantAddress('')
        setEmpId('')
        setEmpEmailId('')
        setEmpMobileNo('')
        setReportingToId('')
        setPicture(null)
        setPictureShow(true)
        setSelectedFile(null)
        setAddScreen(!addScreen)
        setNewData(!newData)
        setLocationArea([])
        setLocation([])
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const updateEmployees = async (employeeId) => {

    const body = {
      firstName,
      lastName,
      gender,
      fatherName,
      dob,
      doj,
      reportingTo: reportingToId?.value ? reportingToId?.value : null,
      companyId: state.companyId,
      departmentId: departmentId?.value,
      designationId: designationId?.value,
      maritalStatus,
      bloodGroup,
      profilePicture,
      spouceName,
     
      mobileNo: EmpMobileNo,
      emailId: EmpEmailId,

      permanantAddress: {
        ...permanantAddress,
        area: permanantAddress?.areaNameId?.value,
        city: permanantAddress?.cityId?.value,
        country: permanantAddress?.countryId?.value,
        state: permanantAddress?.stateId?.value,
      },

      sameAddress: String(isPermanentAddress),

      communicationAddress: isPermanentAddress
        ? {
            ...permanantAddress,
            area: permanantAddress?.areaNameId?.value,
            city: permanantAddress?.cityId?.value,
            country: permanantAddress?.countryId?.value,
            state: permanantAddress?.stateId?.value,
          }
        : {
            ...communicationAddress,
            area: communicationAddress?.areaNameId?.value,
            city: communicationAddress?.cityId?.value,
            country: communicationAddress?.countryId?.value,
            state: communicationAddress?.stateId?.value,
          },
      // empId: empId.value,
    }

    // console.log(body, 'WWWWWWWWWWWWWWWWWWWWWW')
    let fData = new FormData()
    fData.append('profile', profilePicture)
    fData.append('json', JSON.stringify(body))
    try {
      // console.log(fData, 'WWWWWWWWWWWWWWWWWWWWWW')

      const response = await changeEmployee(body, employeeId)
      if (response && response.success === true) {
        toast.success(response.message)
        // AllLocationFun()
        setFirstName('')
        setLastName('')
        setGender('')
        setFatherName('')
        setDob('')
        setDoj('')
        setCompanyId('')
        setDepartmentId('')
        setDesignationId('')
        setMaritalStatus('')
        setBloodGroup('')
        setProfilePicture('')
        setSpouceName('')
        setPermanantAddress('')
        setEmpId('')
        setEmpEmailId('')
        setEmpMobileNo('')
        setReportingToId('')
        setAddScreen(!addScreen)
        handleFileInput()
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success === false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const clickdoboptions = (e) => {
    const TodayDate = moment().format('YYYY-MM-DD')
    const EnterDate = moment(e.target.value).format('YYYY-MM-DD')

    if (EnterDate > TodayDate) {
      // console.log('exceed', 'DOBBBBBBBBBBBB')
      setDob('')
    } else {
      // console.log('OK', 'DOBBBBBBBBBBBB')
      setDob(e.target.value)
    }
  }

  const clickdojoptions = (e) => {
    const TodayDate = moment().format('YYYY-MM-DD')

    const EnterDate = moment(e.target.value).format('YYYY-MM-DD')

    if (EnterDate > TodayDate) {
      // console.log('exceed', 'DOBBBBBBBBBBBB')
      setDoj('')
    } else {
      // console.log('OK', 'DOBBBBBBBBBBBB')
      setDoj(e.target.value)
    }
  }

  let Success = (value) => toast.success(value)
  let Error = (value) => toast.error(value)

  return (
    <React.Fragment>
      {/* <ToastContainer /> */}
      {addScreen ? (
        <>
          <div className="d-flex align-items-center justify-content-between">
            <div className="font_Title pt-2 pb-0 pr-2">List of Employee</div>
            <div>
              <button
                className="loginBtn mright loginBtn_New"
                onClick={() => {
                  setAddScreen(!addScreen)
                  setPicture(null)
                  clearFun()
                }}
              >
                Add New
              </button>
            </div>
          </div>

          <CRow>
            <CCol xs={12} className="p-0">
              <FilterOption updateEmployee={updateEmployee} employeeId />
            </CCol>
          </CRow>
        </>
      ) : (
        <CForm className="">
          <CRow>
            <CCol xs={12}>
              <span className="employeeHeader">
                {/* <h3 className="font_Title">CREATE NEW EMPLOYEE</h3> */}
                {update ? (
                  <h3 className="font_Title pt-2 pb-0 pr-2">Update employee</h3>
                ) : (
                  <h3 className="font_Title pt-2 pb-0 pr-2">Add employee</h3>
                )}
              </span>
              {/* <h3 className="font-size">Employee Details</h3> */}
              <CCard className="mb-6">
                {/* <CCardHeader>
                  <h3 className="font-size">Employee Details</h3>
                </CCardHeader> */}
                <h3 className="font-size m-2">Employee Details</h3>
                <CCardBody>
                  <div className="d-flex justify-content-around">
                    {/* <CCol sm={1}></CCol> */}
                    <CCol className="leftCols">
                      {/* <Department /> */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                First Name <code>*</code>
                              </CFormLabel>
                              <CFormInput
                                type="text"
                                id=""
                                autoFocus
                                value={firstName}
                                onChange={(e) => {
                                  setFirstName(e.target.value)
                                }}
                                name="firstName"
                                placeholder="First name"
                                className="inputfieldgo"
                                autoComplete="off" 
                              />
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Last Name <code>*</code>
                              </CFormLabel>
                              <CFormInput
                                type="text"
                                id="LastName"
                                onChange={(e) => setLastName(e.target.value)}
                                name="lastName"
                                placeholder="Last Name"
                                disabled={!firstName}
                                value={lastName}
                                className="inputfieldgo"
                                autoComplete="off" 
                              />
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Gender <code>*</code>
                              </CFormLabel>

                              <div style={{ display: 'flex', alignItems: 'center' }}>
                                <CFormCheck
                                  inline
                                  type="radio"
                                  id="GendervalidationFormCheck1"
                                  name="gender"
                                  className="inputfieldgen"
                                  label="Male"
                                  checked={gender === 'Male'}
                                  onChange={(e) => {
                                    setGender('Male')
                                  }}
                                  disabled={!firstName || !lastName}
                                  value={gender}
                                  // checked={user.gender === 'Male'}
                                />

                                <CFormCheck
                                  inline
                                  type="radio"
                                  name="gender"
                                  className="inputfieldgen"
                                  id="GendervalidationFormCheck2"
                                  checked={gender === 'Female'}
                                  onChange={(e) => {
                                    setGender('Female')
                                  }}
                                  label="Female"
                                  // checked={user.gender === 'Female'}/
                                  disabled={!firstName || !lastName}
                                  value={gender}
                                />
                                <CFormCheck
                                  inline
                                  type="radio"
                                  name="gender"
                                  className="inputfieldgen"
                                  id="GendervalidationFormCheck3"
                                  checked={gender === 'Transgender'}
                                  onChange={(e) => {
                                    setGender('Transgender')
                                  }}
                                  label=" Transgender"
                                  disabled={!firstName || !lastName}
                                  value={gender}
                                />
                              </div>
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Father Name <code>*</code>
                              </CFormLabel>
                              <CFormInput
                                className="inputfieldgo"
                                type="text"
                                name="fatherName"
                                placeholder="Father Name"
                                value={fatherName}
                                onChange={(e) => {
                                  setFatherName(e.target.value)
                                }}
                                disabled={!firstName || !lastName || !gender}
                                autoComplete="off" 
                              />
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Date of Birth <code>*</code>
                              </CFormLabel>
                              <CFormInput
                                type="date"
                                onChange={(e) => {
                                  clickdoboptions(e)
                                  validateDob(e)
                                }}
                                placeholder="dd/mm/yyyy"
                                max={moment().format('YYYY-MM-DD')}
                                value={dob}
                                id="inp"
                                disabled={!firstName || !lastName || !gender || !fatherName}
                                className="readonly inputfieldgo"
                              />
                              <span
                            style={{
                              fontWeight: '500',
                              fontSize: '12px',
                              color: 'red',
                            }}
                          >
                            {dobError}
                          </span>

                              {/* <DatePicker
                                selected={dob !== '' ? moment(dob).format('DD-MM-YYYY') : dob}
                                onChange={(e) => {
                                  console.log(e)
                                  // clickdoboptions(e)
                                }}
                                name="startDate"
                                minDate="08-1-1980"
                                maxDate={new Date()}
                                dateFormat="dd-MM-yyyy"
                                placeholder="DD-MM-YYYY"
                              /> */}
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Mobile No <code>*</code>
                              </CFormLabel>
                              <CFormInput
                                type="number"
                                className="inputfieldgo"
                                isDisabled={!firstName || !lastName || !gender || !fatherName}
                                id="MobileNo"
                                value={EmpMobileNo}
                                onChange={(e) => {
                                  validatePhoneNo(e)
                                  handleNumChange(e)
                                }}
                                placeholder="Mobile No"
                              />
                              <span
                                style={{
                                  fontWeight: '500',
                                  fontSize: '12px',
                                  color: 'red',
                                }}
                              >
                                {mobileNo}
                              </span>
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Email ID <code>*</code>
                              </CFormLabel>
                              <CFormInput
                                type="email"
                                className="inputfieldgo"
                                isDisabled={
                                  !firstName || !lastName || !gender || !fatherName || !EmpMobileNo
                                }
                                id="Email Id"
                                placeholder="Email Id"
                                onChange={(e) => {
                                  validateEmail(e)
                                  setEmpEmailId(e.target.value)
                                }}
                                value={EmpEmailId}
                                autoComplete="off" 
                                // onChange={checkisEmail}
                              />
                              <span
                                style={{
                                  fontWeight: '500',
                                  fontSize: '12px',
                                  color: 'red',
                                }}
                              >
                                {emailError}
                              </span>
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Marital Status <code>*</code>
                              </CFormLabel>
                              <div style={{ display: 'flex', alignItems: 'center' }}>
                                <CFormCheck
                                  inline
                                  id="validationFormCheck1"
                                  type="radio"
                                  className="inputfieldgen"
                                  name="maritalStatus"
                                  checked={maritalStatus === 'Married'}
                                  onChange={(e) => {
                                    setMaritalStatus('Married')
                                  }}
                                  onClick={() => setSpouceNameId(true)}
                                  label="Married"
                                  value={maritalStatus}
                                  disabled={!firstName || !lastName || !gender || !fatherName}
                                />

                                <CFormCheck
                                  inline
                                  type="radio"
                                  id="validationFormCheck2"
                                  checked={maritalStatus === 'UnMarried'}
                                  className="inputfieldgen"
                                  onChange={(e) => {
                                    setMaritalStatus('UnMarried')
                                  }}
                                  onClick={() => setSpouceNameId(false)}
                                  label="UnMarried"
                                  name="maritalStatus"
                                  value={maritalStatus}
                                  disabled={!firstName || !lastName || !gender || !fatherName}
                                />
                                <CFormCheck
                                  inline
                                  type="radio"
                                  id="validationFormCheck3"
                                  className="inputfieldgen"
                                  checked={maritalStatus === 'Widow'}
                                  onChange={(e) => {
                                    setMaritalStatus('Widow')
                                  }}
                                  onClick={() => setSpouceNameId(false)}
                                  label=" Widow / Divorce"
                                  name="maritalStatus"
                                  value={maritalStatus}
                                  disabled={!firstName || !lastName || !gender || !fatherName}
                                />
                              </div>
                            </CCol>
                            {spouceNameId && (
                              <CRow className="mt-3">
                                <CCol sm={9}>
                                  <CFormLabel className="col-form-label donlabel">
                                    Spouse Name <code>*</code>
                                  </CFormLabel>
                                  <CFormInput
                                    className="inputfieldgo"
                                    type="text"
                                    name="Spouse Name"
                                    value={spouceName}
                                    onChange={(e) => setSpouceName(e.target.value)}
                                    placeholder="Spouce name"
                                  />
                                </CCol>
                              </CRow>
                            )}
                          </CRow>
                        </div>
                      </div>
                    </CCol>

                    <CCol className="leftCols">
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '15px',
                          // paddingRight: '35px',
                        }}
                      >
                        <div>
                          <CRow className="mb-1" style={{ alignItems: 'end' }}>
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Profile picture <code>*</code>
                              </CFormLabel>
                              <div
                                id={'addEmployeehandleClick'}
                                style={{
                                  height: '120px',
                                  width: '120px',
                                  cursor: 'pointer',
                                  border: '1px dashed black',
                                }}
                              >
                                <img
                                  alt=""
                                  src={
                                    typeof picture === 'string'
                                      ? picture !== ''
                                        ? picture
                                        : DEFAULT_IMAGE
                                      : typeof picture === 'object'
                                      ? picture !== null
                                        ? window.URL.createObjectURL(picture)
                                        : DEFAULT_IMAGE
                                      : DEFAULT_IMAGE
                                  }
                                  style={{
                                    width: '100%',
                                    height: '100%',
                                    position: 'acsolute',
                                  }}
                                />
                              </div>
                              {/* <input
                                className="py-2"
                                type={'file'}
                                value={''}
                                id="pid"
                                onChange={(e) => {
                                  handleSave(e.target.files[0])
                                }}
                              /> */}
                              {/* <div className="py-2">
                                <input
                                  type="file"
                                  id="profileImage"
                                  className="d-none"
                                  onChange={(e) => handleSave(e.target.files[0])}
                                />
                                <button
                                  onClick={handleClick}
                                  className="mt-1 px-2 py-1 border "
                                  htmlFor="files"
                                >
                                  Choose file
                                </button>
                              </div> */}
                              <div className="d-flex gap-2">
                                <div>
                                    <input type="file" onChange={handleFileInput} />
                                </div>
                                <div>
                                  {pictureDelete && (
                                    <button
                                      onClick={(e) => {deleteFileFromS3(selectedFile.name); e.preventDefault()}}
                                      className="border-1 mt-2 rounded"
                                    >
                                      Delete File
                                    </button>
                                  )}
                                </div>
                              </div>
                            </CCol>

                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Date of joining <code>*</code>
                              </CFormLabel>
                              <CFormInput
                                type="date"
                                onChange={(e) => {
                                  clickdojoptions(e)
                                }}
                                placeholder="dd/mm/yyyy"
                                max={moment().format('YYYY-MM-DD')}
                                value={doj}
                                id="inp"
                                disabled={
                                  !firstName ||
                                  !lastName ||
                                  !gender ||
                                  !fatherName ||
                                  !maritalStatus
                                }
                                className="readonly inputfieldgo"
                              />
                              {/* <DatePicker
                                className="form-control inputfieldgo dobpicker"
                                // readOnly={true}
                                selected={doj}
                                onChange={(e) => {
                                  clickdojoptions(e)
                                }}
                                name="startDate"
                                minDate="08-1-1980"
                                maxDate={new Date()}
                                dateFormat="dd-MM-yyyy"
                                placeholder="DD-MM-YYYY"
                              /> */}
                              <CFormFeedback invalid>Choose Date</CFormFeedback>
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Department <code>*</code>
                              </CFormLabel>
                              <Select
                                options={departmentName}
                                className="inputfieldso"
                                value={departmentId}
                                isDisabled={
                                  !firstName ||
                                  !lastName ||
                                  !gender ||
                                  !fatherName ||
                                  !doj ||
                                  !maritalStatus ||
                                  emailError ||
                                  !EmpEmailId ||
                                  !EmpMobileNo ||
                                  mobileNo
                                }
                                onChange={(e) => {
                                  setDepartmentId(e)
                                  showDesignation(e.value)
                                  setDesignationId([])
                                  setReportingToId([])
                                }}
                                placeholder="Department"
                              />
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Designation <code>*</code>
                              </CFormLabel>
                              <Select
                                options={designationName}
                                value={designationId}
                                isDisabled={
                                  !firstName ||
                                  !lastName ||
                                  !gender ||
                                  !fatherName ||
                                  !departmentId ||
                                  !maritalStatus
                                }
                                className="inputfieldso"
                                onChange={(e) => {
                                  showReportingName(departmentId.value, e.value)
                                  setDesignationId(e)
                                  setReportingToId([])
                                }}
                                placeholder="Designation"
                              />
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Blood Group <code>*</code>
                              </CFormLabel>
                              {/* bloodGroupList */}
                              <Select
                                // options={bloodGroups.map((group) => ({
                                //   label: group.bloodGroup,
                                //   value: group.bloodGroup,
                                // }))}
                                options={bloodGroupList}
                                value={
                                  bloodGroupList.filter((bg) => bg.value === bloodGroup).length > 0
                                    ? bloodGroupList.find((bg) => bg.value === bloodGroup)
                                    : null
                                }
                                className="inputfieldso"
                                onChange={(e) => setBloodGroup(e.value)}
                                isDisabled={
                                  !firstName ||
                                  !lastName ||
                                  !gender ||
                                  !fatherName ||
                                  !departmentId ||
                                  !maritalStatus ||
                                  !designationId
                                }
                              />

                              {/* <CFormInput
                                type="Blood Group"
                                id="BloodGroup"
                                value={bloodGroup}
                                onChange={(e) => {
                                  setBloodGroup(e.target.value)
                                }}
                                placeholder="Blood Group"
                                className="inputfieldgo"
                                name="bloodGroup"
                                disabled={
                                 
                                }
                              /> */}
                              <CFormFeedback invalid>Please enter a blood group</CFormFeedback>
                            </CCol>
                          </CRow>
                        </div>

                        <div>
                          <CRow className="mb-1">
                            <CCol sm={9}>
                              <CFormLabel className="col-form-label donlabel">
                                Reporting To
                              </CFormLabel>
                              <Select
                                // options={ReportingTo.map((group) => ({
                                //   label: group.Reporting,
                                //   value: group.Reporting,

                                // }))}
                                options={userReportName}
                                // value={reportingToId}
                                value={
                                  update
                                    ? reportingToId === null || reportingToId === ''
                                      ? ''
                                      : userReportName?.find((j) => j.value === reportingToId.value)
                                    : reportingToId
                                }
                                isClearable
                                className="inputfieldso"
                                onChange={(e) => {
                                  console.log(e, 'UPDATE DATA')
                                  setReportingToId(e)
                                }}
                                isDisabled={
                                  !firstName ||
                                  !lastName ||
                                  !gender ||
                                  !fatherName ||
                                  !departmentId ||
                                  !maritalStatus ||
                                  !designationId ||
                                  !bloodGroup
                                }
                              />
                            </CCol>
                          </CRow>
                        </div>
                      </div>
                    </CCol>
                    {/* <CCol md={1}></CCol> */}
                  </div>
                </CCardBody>
                <CCardHeader className="Address">
                  <h3 className="font-size">Address Details</h3>
                </CCardHeader>
                <CCardBody>
                  <div className="d-flex justify-content-around">
                    <CCol className="leftCols">
                      <CForm>
                        <p className="text-medium-emphasis small">Permanant Address</p>
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">
                              Address 1<code>*</code>
                            </CFormLabel>
                            <CFormInput
                              type="text"
                              className="inputfieldgo"
                              id="Address1"
                              placeholder="Address 1"
                              value={permanantAddress?.address1}
                              // disabled={
                              //   !firstName ||
                              //   !lastName ||
                              //   !gender ||
                              //   !fatherName ||
                              //   !departmentId ||
                              //   !maritalStatus ||
                              //   !designationId ||
                              //   !bloodGroup ||
                              //   !reportingToId
                              // }
                              onChange={(e) => {
                                setPermanantAddress({
                                  ...permanantAddress,
                                  address1: e.target.value,
                                })
                              }}
                              autoComplete="off" 
                            />
                          </CCol>
                        </CRow>

                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">Address 2</CFormLabel>
                            {/* {JSON.stringify(permanantAddress)} */}
                            <CFormInput
                            
                              type="text"
                              className="inputfieldgo"
                              id="Address2"
                              placeholder="Address 2"
                              value={permanantAddress?.address2}
                              onChange={(e) => {
                                setPermanantAddress({
                                  ...permanantAddress,
                                  address2: e.target.value,
                                })
                              }}
                              autoComplete="off" 
                            />
                          </CCol>
                        </CRow>

                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">
                              PinCode <code>*</code>
                            </CFormLabel>

                            <CFormInput
                              type="number"
                              className="inputfieldgo"
                              id="PinCode"
                              placeholder="PinCode"
                              value={pinCodeValue}
                              // value={permanantAddress?.pincode}

                              onChange={(e) => {
                                const value = e.target.value.slice(0, 6)
                                setPinCodeValue(value)
                                handlePinCode(e)
                                validatePincode(e)
                              }}
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {pincode}
                            </span>
                          </CCol>
                        </CRow>
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">
                              Area <code>*</code>
                              {/* <div>
                                {
                                  JSON.stringify(locationArea)
                                }
                              </div> */}
                            </CFormLabel>
                            <Select
                              type="text"
                              placeholder="Area Name"
                              className="inputfieldso"
                              options={locationArea}
                              // value={locationArea}

                              value={areaNameId}
                              onChange={(e) => {
                                setAreaNameId(e)
                                // console.log(e)

                                setPermanantAddress({
                                  ...permanantAddress,
                                  areaNameId: e,
                                })
                              }}
                              isSearchable
                            />

                            {/* <CFormInput
                              type="text"
                              className="inputfieldgo"
                              id="Area"
                              placeholder="Area"
                              value={permanantAddress?.area}
                              onChange={(e) => {
                                setPermanantAddress({
                                  ...permanantAddress,
                                  area: e.target.value,
                                })
                              }}
                            /> */}
                          </CCol>
                        </CRow>
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">
                              Country <code>*</code>
                            </CFormLabel>
                            <Select
                              // value={permanantAddress?.countryId}
                              value={
                                location?.countryName
                                  ? { label: location.countryName, value: location.countryName }
                                  : null
                              }
                              className="inputfieldso"
                              // options={countryName}

                              placeholder="Country Name"
                              onChange={(e) => {
                                setCountryId(e)
                                selectState(e.value)
                                setPermanantAddress({
                                  ...permanantAddress,
                                  countryId: e,
                                  stateId: '',
                                  cityId: '',
                                  areaNameId: '',
                                })
                              }}
                            />
                          </CCol>
                        </CRow>

                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">
                              State <code>*</code>
                            </CFormLabel>
                            <Select
                              // value={permanantAddress?.stateId}
                              value={
                                location?.regionName
                                  ? { label: location.regionName, value: location.regionName }
                                  : null
                              }
                              className="inputfieldso"
                              // options={stateName}
                              placeholder="State Name"
                              onChange={(e) => {
                                selectCity(countryId.value, e.value)
                                setPermanantAddress({
                                  ...permanantAddress,
                                  stateId: e,
                                  cityId: '',
                                  areaNameId: '',
                                })
                              }}
                            />
                          </CCol>
                        </CRow>

                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">
                              City <code>*</code>
                            </CFormLabel>
                            <Select
                              options={cityName}
                              className="inputfieldso"
                              placeholder="City Name"
                              // value={permanantAddress?.cityId}
                              value={
                                location.cityName
                                  ? {
                                      label: location.cityName,
                                      value: location.cityName,
                                    }
                                  : null
                              }
                              onChange={(e) => {
                                selectArea(e.value, permanantAddress?.stateId)
                                setPermanantAddress({
                                  ...permanantAddress,
                                  cityId: e,
                                  areaNameId: '',
                                })
                              }}
                            />

                            {/* <CFormInput
                              type="text"
                              placeholder="City"
                              className="inputfieldgo"
                              id="City"
                              value={permanantAddress?.city}
                              onChange={(e) => {
                                setPermanantAddress({
                                  ...permanantAddress,
                                  city: e.target.value,
                                })
                              }}
                            /> */}
                          </CCol>
                        </CRow>

                        {/* <CRow className="mb-3">
                          <CFormLabel className="col-form-label donlabel">
                            Country <code>*</code>
                          </CFormLabel>
                          <CCol sm={8}>
                            <CFormInput
                              type="text"
                              className="inputfieldgo"
                              placeholder="Country"
                              id="Country"
                              value={permanantAddress?.country}
                              onChange={(e) => {
                                setPermanantAddress({
                                  ...permanantAddress,
                                  country: e.target.value,
                                })
                              }}
                            />
                          </CCol>
                        </CRow> */}
                        {/* 
                        <CRow className="mb-3">
                          <CCol sm={8}>
                          <CFormLabel className="col-form-label donlabel">
                            PinCode <code>*</code>
                          </CFormLabel>
                            <CFormInput
                              type="number"
                              className="inputfieldgo"
                              id="PinCode"
                              placeholder="PinCode"
                              value={permanantAddress?.pincode}
                              onChange={(e) => {
                                {
                                  handlePinCode(e)
                                  validatePincode(e)
                                }
                              }}
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {pincode}
                            </span>
                          </CCol>
                        </CRow> */}
                        {/* <CRow className="mb-3">
                          <CFormLabel className="col-form-label donlabel">
                            Email Id <code>*</code>
                          </CFormLabel>
                          <CCol sm={8}>
                            <CFormInput
                              type="email"
                              className="inputfieldgo"
                              id="Email Id"
                              placeholder="Email Id"
                              onChange={(e) => {
                                validateEmail(e)
                                setPermanantAddress({
                                  ...permanantAddress,
                                  emailId: e.target.value,
                                })
                              }}
                              value={permanantAddress?.emailId}
                              // onChange={checkisEmail}
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {emailError}
                            </span>
                          </CCol>
                        </CRow>
                        <CRow className="mb-3">
                          <CFormLabel className="col-form-label donlabel">
                            Mobile No <code>*</code>
                          </CFormLabel>
                          <CCol sm={8}>
                            <CFormInput
                              type="number"
                              className="inputfieldgo"
                              id="MobileNo"
                              value={permanantAddress?.mobileNo}
                              onChange={(e) => {
                                validatePhoneNo(e)
                                handleNumChange(e)
                              }}
                              placeholder="Mobile No"
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {mobileNo}
                            </span>
                          </CCol>
                        </CRow> */}
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">Landline No</CFormLabel>
                            <CFormInput
                              type="number"
                              id="LandlineNo"
                              className="inputfieldgo"
                              placeholder="Landline No"
                              value={permanantAddress?.landlineNo}
                              onChange={(e) => {
                                handleNumChanges(e)
                              }}
                              // value={landlilne}
                              // onChange={handleNumChanges}
                            />
                          </CCol>
                        </CRow>
                      </CForm>
                    </CCol>
                    {/* 1111 */}
                    <CCol className="leftCols">
                      <CForm>
                        <p className="text-medium-emphasis-3 small">Communication Address</p>
                        <CRow className="mb-3">
                          <CFormCheck
                            type="checkbox"
                            id="invalidCheck"
                            onChange={(e) => setIsPermanentAddress(!isPermanentAddress)}
                            className="inputfieldgen"
                            label="Is Same as Permanent Address"
                            checked={isPermanentAddress}
                            // disabled={
                            //   !firstName ||
                            //   !lastName ||
                            //   !gender ||
                            //   !fatherName ||
                            //   !departmentId ||
                            //   !maritalStatus ||
                            //   !designationId ||
                            //   !bloodGroup ||
                            //   !reportingToId
                            // }
                            onClick={() => {
                              if (isPermanentAddress) {
                                setCommunicationAddress({
                                  address1: '',
                                  address2: '',
                                  areaNameId: '',
                                  cityId: '',
                                  stateId: '',
                                  countryId: '',
                                  pincode: '',
                                  // emailId: '',
                                  // mobileNo: '',
                                  landlineNo: '',
                                })
                              }
                              setIsPermanentAddress(!isPermanentAddress)
                            }}
                          />
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">Address 1</CFormLabel>
                            <CFormInput
                              className="inputfieldgo"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.address1
                                  : communicationAddress.address1
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  address1: e.target.value,
                                })
                              }}
                              type="text"
                              id="Address1"
                              placeholder="Address 1"
                            />
                          </CCol>
                        </CRow>
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">Address 2</CFormLabel>
                            <CFormInput
                              className="inputfieldgo"
                              type="text"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.address2
                                  : communicationAddress.address2
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  address2: e.target.value,
                                })
                              }}
                              id="Address2"
                              placeholder="Address 2"
                            />
                          </CCol>
                        </CRow>
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">PinCode</CFormLabel>
                            <CFormInput
                              type="number"
                              className="inputfieldgo"
                              value={
                                isPermanentAddress ? pinCodeValue : communicationAddress.pincode
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  pincode: e.target.value,
                                })
                              }}
                              id="PinCode"
                              placeholder="PinCode"
                            />
                          </CCol>
                        </CRow>
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">Area</CFormLabel>
                            <Select
                              className="inputfieldso"
                              // options={location.areaDetailsList
                              //   ? location.areaDetailsList.map((area) => ({
                              //       label: area,
                              //       value: area,
                              //     }))
                              //   : [] // Provide an empty array as options if areaDetailsList is undefined
                              // }
                              // value={permanantAddress.areaNameId}
                              // options={areaName}
                              // value={
                              //   isPermanentAddress
                              //     ? permanantAddress.areaNameId
                              //     : communicationAddress.areaNameId
                              // }
                              options={locationArea}
                              value={
                                isPermanentAddress
                                  ? permanantAddress.areaNameId
                                  : communicationAddress.areaNameId
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  areaNameId: e,
                                })
                              }}
                            />
                            {/* <CFormInput
                              className="inputfieldgo"
                              type="text"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.area
                                  : communicationAddress.area
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  area: e.target.value,
                                })
                              }}
                              id="Area"
                              placeholder="Area"
                            /> */}
                          </CCol>
                        </CRow>

                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">Country</CFormLabel>
                            <Select
                              className="inputfieldgo"
                              // value={
                              //   location?.countryName ?
                              //   {label : location.countryName,
                              //   value : location.countryName }
                              // : null}
                              options={countryName}
                              value={
                                isPermanentAddress
                                  ? location?.countryName
                                    ? { label: location.countryName, value: location.countryName }
                                    : null
                                  : communicationAddress.countryId
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  countryId: e,
                                })
                              }}
                              id="Country"
                              placeholder="Country"
                            />
                          </CCol>
                        </CRow>

                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">State</CFormLabel>
                            <Select
                              id="State"
                              placeholder="State"
                              className="inputfieldgo"
                              options={stateName}
                              // value={
                              //   location?.regionName ?
                              //   {label : location.regionName,
                              //   value : location.regionName }
                              // : null}
                              value={
                                isPermanentAddress
                                  ? location?.regionName
                                    ? { label: location.regionName, value: location.regionName }
                                    : null
                                  : communicationAddress.stateId
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  stateId: e,
                                })
                              }}
                            />
                          </CCol>
                        </CRow>

                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">City</CFormLabel>
                            <Select
                              className="inputfieldgo"
                              // value={location.cityName ? {
                              //   label:location.cityName,
                              //   value:location.cityName
                              // }: null}
                              options={cityName}
                              value={
                                isPermanentAddress
                                  ? location?.cityName
                                    ? { label: location.cityName, value: location.cityName }
                                    : null
                                  : communicationAddress.cityId
                              }
                              // value={
                              //   isPermanentAddress
                              //     ? permanantAddress.cityId
                              //     : communicationAddress.cityId
                              // }

                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  cityId: e,
                                })
                              }}
                              id="City"
                              placeholder="City"
                            />
                            {/* <CFormInput
                              type="text"
                              className="inputfieldgo"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.city
                                  : communicationAddress.city
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  city: e.target.value,
                                })
                              }}
                              id="City"
                              placeholder="City"
                            /> */}
                          </CCol>
                        </CRow>

                        {/* <CRow className="mb-3">
                          <CCol sm={8}>
                          <CFormLabel className="col-form-label donlabel">
                            PinCode
                          </CFormLabel>
                            <CFormInput
                              type="number"
                              className="inputfieldgo"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.pincode
                                  : communicationAddress.pincode
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  pincode: e.target.value,
                                })
                              }}
                              id="PinCode"
                              placeholder="PinCode"
                            />
                          </CCol>
                        </CRow> */}
                        {/* <CRow className="mb-3">
                          <CFormLabel className="col-form-label donlabel">
                            Email Id
                          </CFormLabel>
                          <CCol sm={8}>
                            <CFormInput
                              type="text"
                              className="inputfieldgo"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.emailId
                                  : communicationAddress.emailId
                              }
                              onChange={(e) => {
                                validateEmailCom(e)
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  emailId: e.target.value,
                                })
                              }}
                              id="Email Id"
                              placeholder="Email Id"
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {emailErrorCom}
                            </span>
                          </CCol>
                        </CRow>
                        <CRow className="mb-3">
                          <CFormLabel className="col-form-label donlabel">
                            Mobile No
                          </CFormLabel>
                          <CCol sm={8}>
                            <CFormInput
                              type="number"
                              className="inputfieldgo"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.mobileNo
                                  : communicationAddress.mobileNo
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  mobileNo: e.target.value,
                                })
                              }}
                              id="MobileNo"
                              placeholder="Mobile No"
                            />
                          </CCol>
                        </CRow> */}
                        <CRow className="mb-3">
                          <CCol sm={8}>
                            <CFormLabel className="col-form-label donlabel">Landline No</CFormLabel>
                            <CFormInput
                              type="number"
                              // className="inputfieldgo"
                              value={
                                isPermanentAddress
                                  ? permanantAddress.landlineNo
                                  : communicationAddress.landlineNo
                              }
                              onChange={(e) => {
                                setCommunicationAddress({
                                  ...communicationAddress,
                                  landlineNo: e.target.value,
                                })
                              }}
                              id="LandlineNo"
                              placeholder="Landline No"
                            />
                          </CCol>
                        </CRow>
                      </CForm>
                    </CCol>
                  </div>
                  <CRow className="btnAlign">
                    <div className="">
                      {update ? (
                        <div className="d-flex flex-row justify-content-end">
                          <button
                            className="update mright"
                            type="submit"
                            disabled={
                              dobError || 
                              dobError ||
                              emailError 
                              || pincode || mobileNo
                            }
                            onClick={(e) => {
                              updateEmployees(empId.value)
                              e.preventDefault()
                              // setPictureDelete()
                            }}
                           
                          >
                            Update
                          </button>
                          <div>
                            <button
                              className="reset"
                              onClick={() => {
                                setAddScreen(!addScreen)
                              }}
                            >
                              cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="d-flex flex-row justify-content-end">
                          <button
                            className="save mright"
                            disabled={
                              !firstName ||
                              !lastName ||
                              !picture ||
                              !gender ||
                              !fatherName ||
                              !departmentId ||
                              !maritalStatus ||
                              !designationId ||
                              !bloodGroup ||
                              !reportingToId ||
                              !permanantAddress ||
                              !permanantAddress.areaNameId ||
                              // !permanantAddress.location ||
                              // !permanantAddress.stateId ||
                              // !permanantAddress.pincode ||
                              !EmpEmailId ||
                              !EmpMobileNo ||
                              emailError ||
                              mobileNo ||
                              pincode
                            }
                            type="submit"
                            onClick={(e)=>{saveEmployee(); e.preventDefault()}}
                          >
                            save
                          </button>
                          <div>
                            <button
                              className="clear mright"
                              onClick={(e) => {
                                e.preventDefault()
                                clearFun(e)
                              }}
                            >
                              Clear
                            </button>
                          </div>
                          <div>
                            <button
                              className="reset"
                              onClick={() => {
                                setAddScreen(!addScreen)
                              }}
                            >
                              cancel
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </CRow>
                </CCardBody>
              </CCard>
            </CCol>

            {/* END */}
          </CRow>
        </CForm>
      )}

      <br />
    </React.Fragment>
  )
}

export default EmployeeForm