import axios from 'axios'
import React, { useEffect } from 'react'
import { useState, useContext } from 'react'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CButton,
  CContainer,
  CModal,
  CModalBody,
  CModalFooter,
  CModalHeader,
  CModalTitle,
  // CDropdownToggle,
  // CDropdownMenu,
  // CDropdownItem,
} from '@coreui/react-pro'

import { FaEdit } from 'react-icons/fa'
import { RiDeleteBinFill } from 'react-icons/ri'
import { GlobalContext } from 'src/context'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3 } from 'react-icons/im'
import ReactToPdf from 'react-to-pdf'
import { employeeDelete, employeeTable } from 'src/services/ApiServices'
import moment from 'moment'

// eslint-disable-next-line react/prop-types
function FilterOption({ updateEmployee, employeeId }) {
  const [employee, setEmployee] = useState([])
  const { state } = useContext(GlobalContext)
  const [visible, setVisible] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [employeeNameData,setEmployeeNameData] = useState('');
  useEffect(() => {
    showEmployee(state.companyId)
  }, [state.companyId])

  const [tabledelete, settabledelete] = useState('')

  const onDelete = async (employeeId) => {
    var res = await employeeDelete(employeeId)
    try {
      if (res) {
        if (res.success) {
          const data = employee.filter((Emplevel) => Emplevel.employeeId !== employeeId)
          setEmployee(data)
          toast.success(res.message)
        } else {
          toast.error(res.error)
        }
      }
      showEmployee()
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success === false) {
          // toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const showEmployee = async () => {
    var response
    try {
      response = await employeeTable()
      if (response) {
        if (response.success) {
          if (response.employees) {
            console.log('updatedata', response.employees)
            const data = response.employees.map((x, i) => {
              return {
                Sno: i + 1,
                employeeName:`${x.firstName} ${x.lastName} `,
                firstName: x.firstName,
                lastName: x.lastName,
                fatherName: x.fatherName,
                department: x.departmentId.departmentName,
                designation: x.designationId?.designationName,
                departmentId: x.departmentId,
                designationId: x.designationId,
                mobileNo: x.mobileNo,
                emailId: x.emailId,
                bloodGroup: x.bloodGroup,
                reportingToId: x.reportingTo?._id,
                doj: moment(x.doj).format('DD MMM YYYY'),
                dob: x.dob,
                gender: x.gender,
                maritalStatus: x.maritalStatus,
                reportingTo: x.reportingTo?.firstName
                  ? `${x.reportingTo.firstName} ${x.reportingTo.lastName}`
                  : '-',
                employeeId: x._id,
                permanantAddress: x.permanantAddress,
                profilePicture: x.profilePicture,
                spouceName: x.spouceName,
                sameAddress: x.sameAddress,
              }
            })
            setEmployee(data)
          }

          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success === false) {
          // toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const columns = [
    {
      label: 'S.No',
      key: 'Sno',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      label: 'First Name',
      key: 'firstName',
      _style: { width: '12%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      label: 'Last Name',
      key: 'lastName',
      _style: { width: '12%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      label: 'Department',
      key: 'department',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      label: 'Designation',
      key: 'designation',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      label: 'DOJ',
      key: 'doj',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'reportingTo',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '10%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]
  const myFunction = () => {
    window.open('https://www.google.com/')
  }

  const [modalIsOpen, setIsOpen] = useState(false)

  function openModal() {
    setIsOpen(true)
  }

  function closeModal() {
    setIsOpen(false)
  }

  const ref = React.createRef()

  const options = {
    orientation: 'landscape',
    unit: 'in',
  }
  return (
    <CContainer className="filterContainer filterContainer_New">
      <CSmartTable
        activePage={1}
        clickableRows
        columns={columns}
        columnFilter
        columnSorter
        items={employee}
        itemsPerPageSelect
        itemsPerPageLabel={'No of Rows'}
        itemsPerPage={5}
        pagination
        scopedColumns={{
          show_details: (item) => {
            return (
              <td className="py-2 gaponly">
                <CButton
                  className="updateBtn"
                  onClick={() => {
                    updateEmployee(item)
                  }}
                >
                  <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                </CButton>
                {/* {JSON.stringify(item)} */}
                <CButton

                  className="deleteBtn"
                  onClick={() => {
                    setVisible(!visible)
                    settabledelete(item.employeeId)
                    setEmployeeNameData(item.employeeName)
                  }}
                >
                  <RiDeleteBinFill style={{ fontSize: '22px', color: '#ea4335' }} />
                </CButton>
              </td>
            )
          },
        }}
        sorterValue={{ column: 'name', state: 'asc' }}
        tableProps={{
          striped: true,
          hover: true,
        }}
      />
      <>
        <CModal size="sm" alignment="center" visible={visible} onClose={() => setVisible(false)}>
          <CModalHeader>
            <div
              className="times"
              onClick={() => {
                setVisible(false)
              }}
            >
              &times;
            </div>
            <CModalTitle>
              <span>
                <CIcon icon={cilTask} className="me-2" />
              </span>
              Confirm
            </CModalTitle>
          </CModalHeader>
          <CModalBody className="loginModelBody"><sapn>
            Are you sure do you want to delete the <br /> 
            Employee Name : <b>{employeeNameData}</b></sapn>
          </CModalBody>
          <CModalFooter>
            <button className="modelBtnNo" onClick={() => setVisible(false)}>
              No
            </button>
            <button
              className="modelBtnYes"
              onClick={() => {
                onDelete(tabledelete)
                setVisible(false)
              }}
            >
              Yes
            </button>
          </CModalFooter>
        </CModal>
      </>
    </CContainer>
  )
}

export default FilterOption

// .....................................
