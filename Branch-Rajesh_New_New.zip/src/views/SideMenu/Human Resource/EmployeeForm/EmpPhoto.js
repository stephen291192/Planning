import React from 'react'
import ReactDOM from 'react-dom'

function Photo() {
  const uploadedImage = React.useRef(null)
  const imageUploader = React.useRef(null)

  const handleImageUpload = (e) => {
    const [file] = e.target.files
    if (file) {
      const reader = new FileReader()
      const { current } = uploadedImage
      current.file = file
      reader.onload = (e) => {
        current.src = e.target.result
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div
      style={
        {
          // display: 'flex',
          // // flexDirection: 'column',
          // // alignItems: 'center',
          // justifyContent: 'center',
        }
      }
    >
      <div
        style={{
          height: '150px',
          width: '130px',
          // border: '1px solid #efefef',
          boxShadow: 'rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px',
        }}
        onClick={() => imageUploader.current.click()}
      >
        <img
          ref={uploadedImage}
          style={{
            width: '100%',
            height: '100%',
            position: 'acsolute',
          }}
        />
      </div>
      <input
        type="file"
        name="profilePicture"
        accept="image/*"
        onChange={handleImageUpload}
        ref={imageUploader}
        style={{ display: 'none' }}
      />

      <input
        className="my-3 hoverblock inputfieldgo"
        type="file"
        // style={{ marginLeft: '20%' }}
        // onChange={(e) => {
        //   setCompanyLogo(e.target.value)
        // }}
        // value={companyLogo}
      />
      {/* choose your profile picture */}
    </div>
  )
}
export default Photo
