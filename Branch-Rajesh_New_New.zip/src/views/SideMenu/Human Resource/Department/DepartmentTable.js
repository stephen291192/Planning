import React, { useContext } from 'react'
import { toast } from 'react-toastify'
import { useState, useEffect, useRef } from 'react'
import {
  CSmartTable,
  CButton,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { FaEdit } from 'react-icons/fa'
import { RiDeleteBinFill } from 'react-icons/ri'
import { GlobalContext } from 'src/context'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { departdelete, getalldepartment } from 'src/services/ApiServices'

// eslint-disable-next-line react/prop-types
export const DepartmentTable = ({ updateDepartment, showParentDepartment }) => {
  const componentRef = useRef()
  const [department, setDepartment] = useState([])
  const [company, setCompany] = useState([])
  const [visible, setVisible] = useState(false)
  const { state, dispatch } = useContext(GlobalContext)
  const [tableDeleteId, setTableDeleteId] = useState('')
  const [tableDeleteId1, setTableDeleteId1] = useState('')

  const [tableSelectedDeptName, settableSelectedDeptName] = useState('')
  // console.log(tableDeleteId1, 'assfvkljklj')
  const intial_state = () => {
    setCompany([])
    setDepartment([])
  }

  useEffect(() => {
    intial_state()
    showDepartmnet()
  }, [state.companyId])

  const onDelete = async () => {
    var response
    const departmentId = tableDeleteId1
    try {
      response = await departdelete(departmentId)
      if (response.success) {
        setDepartment(response)
        const data = department.filter((department) => department.departmentId !== departmentId)
        showDepartmnet(state.companyId, data)
        toast.success(response.message)
      } else {
        toast.error(response.error)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const showDepartmnet = async (companyId) => {
    setDepartment([])
    var response
    try {
      response = await getalldepartment(companyId)
      if (response) {
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x, i) => {
              return {
                S_no: i + 1,
                companyName: x.companyId.companyName,
                departmentCode: x.code,
                departmentAbbreviation: x.abbreviation,
                parentDepartment: x.reportingTo?.departmentName
                  ? x.reportingTo.departmentName
                  : x.reportingTo === null
                  ? '-'
                  : x.parentDepartment,
                parentDepartmentId: x.parentDepartment?._id
                  ? x.parentDepartment._id
                  : x.parentDepartment === null
                  ? '-'
                  : x.parentDepartment,
                departmentName: x.departmentName,
                companyId: x.companyId._id,
                departmentId: x._id,
              }
            })
            setDepartment(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const columns = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },

    {
      key: 'departmentName',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'departmentAbbreviation',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'departmentCode',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'parentDepartment',
      label: 'Reporting to Department',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '6%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]

  return (
    <>
      <CContainer className="filterContainer filterContainer_New">
        <CSmartTable
          activePage={1}
          clickableRows
          columns={columns}
          columnFilter
          columnSorter
          items={department}
          itemsPerPageSelect
          itemsPerPageLabel={'No of Rows'}
          itemsPerPage={5}
          pagination
          scopedColumns={{
            show_details: (item) => {
              return (
                <td className="gaponly">
                  {/* {JSON.stringify(item)} */}
                  <CButton
                    className="updateBtn"
                    onClick={() => {
                      showParentDepartment()
                      updateDepartment(item)
                    }}
                  >
                    <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                  </CButton>
                  <CButton
                    className="deleteBtn"
                    onClick={() => {
                      // console.log(item, 'DEPARTMENT LIST')
                      setVisible(!visible)
                      setTableDeleteId(item.companyId)
                      setTableDeleteId1(item.departmentId)
                      settableSelectedDeptName(item.departmentName)
                    }}
                  >
                    <RiDeleteBinFill style={{ fontSize: '22px', color: '#ea4335' }} />
                  </CButton>
                </td>
              )
            },
          }}
          sorterValue={{ column: 'name', state: 'asc' }}
          tableProps={{
            striped: true,
            hover: true,
            responsive: true,
          }}
        />
        <>
          <CModal size="sm" alignment="center" visible={visible} onClose={() => setVisible(false)}>
            <CModalHeader>
              <div
                className="times"
                onClick={() => {
                  setVisible(false)
                }}
              >
                &times;
              </div>
              <CModalTitle>
                <span>
                  <CIcon icon={cilTask} className="me-2" />
                </span>
                Confirm
              </CModalTitle>
            </CModalHeader>
            <CModalBody className="loginModelBody">
              <span>
                Are you sure do you want to delete the <br />
                Department Name : <b>{tableSelectedDeptName} </b>
              </span>
            </CModalBody>
            <CModalFooter>
              <button className="modelBtnNo" onClick={() => setVisible(false)}>
                No
              </button>
              <button
                className="modelBtnYes"
                onClick={() => {
                  onDelete()
                  setVisible(false)
                }}
              >
                Yes
              </button>
            </CModalFooter>
          </CModal>
        </>
      </CContainer>
    </>
  )
}
