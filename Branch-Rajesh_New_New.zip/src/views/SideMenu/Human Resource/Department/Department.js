
import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import { toast } from 'react-toastify'
import { DepartmentTable } from './DepartmentTable'
import { GlobalContext } from 'src/context'
import { addDepartment, getalldepartment, updatedepartment } from 'src/services/ApiServices'

export const Department = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [update, setupdate] = useState(false)
  const [addScreen, setAddScreen] = useState(true)
  const [companyName, setCompanyName] = useState([])
  const [parentDepartment, setParentDepartment] = useState([])
  const [departmentName, setDepartmentName] = useState('')
  const [departmentAbbreviation, setDepartmentAbbreviation] = useState('')
  const [departmentCode, setDepartmentCode] = useState('')
  const [companyId, setCompanyId] = useState('')
  const [departmentId, setDepartmentId] = useState('')
  const [parentDepartmentId, setParentDepartmentId] = useState('')
  const [departNameError, setDepartNameError] = useState('')
  const [departNameAbbriError, setDepartNameAbbriError] = useState('')
  const [departNameCodeError, setDepartNameCodeError] = useState('')

  useEffect(() => {
    showParentDepartment(state.companyId)
  }, [])

  const validateDepartmentName = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 6) {
      setDepartNameError('Department name should be 6 letters')
    } else {
      setDepartNameError()
    }
  }

  const validateDepartmentAbbriName = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 3) {
      setDepartNameAbbriError('Department Abbreviation should be 3 letters')
    } else {
      setDepartNameAbbriError()
    }
  }

  const validateDepartmentCodeName = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 2) {
      setDepartNameCodeError('Department code should be 2 letters')
    } else {
      setDepartNameCodeError()
    }
  }

  const showParentDepartment = async (companyId) => {
    var response
    try {
      response = await getalldepartment(companyId)
      if (response) {
        if (response.success) {
          const data = response.data.map((x) => {
            return {
              value: x._id,
              label: x?.departmentName,
            }
          })
          setParentDepartment(data)
        } else {
          setParentDepartment([])
        }
      }
    } catch (e) {
      console.log(e)
    }
  }

  const clearDepartbtn = (e) => {
    e.preventDefault()
    setDepartmentName('')
    setDepartmentAbbreviation('')
    setDepartmentCode('')
    setParentDepartmentId('')
    setAddScreen(false)
  }

  const updateDepartment = (data) => {
    console.log(data, 'datadatadatadatadatadata')
    setAddScreen(!addScreen)
    setupdate(true)
    setCompanyName(data.companyName)
    setDepartmentCode(data.departmentCode)
    setDepartmentAbbreviation(data.departmentAbbreviation)
    setParentDepartment(data.parentDepartment)
    setDepartmentName(data.departmentName)
    setCompanyId({
      value: data.companyId,
      label: data.companyName,
    })
    setDepartmentId({
      value: data.departmentId,
      label: data.departmentName,
    })
    setParentDepartmentId({
      value: data.parentDepartmentId,
      label: data.parentDepartment === "-" ? "Select Reporting to Department" : data.parentDepartment,
    })
    setParentDepartment(parentDepartment.filter((x)=> x.label !== departmentName))
  }

  const saveDepartmentupdate = async (departmentId) => {
    const data = {
      departmentName: departmentName,
      abbreviation: departmentAbbreviation,
      code: departmentCode,
      reportingTo: parentDepartmentId.value,
    }
    try {
      const response = await updatedepartment(data, departmentId)
      if (response && response.success === true) {
        toast.success(response.message)
        setCompanyName([])
        setDepartmentName('')
        setDepartmentCode('')
        setParentDepartmentId('')
        setCompanyId('')
        setAddScreen(!addScreen)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const saveDepartment = async () => {
    const data = {
      companyId: state.companyId,
      departmentName: departmentName,
      abbreviation: departmentAbbreviation,
      code: departmentCode,
      reportingTo: parentDepartmentId.value,
    }
    try {
      const response = await addDepartment(data)
      if (response && response.success === true) {
        toast.success(response.message)
        setCompanyName([])
        setDepartmentName('')
        setDepartmentCode('')
        setParentDepartmentId('')
        setCompanyId('')
        setAddScreen(!addScreen)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <React.Fragment>
      {addScreen ? (
        <>
          <div className="d-flex align-items-center justify-content-between">
            <div className="font_Title pt-2 pb-0 pr-2">List of Department</div>

            <div>
              <button
                className="loginBtn mright loginBtn_New"
                onClick={() => {
                  setAddScreen(!addScreen)
                  setupdate(false)
                  setDepartmentName('')
                  setDepartmentCode('')
                  setParentDepartmentId('')
                  setDepartmentAbbreviation('')
                }}
              >
                Add New
              </button>
            </div>
          </div>

          <CRow>
            <CCol xs={12} className="p-0">
              <DepartmentTable
                updateDepartment={updateDepartment}
                showParentDepartment={showParentDepartment}
              />
            </CCol>
          </CRow>
        </>
      ) : (
        <CForm className="">
          <CRow>
            <CCol xs={12}>
              <span className="employeeHeader">
                {update ? (
                  <h3 className="font_Title">Update Department </h3>
                ) : (
                  <h3 className="font_Title">Create Department</h3>
                )}
              </span>
              <CCard className="mb-6">
                <CCardBody>
                  <CForm>
                    <CRow className="mb-3">
                      <CCol sm={3}>
                        <CFormLabel className="col-form-label donlabel">
                          Department <code>*</code>
                        </CFormLabel>
                        <CFormInput
                          className="inputfieldgo"
                          type="text"
                          value={departmentName}
                          onChange={(e) => {
                            setDepartmentName(e.target.value)
                            validateDepartmentName(e)
                          }}
                          placeholder="Name of the Department"
                        />
                        <span
                          style={{
                            fontWeight: '500',
                            fontSize: '12px',
                            color: 'red',
                          }}
                        >
                          {departNameError}
                        </span>
                      </CCol>

                      <CCol sm={3}>
                        <CFormLabel className="col-form-label donlabel">
                          Department Abbreviation <code>*</code>
                        </CFormLabel>
                        <CFormInput
                          type="text"
                          className="inputfieldgo"
                          disabled={!departmentName}
                          value={departmentAbbreviation}
                          onChange={(e) => {
                            const inputValue = e.target.value.slice(0, 3).toUpperCase() // Limit input to 3 characters
                            setDepartmentAbbreviation(inputValue)
                            validateDepartmentAbbriName(e)
                          }}
                          placeholder="Department Abbreviation"
                        />
                        <span
                          style={{
                            fontWeight: '500',
                            fontSize: '12px',
                            color: 'red',
                          }}
                        >
                          {departNameAbbriError}
                        </span>
                      </CCol>
                      <CCol sm={3}>
                        <CFormLabel className="col-form-label donlabel">
                          Department Code <code>*</code>
                        </CFormLabel>
                        <CFormInput
                          type="text"
                          className="inputfieldgo"
                          disabled={!departmentAbbreviation}
                          value={departmentCode}
                          onChange={(e) => {
                            const inputValue = e.target.value.slice(0, 2).toUpperCase()
                            setDepartmentCode(inputValue)
                            validateDepartmentCodeName(e)
                          }}
                          placeholder="Department Code"
                        />
                        <span
                          style={{
                            fontWeight: '500',
                            fontSize: '12px',
                            color: 'red',
                          }}
                        >
                          {departNameCodeError}
                        </span>
                      </CCol>
                    </CRow>
                    <CRow className="mb-3">
                      <CCol sm={3}>
                        <CFormLabel className="col-form-label donlabel">
                          Select Reporting to Department
                        </CFormLabel>
                        <Select
                          placeholder="Select Reporting to Department"
                          // options={parentDepartment}
                          options={parentDepartment.filter((x) => x.label !== departmentName)}
                          className="inputfieldso"
                          value={parentDepartmentId}
                          onChange={(e) => {
                            setParentDepartmentId(e)
                            showParentDepartment(state.companyId)
                          }}
                        />
                      </CCol>
                    </CRow>
                    <div className="d-flex flex-row justify-content-end">
                      {update ? (
                        <div>
                          <button
                            className="update mright"
                            type="submit"
                            onClick={(e) => {
                              e.preventDefault()
                              saveDepartmentupdate(departmentId.value)
                            }}
                            disabled={
                              !departmentName ||
                              !departmentCode ||
                              departNameCodeError ||
                              departNameError
                            }
                          >
                           
                            Update
                          </button>
                        </div>
                      ) : (
                        <div>
                          <button
                            className="save mright"
                            type="submit"
                            disabled={
                              !departmentName ||
                              !departmentCode ||
                              departNameCodeError ||
                              departNameError
                            }
                            onClick={(e) => {
                              saveDepartment()
                              e.preventDefault()
                            }}
                          >
                            save
                          </button>
                        </div>
                      )}
                      {update ? null : (
                        <div>
                          <button
                            className="clear mright"
                            onClick={(e) => {
                              clearDepartbtn(e)
                            }}
                          >
                            Clear
                          </button>
                        </div>
                      )}
                      <div>
                        <button className="reset" onClick={() => setAddScreen(!addScreen)}>
                          cancel
                        </button>
                      </div>
                    </div>
                  </CForm>
                </CCardBody>
              </CCard>
            </CCol>
          </CRow>
        </CForm>
      )}
    </React.Fragment>
  )
}