import React, { useState, useEffect, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import { toast } from 'react-toastify'
import { GlobalContext } from 'src/context'
import { DesignationTable } from './DesignationTable'
import {
  addDesignation,
  designationUpdate,
  getalldepartment,
  getalldesignation,
} from 'src/services/ApiServices'

export const Designation = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [checkbox, setCheckbox] = useState(false)
  const [update, setupdate] = useState(false)
  const [tableShow, setTableShow] = useState(false)

  const [addScreen, setAddScreen] = useState(true)
  const [companyId, setCompanyId] = useState('')
  const [designationName, setDesignationName] = useState('')
  const [designationAbbri, setDesignationAbbri] = useState('')
  const [designationCode, setDesignationCode] = useState('')
  const [departmentId, setDepartmentId] = useState('')
  const [departmentIdad, setDepartmentIdad] = useState('')
  const [designationId, setDesignationId] = useState('')
  const [reportingId, setReportingId] = useState('')

  const [companyName, setCompanyName] = useState([])
  const [departmentName, setDepartmentName] = useState([])
  const [reporting, setReporting] = useState([])
  const [departNameError, setDepartNameError] = useState('')
  const [departNameAbbriError, setDepartNameAbbriError] = useState('')
  const [departNameCodeError, setDepartNameCodeError] = useState('')
  useEffect(() => {
    showDepartment()
    showReporting(state.companyId, departmentId?.value)
  }, [state.companyId, departmentId?.value])

  const validateDesName = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 6) {
      setDepartNameError('Designation name should be 6 letters')
    } else {
      setDepartNameError()
    }
  }

  const validateDesAbbri = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 3) {
      setDepartNameAbbriError('Designation Abbreviation should be 3 letters')
    } else {
      setDepartNameAbbriError()
    }
  }

  const validateDesCodeName = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 2) {
      setDepartNameCodeError('Designation code should be 2 letters')
    } else {
      setDepartNameCodeError()
    }
  }

  const showReporting = async (companyId, departmentId) => {
    setReporting([])
    var response
    try {
      response = await getalldesignation(companyId, departmentId)
      if (response) {
        if (response.success) {
          const data = response.data.map((x) => {
            return {
              value: x._id,
              label: x.designationName,
            }
          })
          setReporting(data)
        } else {
          setReporting([])
        }
      }
    } catch (e) {
      console.log(e)
    }
  }

  const showDepartment = async () => {
    var response
    setDepartmentName([])
    try {
      response = await getalldepartment(state.companyId)
     
      if (response && response.success) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: x?.departmentName,
          }
        })
        setDepartmentName(data)
      } else {
        toast.error( 'No designations found for department');
        
      }
    } catch (e) {
      console.log(e);
      // toast.error('An error occurred while fetching designations');
    }
  }

  const clearDesigbtn = (e) => {
    e.preventDefault()
    setDepartmentId('')
    setDesignationName('')
    setDesignationAbbri('')
    setDesignationCode('')
    setReportingId('')
    setAddScreen(false)
  }

  const updateDesignation = (data) => {
    console.log(data, 'datadatadata')
    setAddScreen(!addScreen)
    setupdate(true)
    setDesignationId(data.designationId)
    setDesignationName(data.designationName)
    setDesignationCode(data.designationCode)
    setDesignationAbbri(data.designationAbbreviation)
    setCompanyName(data.companyName)
    setDepartmentName(data.departmentName)
    setReporting(data.reportingTo)
    showDepartment()
    showReporting(state.companyId, departmentId?.value)
    setReportingId({
      value: data.reportingToId,
      label: data.reportingTo == "-" ? "Select Reporting To" : data.reportingTo,
    })
    setReporting(reporting.filter((x)=> x.label !== designationName))
    setCompanyId({
      value: data.companyId,
      label: data.companyName,
    })
    setDepartmentId({
      value: data.departmentId,
      label: data.departmentName,
    })
  }

  const saveDesignation = async (companyId, departmentId) => {
    const data = {
      companyId: state.companyId,
      code: designationCode,
      abbreviation: designationAbbri,
      designationName: designationName,
      departmentId: departmentId.value,
      reportingTo: reportingId.value,
      checkbox,
    }
    try {
      const response = await addDesignation(data, companyId, departmentId)
      if (response && response.success === true) {
        toast.success(response.message)
        setCompanyId('')
        setDesignationName('')
        setDesignationCode('')
        setDepartmentId('')
        setReportingId('')
        setCompanyName([])
        setDepartmentName([])
        setReporting([])
        setCheckbox(false)
        showDepartment()
        setAddScreen(!addScreen)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const updatedesignation = async (companyId, departmentId, designationId) => {
    const data = {
      designationName: designationName,
      code: designationCode,
      abbreviation: designationAbbri,
      reportingTo: reportingId.value,
    }
    try {
      const response = await designationUpdate(data, companyId, departmentId, designationId)
      if (response && response.success === true) {
        toast.success(response.message)
        setCompanyName([])
        setDepartmentName('')
        setCompanyId('')
        setDepartmentName([])
        showDepartment()
        setAddScreen(!addScreen)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <div>
      {addScreen ? (
        <div>
          <div className="d-flex align-items-center justify-content-between">
            <div className="font_Title pt-2 pb-0 pr-2">List of Designation</div>
            <div>
              <button
                className="loginBtn mright loginBtn_New"
                onClick={() => {
                  setAddScreen(!addScreen)
                  setDesignationCode('')
                  setDesignationAbbri('')
                  setDesignationName('')
                  setDepartmentId('')
                  setReportingId('')
                  setupdate(false)
                }}
              >
                Add New
              </button>
            </div>
          </div>

          <CRow>
            <CCol xs={12} className="p-0">
              <CCard className="mb-6">
                <CCardBody>
                  <CRow className="mb-3">
                    <CCol sm={3}>
                      <CFormLabel className="col-form-label donlabel">
                        Department Name <code>*</code>
                      </CFormLabel>
                      <Select
                        options={departmentName}
                        className="inputfieldso"
                        value={departmentIdad}
                        onChange={(e) => {
                          setDepartmentIdad(e)
                          setTableShow(true)
                        }}
                        placeholder="Department Name"
                      />
                    </CCol>
                  </CRow>
                </CCardBody>
              </CCard>
              <CCol xs={12} className="p-0">
                {tableShow && (
                  <DesignationTable
                    updateDesignation={updateDesignation}
                    depart={departmentIdad?.value}
                  />
                )}
              </CCol>
            </CCol>
          </CRow>
        </div>
      ) : (
        <div>
          <CForm>
            <CRow>
              <CCol xs={12}>
                <span className="employeeHeader">
                  {update ? (
                    <h3 className="font_Title">Update Designation</h3>
                  ) : (
                    <h3 className="font_Title">Create Designation</h3>
                  )}
                </span>
                <CCard className="mb-6">
                  <CCardBody>
                    <CForm>
                      <CRow className="mb-3">
                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">
                            Select Department <code>*</code>
                          </CFormLabel>
                          <Select
                            placeholder="Select Department"
                            options={departmentName}
                            className="inputfieldso"
                            value={departmentId}
                            isDisabled={update}
                            onChange={(e) => {
                              setDepartmentId(e)
                              showReporting(state.companyId, e?.value)
                            }}
                          />
                        </CCol>

                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">
                            Designation Name <code>*</code>
                          </CFormLabel>
                          <CFormInput
                            type="text"
                            className="inputfieldgo"
                            value={designationName}
                            disabled={!departmentId}
                            onChange={(e) => {
                              setDesignationName(e.target.value)
                              validateDesName(e)
                            }}
                            placeholder="Designation Name"
                          />
                          <span
                            style={{
                              fontWeight: '500',
                              fontSize: '12px',
                              color: 'red',
                            }}
                          >
                            {departNameError}
                          </span>
                        </CCol>

                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">
                            Designation Abbreviation <code>*</code>
                          </CFormLabel>
                          <CFormInput
                            type="text"
                            className="inputfieldgo"
                            value={designationAbbri}
                            disabled={!designationName}
                            onChange={(e) => {
                              const inputValue = e.target.value.slice(0, 3).toUpperCase()
                              setDesignationAbbri(inputValue)
                              validateDesAbbri(e)
                            }}
                            placeholder="Designation Abbreviation"
                          />
                          <span
                            style={{
                              fontWeight: '500',
                              fontSize: '12px',
                              color: 'red',
                            }}
                          >
                            {departNameAbbriError}
                          </span>
                        </CCol>
                      </CRow>

                      <CRow className="mb-3">
                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">
                            Designation Code <code>*</code>
                          </CFormLabel>
                          <CFormInput
                            type="text"
                            value={designationCode}
                            className="inputfieldgo"
                            disabled={!departmentId || !designationName || !designationAbbri}
                            onChange={(e) => {
                              const inputValue = e.target.value.slice(0, 2).toUpperCase()
                              setDesignationCode(inputValue)
                              validateDesCodeName(e)
                            }}
                            placeholder="Designation Code"
                          />
                          <span
                            style={{
                              fontWeight: '500',
                              fontSize: '12px',
                              color: 'red',
                            }}
                          >
                            {departNameCodeError}
                          </span>
                        </CCol>

                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">
                            Reporting To Designation
                          </CFormLabel>
                          <Select
                            placeholder="Select Reporting To"
                            options={reporting.filter((x)=> x.label !== designationName)}
                            className="inputfieldso"
                            value={reportingId}
                            onChange={(e) => {
                              setReportingId(e)
                            }}
                          />
                        </CCol>
                      </CRow>
                      <div className="d-flex flex-row justify-content-end">
                        {update ? (
                          <div>
                            <button
                              className="update mright"
                              type="submit"
                              onClick={() => {
                                updatedesignation(
                                  state.companyId,
                                  departmentId.value,
                                  designationId,
                                )
                              }}
                              disabled={
                                !designationCode ||
                                !departmentId ||
                                !designationName ||
                                !designationAbbri||
                                departNameAbbriError || departNameCodeError || departNameError
                              }
                            >
                              Update
                            </button>
                          </div>
                        ) : (
                          <div>
                            <button
                              disabled={
                                !designationCode ||
                                !departmentId ||
                                !designationName ||
                                !designationAbbri||
                                departNameAbbriError || departNameCodeError || departNameError
                              }
                              className="save mright"
                              type="submit"
                              onClick={(e) => {
                                saveDesignation(state.companyId, departmentId.value);
                                e.preventDefault()
                              }}
                            >
                              save
                            </button>
                          </div>
                        )}
                        {update ? null : (
                          <div>
                            <button
                              className="clear mright"
                              onClick={(e) => {
                                clearDesigbtn(e)
                              }}
                            >
                              Clear
                            </button>
                          </div>
                        )}
                        <div>
                          <button
                            className="reset"
                            type="reset"
                            onClick={() => setAddScreen(!addScreen)}
                          >
                            cancel
                          </button>
                        </div>
                      </div>
                    </CForm>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
          </CForm>
        </div>
      )}
    </div>
  )
}