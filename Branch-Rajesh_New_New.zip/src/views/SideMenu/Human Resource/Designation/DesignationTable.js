import React, { useContext } from 'react'
import { toast } from 'react-toastify'
import { useState, useEffect } from 'react'
import {
  CSmartTable,
  CButton,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { FaEdit } from 'react-icons/fa'
import { RiDeleteBinFill } from 'react-icons/ri'
import { GlobalContext } from 'src/context'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { designdelete, getalldesignation } from 'src/services/ApiServices'

// eslint-disable-next-line react/prop-types
export const DesignationTable = ({ updateDesignation, depart }) => {
  const [tableDeleteId, setTableDeleteId] = useState('')
  const [tableDeleteIds, setTableDeleteIds] = useState('')
  const [tableDesignationName, settableDesignationName] = useState('')
  const [designation, setDesignation] = useState([])
  const { state, dispatch } = useContext(GlobalContext)
  const [visible, setVisible] = useState(false)

  // const intial_state = () => {
  //   setDesignation([])
  // }

  // useEffect(() => {
  //   intial_state()
  // }, [state.companyId])

  useEffect(() => {
    if (depart) {
      showDesignation(state.companyId, depart)
    }
  }, [depart])

  const showDesignation = async (companyId, departmentId) => {
    setDesignation([])
    try {
    const response = await getalldesignation(companyId, departmentId)
      if (response) {
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x, i) => {
              return {
                S_no: i + 1,
                designationId: x._id,
                designationAbbreviation: x.abbreviation,
                designationCode: x.code,
                designationName: x.designationName,
                companyName: x.companyId.companyName,
                departmentName: x.departmentId.departmentName,
                reportingTo: x.reportingTo?.designationName ? x.reportingTo.designationName : '-',
                reportingToId: x.reportingTo?._id ? x.reportingTo._id : undefined,
                departmentId: x.departmentId._id,
              }
            })
            setDesignation(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const onDelete = async (companyId, departmentId, designationId) => {
    var response
    try {
      response = await designdelete(companyId, departmentId, designationId)
      if (response.success) {
        setDesignation(response)
        const data = designation.filter(
          (designation) => designation.designationId !== designationId,
        )
        showDesignation(state.companyId, depart, data)
        toast.success(response.message)
      } else {
        toast.error(response.error)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const columns = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'departmentName',
      _style: { width: '12%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'designationName',
      _style: { width: '12%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'designationAbbreviation',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'designationCode',
      _style: { width: '12%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'reportingTo',
      label: 'Reporting To Designation',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '10%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]

  return (
    <CContainer className="filterContainer filterContainer_New">
        <CSmartTable
          activePage={1}
          clickableRows
          columns={columns}
          columnFilter
          columnSorter
          items={designation}
          itemsPerPageSelect
          itemsPerPageLabel={'No of Rows'}
          itemsPerPage={5}
          pagination
          scopedColumns={{
            show_details: (item) => {
              return (
                <td className="gaponly">
                  <CButton
                    className="updateBtn"
                    onClick={() => {
                      updateDesignation(item)
                    }}
                  >
                    <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                  </CButton>
                  <CButton
                    className="deleteBtn"
                    onClick={() => {
                      setVisible(!visible)
                      settableDesignationName(item.designationName)
                      setTableDeleteId(item.designationId)
                      setTableDeleteIds(item.departmentId)
                    }}
                  >
                    <RiDeleteBinFill style={{ fontSize: '22px', color: '#ea4335' }} />
                  </CButton>
                </td>
              )
            },
          }}
          sorterValue={{ column: 'name', state: 'asc' }}
          tableProps={{
            striped: true,
            hover: true,
          }}
        />
      <>
        <CModal size="sm" alignment="center" visible={visible} onClose={() => setVisible(false)}>
          <CModalHeader>
            <div
              className="times"
              onClick={() => {
                setVisible(false)
              }}
            >
              &times;
            </div>
            <CModalTitle>
              <span>
                <CIcon icon={cilTask} className="me-2" />
              </span>
              Confirm
            </CModalTitle>
          </CModalHeader>
          <CModalBody className="loginModelBody"><span>
            Are you sure do you want to delete the <br />
           Designation Name : <b>{tableDesignationName}</b></span>
          </CModalBody>
          <CModalFooter>
            <button className="modelBtnNo" onClick={() => setVisible(false)}>
              No
            </button>
            <button
              className="modelBtnYes"
              onClick={() => {
                onDelete(state.companyId, tableDeleteIds, tableDeleteId)
                setVisible(false)
              }}
            >
              Yes
            </button>
          </CModalFooter>
        </CModal>
      </>
    </CContainer>
  )
}
