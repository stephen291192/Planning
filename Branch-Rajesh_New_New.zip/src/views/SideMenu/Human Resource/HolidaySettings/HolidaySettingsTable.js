import React, { useContext } from 'react'
import { ToastContainer, toast } from 'react-toastify'
import { useState, useEffect } from 'react'
import {
  CSmartTable,
  CBadge,
  CButton,
  CCollapse,
  CCardBody,
  CContainer,
  CCol,
  CRow,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { FaEdit } from "react-icons/fa";
import { RiDeleteBinFill } from 'react-icons/ri'
import { GlobalContext } from 'src/context'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import TableDropdown from 'src/views/forms/TableDropdown/TableDropdown'
import { getallHOLIDAY, holidaydelete } from 'src/services/ApiServices'

// eslint-disable-next-line react/prop-types
export const HolidaySettingsTable = ({ updateHoliday }) => {
  const [holiday, setHoliday] = useState([])
  const [visible, setVisible] = useState(false)
  const { state, dispatch } = useContext(GlobalContext)
  const [itemsPerPage, setItemsPerPage] = useState('20')

  const [tableDeleteId, setTableDeleteId] = useState('')
  const [tableDeleteId1, setTableDeleteId1] = useState('')

  useEffect(() => {
    showHoliday(state.companyId)
  }, [state.companyId])

  const deleteHoliday = async (companyId, holidayId) => {
    var response
    try {
      response = await holidaydelete(companyId, holidayId)
      if (response.success) {
        setHoliday(response)
        const data = holiday.filter(
          (holiday) => holiday.companyId !== companyId && holiday.holidayId !== holidayId,
        )
        showHoliday(state.companyId, data)
        toast.success(response.message)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const showHoliday = async (companyId) => {
    var response
    setHoliday([])
    try {
      response = await getallHOLIDAY(companyId)
      if (response) {
        if (response.success) {
          if (response.holidays) {
            const data = response.holidays.map((x, i) => {
              return {
                S_no: i + 1,
                Holiday_Type: x.holidayTypeId.holidayType,
                holidayDate:
                  x.holidayDate.length > 5 ? x.holidayDate.slice(0, 10) : new Date().getFullYear(),
                Holiday_Name: x.holidayName,
                holidayId: x._id,
                companyId: x.companyId,
              }
            })
            setHoliday(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const columns = [
    {
      key: 'S_no',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'Holiday_Type',
      label: 'Holiday Type',
      _style: { width: '18%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'holidayDate',
      label: 'Holiday Date',
      _style: { width: '22%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'Holiday_Name',
      label: 'Holiday Name',
      _style: { width: '22%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '10%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]
  return (
    <CContainer className="filterContainer filterContainer_New">
      {/* <div className="ItemsPerPage">
        <span className="pageid">No of Rows</span> &nbsp;
        <TableDropdown
          defaultValue={'20'}
          value={itemsPerPage}
          onChange={(value) => {
            setItemsPerPage(value)
          }}
        />
      </div> */}
      {/* <div className="TableDownload">
        <BsPrinter size={20} />
        <span className="tooltiptext">Print</span>
      </div> */}
      <CSmartTable
        activePage={1}
        // cleaner
        clickableRows
        columns={columns}
        columnFilter
        columnSorter
        // footer
        // onSorterChange={(value) => {
        //   console.log(value, 'COHDOSHOHOS')
        // }}
        // onTableFilterChange={(value) => {
        //   console.log(value, 'COHDOSHOHOS')
        // }}
        // onFilteredItemsChange={(value, secondProps) => {
        //   console.log(
        //     value,
        //     'COHDOSHOHOS 2',
        //     value.map((b, index) => ({ ...b, S_no: index + 1 })),
        //   )
        //   return value.map((b, index) => ({ ...b, S_no: index + 1 }))
        // }}
        // columnFilterValue={(value) => {
        //   console.log(value, 'COHDOSHOHOS 4')
        // }}
        // onColumnFilterChange={(value) => {
        //   console.log(value, 'COHDOSHOHOS 3')
        // }}
        // onChange={(value) => {
        //   console.log(value, 'COHDOSHOHOS 5')
        // }}
        items={holiday}
        itemsPerPageSelect
        itemsPerPageLabel={'No of Rows'}
        itemsPerPage={5}
        pagination
        scopedColumns={{
          show_details: (item) => {
            return (
              <td className="gaponly">
                <CButton
                  className="updateBtn"
                  onClick={() => {
                    updateHoliday(item)
                  }}
                >
                     <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                </CButton>
                {/* {JSON.stringify(item)} */}
                <CButton
                  className="deleteBtn"
                  onClick={() => {
                    setVisible(!visible)
                    setTableDeleteId(item.companyId)
                    setTableDeleteId1(item.holidayId)
                  }}
                >
                   <RiDeleteBinFill
                      style={{ fontSize: '22px', color: '#ea4335' }}
                    />
                </CButton>
               
              </td>
            )
          },
        }}
        sorterValue={{ column: 'name', state: 'asc' }}
        // tableFilter
        // tableHeadProps={{
        //   color: 'danger',
        // }}
        tableProps={{
          striped: true,
          hover: true,
        }}
      />
       <>
                  <CModal
                    size="sm"
                    alignment="center"
                    visible={visible}
                    onClose={() => setVisible(false)}
                  >
                    <CModalHeader>
                      <div
                        className="times"
                        onClick={() => {
                          setVisible(false)
                        }}
                      >
                        &times;
                      </div>
                      <CModalTitle>
                        <span>
                          <CIcon icon={cilTask} className="me-2" />
                        </span>
                        Confirm
                      </CModalTitle>
                    </CModalHeader>
                    <CModalBody className="loginModelBody">
                      Are you sure do you want to delete a current row.
                    </CModalBody>
                    <CModalFooter>
                      <button className="modelBtnNo" onClick={() => setVisible(false)}>
                        No
                      </button>
                      <button
                        className="modelBtnYes"
                        onClick={() => {
                          deleteHoliday(tableDeleteId, tableDeleteId1)
                          setVisible(false)
                        }}
                      >
                        Yes
                      </button>
                    </CModalFooter>
                  </CModal>
                </>
    </CContainer>
  )
}
