import React, { useEffect, useState, useContext } from 'react'
import {
  button,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormCheck,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CRow,
  CFormFeedback,
} from '@coreui/react'
import Select from 'react-select'
import { toast } from 'react-toastify'
import { HolidaySettingsTable } from './HolidaySettingsTable'
import { GlobalContext } from 'src/context'
import { addHoliday, getholidaytype, holidayUpdate } from 'src/services/ApiServices'

export const HolidaySettings = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [update, setupdate] = useState(false)

  const [addScreen, setAddScreen] = useState(true)
  const [holidayTypeId, setHolidayTypeId] = useState('')
  const [holidayId, setHolidayId] = useState(null)
  const [year, setYear] = useState('')
  const [holidayDate, setHolidayDate] = useState('')
  const [holidayName, setHolidayName] = useState('')
  const [holidayType, setHolidayType] = useState([])
  const [holiyError, setHoliyError] = useState('')
  useEffect(() => {
    showholidayTypes(state.companyId)
  }, [])

  const validateHoliy = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 6) {
      setHoliyError('Holiday Name should be 6 letters')
    } else {
      setHoliyError()
    }
  }

  var dateObj = new Date()
  var month = dateObj.getUTCMonth() + 1 //months from 1-12
  var day = dateObj.getUTCDate()
  var years = dateObj.getUTCFullYear()

  const showholidayTypes = async (companyId) => {
    var response
    setHolidayType([])
    try {
      response = await getholidaytype(companyId)
      if (response) {
        const data = response.holidayTypes.map((x) => {
          return {
            value: x._id,
            label: x?.holidayType,
          }
        })
        setHolidayType(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const updateHoliday = (data) => {
    setAddScreen(!addScreen)
    setupdate(true)

    setHolidayDate(data.holidayDate)
    setHolidayName(data.Holiday_Name)
    setHolidayType(data.Holiday_Type)
    showholidayTypes(state.companyId)
    setHolidayTypeId({
      value: data.holidayTypeId,
      label: data.Holiday_Type,
    })
    setHolidayId({
      value: data.holidayId,
      label: data.Holiday_Name,
    })
  }

  const saveHoliday = async () => {
    const data = {
      companyId: state.companyId,
      year: holidayDate.length > 5 ? holidayDate.slice(0, 4) : new Date().getFullYear(),
      holidayDate,
      holidayName,
      holidayTypeId: holidayTypeId.value,
    }
    try {
      const response = await addHoliday(data)
      if (response && response.success === true) {
        toast.success(response.message)
        setHolidayTypeId('')
        setHolidayDate('')
        setHolidayName('')
        setAddScreen(!addScreen)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const updatedesignation = async (companyId, holidayId) => {
    const data = {
      holidayDate,
      holidayName,
      holidayTypeId: holidayTypeId.value,
    }
    try {
      const response = await holidayUpdate(data, companyId, holidayId)
      if (response && response.success === true) {
        toast.success(response.message)
        setAddScreen(!addScreen)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }
  return (
    <div>
      {addScreen ? (
        <div>
          <div className="d-flex align-items-center justify-content-between">
            <div className="font_Title pt-2 pb-0 pr-2">List of holiday setting</div>
            <div>
              <button
                className="loginBtn mright loginBtn_New"
                onClick={() => {
                  setAddScreen(!addScreen)
                  setHolidayTypeId('')
                  setHolidayDate('')
                  setHolidayName('')
                  setupdate(false)
                }}
              >
                Add New
              </button>
            </div>
          </div>
          <CRow>
            <CCol xs={12} className="p-0">
              {/* <CCard className="mb-6">
                <span className="employeeHeader">
                  <h3 className="font_Title">LIST OF HOLIDAY SETTINGS</h3>
                </span>
                <CCardBody>
                  <button
                    className="loginBtn mright"
                    onClick={() => {
                      setAddScreen(!addScreen)
                      setHolidayTypeId('')
                      setHolidayDate('')
                      setHolidayName('')
                      setupdate(false)
                    }}
                  >
                    ADD
                  </button>
                  <br /> */}
              <HolidaySettingsTable updateHoliday={updateHoliday} />
              {/* </CCardBody> */}
              {/* </CCard> */}
            </CCol>
          </CRow>
        </div>
      ) : (
        <div>
          <CForm>
            <CRow>
              <CCol xs={12}>
                <span className="employeeHeader">
                  {update ? (
                    <h3 className="font_Title">update holiday setting</h3>
                  ) : (
                    <h3 className="font_Title">create holiday setting</h3>
                  )}
                </span>
                <CCard className="mb-6">
                  <CCardBody>
                    <CForm>
                      <CRow className="mb-3">
                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">Year</CFormLabel>
                          <CFormInput
                            type="text"
                            value={
                              holidayDate !== ''
                                ? holidayDate.slice(0, 4)
                                : new Date().getFullYear()
                            }
                            onChange={(e) => setYear(e.target.value)}
                            className="no-drop inputfieldgo"
                            disabled
                          />
                        </CCol>

                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">Holiday Type</CFormLabel>
                          <Select
                            isDisabled={update}
                            options={holidayType}
                            value={holidayTypeId}
                            className="inputfieldso"
                            onChange={(e) => {
                              setHolidayTypeId(e)
                            }}
                          />
                        </CCol>

                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">Holiday Date</CFormLabel>
                          <CFormInput
                            type="date"
                            disabled={!holidayTypeId}
                            name="Holiday Date"
                            className="inputfieldgo"
                            value={holidayDate}
                            min="1899-01-01"
                            max="2030-01-01"
                            onChange={(e) => {
                              setHolidayDate(e.target.value)
                            }}
                          />
                        </CCol>
                      </CRow>

                      <CRow className="mb-3">
                        <CCol sm={3}>
                          <CFormLabel className="col-form-label donlabel">Holiday Name</CFormLabel>
                          <CFormInput
                            type="text"
                            disabled={!holidayTypeId || !holidayDate}
                            className="inputfieldgo"
                            value={holidayName}
                            onChange={(e) => {
                              setHolidayName(e.target.value)
                              validateHoliy(e)
                            }}
                            placeholder="Holiday Name"
                          />
                          <span
                            style={{
                              fontWeight: '500',
                              fontSize: '12px',
                              color: 'red',
                            }}
                          >
                            {holiyError}
                          </span>
                        </CCol>
                      </CRow>
                      <div className="d-flex flex-row justify-content-end">
                        {update ? (
                          <div>
                            <button
                              className="loginBtn mright"
                              type="submit"
                              onClick={(e) => {
                                updatedesignation(state.companyId, holidayId.value)
                                e.preventDefault()
                              }}
                            >
                              Update
                            </button>
                          </div>
                        ) : (
                          <div>
                            <button
                              className="save mright"
                              disabled={
                                !holidayTypeId || !holidayDate || !holidayName || holiyError
                              }
                              type="submit"
                              onClick={(e) => {
                                saveHoliday()
                                e.preventDefault()
                              }}
                            >
                              save
                            </button>
                          </div>
                        )}
                        <div>
                          <button className="reset" onClick={() => setAddScreen(!addScreen)}>
                            cancel
                          </button>
                        </div>
                      </div>
                    </CForm>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
          </CForm>
        </div>
      )}
    </div>
  )
}
