import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  generateWeekMonthTaskReport,
  projectmaptable,
  roleTable,
  downloadAppraisalTodayPdf,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { TaskReportFunctions } from '../Report/TaskReportFunctions'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import momentBusinessDays from 'moment-business-days'

momentBusinessDays.updateLocale('us', {
  workingWeekdays: [1, 2, 3, 4, 5, 6],
})

export const MonthlyTaskReport = () => {
  const { state, dispatch } = useContext(GlobalContext)

  console.log(state, 'USER DATA')
  const [projectDrop, setProjectDrop] = useState([])
  const [projectValue, setProjectValue] = useState('')
  const [tableData, setTableData] = useState([])

  const [tableShow, setTableShow] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [date, setDate] = useState('')
  const [week, setWeek] = useState(false)
  const [month, setMonth] = useState(false)

  const [listData, setListData] = useState('')

  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [reportbtn, setreportbtn] = React.useState(false)
  const ref = React.createRef()

  const [startDate, setStartDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [holidayDates, setHolidayDates] = useState([])
  const [isDisabled, setIsDisabled] = useState(false)

  const [UniqueProData, setUniqueProData] = useState([])

  const openModal = () => {
    setIsOpen(true)
  }

  const closeModal = () => {
    setIsOpen(false)
  }

  const optionsans = {
    orientation: 'landscape',
  }

  const options = [
    { value: 'chocolate', label: 'yet to start' },
    { value: 'strawberry', label: 'In Progress' },
    { value: 'vanilla', label: 'Completed' },
    { value: 'hold', label: 'Hold' },
  ]

  const task = [
    { value: 'chocolateq', label: 'Daily' },
    { value: 'strawberryq', label: 'Weekly' },
    { value: 'vanillaq', label: 'Monthly' },
  ]

  const monthly = [
    { value: 'jan', label: 'January' },
    { value: 'feb', label: 'February' },
    { value: 'mar', label: 'March' },
    { value: 'apr', label: 'April' },
    { value: 'may', label: 'May' },
    { value: 'jun', label: 'June' },
    { value: 'jul', label: 'July' },
    { value: 'aug', label: 'August' },
    { value: 'sep', label: 'September' },
    { value: 'oct', label: 'October' },
    { value: 'nov', label: 'November' },
    { value: 'dec', label: 'December' },
  ]

  const taskChange = (e) => {
    if (e.value === 'chocolateq') {
      setTableShow(true)
      setreportbtn(true)
      setWeek(false)
      setMonth(false)
    }
    if (e.value === 'strawberryq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(true)
      setMonth(false)
    }
    if (e.value === 'vanillaq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(false)
      setMonth(true)
    }
  }

  //   useEffect(() => {
  //     selectProject(state.employeeId._id)
  //   }, [])

  //   const selectProject = async (employeeId) => {
  //     var response
  //     try {
  //       response = await projectmaptable(employeeId)
  //       if (response) {
  //         const data = response.data.projects.map((x) => {
  //           return {
  //             value: x._id,
  //             label: x.projectName,
  //           }
  //         })
  //         setProjectDrop(data)
  //       }
  //     } catch (err) {
  //       if (err.response) {
  //         if (err.response.data && err.response.data.success == false) {
  //           toast.error(err.response.data.error)
  //         }
  //       } else if (err.request) {
  //         toast.error('No Internet')
  //       } else {
  //         toast.error('Something Went Wrong' + err)
  //       }
  //     }
  //   }

  function disableWeekends(date) {
    let day = new Date(date)
    day = day.getDay()
    return day !== 0
  }

  const dateDurationFuc = async (data, date1, dates, k) => {
    while (date1.length > 0) {
      let date = await dates
      date1 = await data.filter((x) => {
        if (moment(moment(date).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      if (date1.length > 0) {
        date = await momentBusinessDays(date).businessAdd(1)._d
      }
      dates = await date
    }
    return dates
  }

  const dateDuration = async (date, duration, data) => {
    let i = 0
    while (i < Number(duration)) {
      let dates = await date
      let k = i + 1
      let date1 = await data.filter(async (x) => {
        dates = await momentBusinessDays(dates).businessAdd(1)._d
        if (moment(moment(dates).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      console.log(date1.length)
      if (date1.length > 0) {
        dates = await dateDurationFuc(data, date1, dates, k)
      }
      i = i + 1
      date = await dates
    }
    return date
  }

  const selectDateFuc = async (date) => {
    if (date) {
      setStartDate(date)
      taskTable(moment(date).format('YYYY-MM-DD'), moment(date).endOf('month').format('YYYY-MM-DD'))
      // getContentFuc(
      //     companyId,
      //     bookType._id,
      //     country._id,
      //     institution._id,
      //     tier._id,
      //     moment(date).format("DD-MM-YYYY"),
      //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
      // );
    }
  }

  const initalColumn = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '2%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'project',
      label: 'Project',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
  ]

  const RemainingInitialColumn = [
    {
      key: 'TodayActivity',
      label: 'Activity',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'StartDate',
      label: 'Est. Start Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EndDate',
      label: 'Est. End Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    // {
    //   key: 'EstimatedStartTime',
    //   label: 'Est. Start Time',
    //   _style: { width: '18%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'EstimatedEndTime',
    //   label: 'Est. End Time',
    //   _style: { width: '17%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'plannedduration',
    //   label: 'Est. Duration (Mins)',
    //   _style: { width: '10%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
  ]

  const [columns, setColumns] = useState(initalColumn)
  const [DataReport, setDataReport] = useState([])

  const getMostFuncTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.functionalTierDetails.length > max) {
        max = item.functionalTierDetails.length
        maxObj = [item]
      } else if (item.functionalTierDetails.length === max) {
        maxObj.push(item)
      }
    })

    return maxObj
  }

  const getMostTechTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.technicalTierDetails !== null) {
        if (item.technicalTierDetails.length > max) {
          max = item.technicalTierDetails.length
          maxObj = [item]
        } else if (item.technicalTierDetails.length === max) {
          maxObj.push(item)
        }
      }
    })

    return maxObj
  }

  const taskTable = async (FromDate, ToDate) => {
    setTableData([])
    setUniqueProData([])
    const data = {
      //   projectId: [projectValue.value],
      employeeId: state.employeeId._id,
      fromDate: FromDate,
      toDate: ToDate,
    }
    try {
      const response = await generateWeekMonthTaskReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            // console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProData(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProData([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const tConvertDate = (date) => {
    var RDate = date.split('T')[0]
    var RDate = moment(RDate).format('DD MMM YYYY')
    return RDate // return adjusted time or original string
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  const onClickDownloadFuc = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProData.length > 0) {
      UniqueProData.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:15px;">
        Project: ${x.projectId.projectName}
        </h4>`
        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:15px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`
            console.log(z, 'UUUUUUUUUUUUUUUUUUUUUUU')
            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            // z.functionalTierDetails.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //       padding: 5px;font-size:9px;
            //       text-align: center;
            //       background-color: #3c4b64;
            //       color: white;" class="tableHeader">${x.value}</th>`

            //   return data
            // })

            // getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
            //   .length > 0 &&
            //   getMostTechTiers(
            //     DataReport.filter((item) => item.projectId._id === x.projectId._id),
            //   )[0].technicalTierDetails.map(async (x, i) => {
            //     data =
            //       data +
            //       `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //       padding: 5px;font-size:9px;
            //       text-align: center;
            //       background-color: #3c4b64;
            //       color: white;" class="tableHeader">${x.value}</th>`

            //     return data
            //   })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Functional Requirements</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:12px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Technical Requirements</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Task Description</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:12px;width:5%;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Start Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:12px;width:5%;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">End Date</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
              padding: 5px;" >`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `${
                    x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                      ? `${
                          x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                            .variableName
                        }, `
                      : ''
                  }`

                if (z.functionalTierDetails.length === i + 1) {
                  data = data + `${dDesc.innerText}`
                }

                return data
              })

              data = data + `</td>`

              //       data =
              //         data +
              //         `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
              // padding: 5px;" >`

              //       z.functionalTierDetails.map(async (y, i) => {
              //         data =
              //           data +
              //           `${
              //             x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
              //               ? `${y.value} - ${
              //                   x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
              //                     .variableName
              //                 }, `
              //               : ''
              //           }`

              //         data = data + `<br>`

              //         if (z.functionalTierDetails.length === i + 1) {
              //           data = data + `${dDesc.innerText}`
              //         }

              //         return data
              //       })

              //       data = data + `</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
            padding: 5px;" >`

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `${
                      x.technicalVariableDetails === null
                        ? ''
                        : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                            .length === 0
                        ? ''
                        : `${
                            x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                              ?.variableName
                          }${
                            getMostTechTiers(
                              DataReport.filter((item) => item.projectId._id === x.projectId._id),
                            )[0].technicalTierDetails.length ===
                            i + 1
                              ? ''
                              : ', '
                          }`
                    }`

                  return data
                })

              data = data + `</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
            padding: 5px;" >`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `${
                    x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                      ? `${
                          x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                            .variableName
                        }, `
                      : ''
                  }`

                if (z.functionalTierDetails.length === i + 1) {
                  data = data + `${dDesc.innerText}, `
                }

                return data
              })

              // data = data + `${dDesc.innerText}`

              if (
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                ).length > 0
              ) {
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                ).length > 0 &&
                  getMostTechTiers(
                    DataReport.filter((item) => item.projectId._id === x.projectId._id),
                  )[0].technicalTierDetails.map(async (z, i) => {
                    data =
                      data +
                      `${
                        x.technicalVariableDetails === null
                          ? ''
                          : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                              .length === 0
                          ? ''
                          : `${
                              x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                                ?.variableName
                            }${
                              getMostTechTiers(
                                DataReport.filter((item) => item.projectId._id === x.projectId._id),
                              )[0].technicalTierDetails.length ===
                              i + 1
                                ? ''
                                : ', '
                            }`
                      }`

                    return data
                  })
              }

              data = data + `</td>`

              //       data =
              //         data +
              //         `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              //   padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '18px',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Project Management Software
              </p>
              <p
                style={{
                  fontSize: '18px',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment(startDate).format('MMMM')} Month - Task Report of {state.firstName}{' '}
                {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_MonthlyTaskReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
            <CCard className="mb-6">
              <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">Monthly Task Report</h3>
                </div>
              </div>
              <CCardBody>
                <CForm>
                  <CRow className="mb-3">
                    {/* <CRow className="col-sm-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Project Name <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <Select
                          className={'inputfieldso'}
                          options={projectDrop}
                          value={projectValue}
                          onChange={(e) => {
                            setProjectValue(e)
                            setStartDate('')
                            setToDate('')
                            setTableData([])
                          }}
                          placeholder="Project Name"
                        />
                      </CCol>
                    </CRow> */}
                    <CRow className="col-sm-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Select Month <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <DatePicker
                          placeholderText={'Select the month'}
                          dateFormat={'MM/yyyy'}
                          selected={startDate && startDate}
                          onChange={(date) => {
                            selectDateFuc(date)
                          }}
                          customInput={
                            <CFormInput
                              style={{ width: '700px !important' }}
                              value={startDate}
                            ></CFormInput>
                          }
                          showMonthYearPicker
                        />
                      </CCol>
                    </CRow>
                  </CRow>
                </CForm>
              </CCardBody>
              <CCardBody>
                <CForm>
                  <div>
                    <CRow className="">
                      <div>
                        {startDate && UniqueProData.length > 0 ? (
                          <h3
                            className="escols"
                            style={{ textAlign: 'center', padding: '10px 20px' }}
                          >
                            Monthly Task Report for the Month of{' '}
                            {moment(startDate).format('MMMM YYYY')}
                          </h3>
                        ) : null}
                      </div>
                      <div className="d-flex flex-row justify-content-end mb-3">
                        {UniqueProData.length > 0 ? (
                          <div>
                            <button
                              className="loginBtn1 mright"
                              type="submit"
                              // onClick={(e) => {
                              //   openModal()
                              //   e.preventDefault()
                              // }}
                              onClick={() => onClickDownloadFuc()}
                              disabled={isDisabled}
                            >
                              Download Report
                            </button>
                          </div>
                        ) : null}
                      </div>
                      {UniqueProData.map((x, i) => {
                        return (
                          <TaskReportFunctions
                            key={i}
                            projectId={x.projectId._id}
                            projectName={x.projectId.projectName}
                            projectReportData={DataReport.filter(
                              (item) => item.projectId._id === x.projectId._id,
                            )}
                            // funcTiersData={getMostFuncTiers(
                            //   DataReport.filter((item) => item.projectId._id === x.projectId._id),
                            // )}
                            techTiersData={getMostTechTiers(
                              DataReport.filter((item) => item.projectId._id === x.projectId._id),
                            )}
                            funcTiersData={[
                              ...new Map(
                                DataReport.filter(
                                  (item) => item.projectId._id === x.projectId._id,
                                ).map((item123) => [item123.functionalAttributeId._id, item123]),
                              ).values(),
                            ]}
                          />
                        )
                      })}
                    </CRow>
                  </div>

                  {/* Modal for Pdf Downloader */}
                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
