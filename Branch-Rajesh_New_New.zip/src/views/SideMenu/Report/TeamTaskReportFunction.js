/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  TaskReportGenerate,
  projectmaptable,
  roleTable,
  downloadAppraisalTodayPdf,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { toast } from 'react-toastify'
import { TeamTaskReportView } from '../Report/TeamTaskReportView'

import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'

export const TeamTaskReportFunction = ({
  projectId,
  projectName,
  projectReportData,
  funcTiersData,
  techTiersData,
}) => {
  const { state, dispatch } = useContext(GlobalContext)

  const [tableData, setTableData] = useState([])

  useEffect(() => {
    taskTable()
  }, [])

  const initalColumn = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-bold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'project',
      label: 'Project',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-bold' },
      filter: true,
      sorter: false,
    },
  ]


  const [columns, setColumns] = useState(initalColumn)
  const [DataReport, setDataReport] = useState([])
  const [FunctionsData, setFunctionsData] = useState([])

  const taskTable = async () => {
    setTableData([])

    if (projectReportData.length > 0) {
 

      const funcsunique = [
        ...new Map(
          funcTiersData.map((item123) => [item123.functionalAttributeId._id, item123]),
        ).values(),
      ]
      // console.log(unique, 'REPORT DATA VALUES')
      setFunctionsData(funcsunique)

      console.log(funcsunique, 'PROJECT DATA')

    } else {
      //   toast.error(response.error)
    }
  }

  const tConvertDate = (date) => {
    var RDate = date.split('T')[0]
    var RDate = moment(RDate).format('DD MMM YYYY')
    return RDate // return adjusted time or original string
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  const onClickDownloadFuc = async () => {
    // setIsDisabled(true);
    let data = '',
      header = ''
    // let ti = 1;
    if (DataReport.length > 0) {
      data = data + `<table style="width:100%;">`

      columns.map(async (x, i) => {
        data =
          data +
          `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">${x.label}</th>`

        return data
      })

      console.log(columns, 'PDF REPORT DATA')

      // let jii = 0;

      DataReport.map(async (x, i) => {
        data = data + '<tr>'
        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`
        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${x.projectId.projectName}</td>`

        x.functionalVariableDetails.map(async (x, i) => {
          data =
            data +
            `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${x.variableName}</td>`
        })

        x.technicalVariableDetails.map(async (x, i) => {
          data =
            data +
            `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.variableName}</td>`
        })

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${x.description}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`

          // data =
          // data +
          // `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          // padding: 5px;" >${tConvertDate(x.label)}</td>`

        // data =
        //   data +
        //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
        //   padding: 5px;" >${tConvert(x.est)}</td>`

        // data =
        //   data +
        //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
        //   padding: 5px;" >${tConvert(x.eft)}</td>`

        // data =
        //   data +
        //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
        //   padding: 5px;" >${String(x.plannedDuration)}</td>`

        return data
      })

      console.log(DataReport, 'PDF REPORT DATA')

      data = data + `</table>`
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment().format('DD MMM YYYY')} Detailed Today Task Report of {state.firstName}{' '}
                {state.lastName}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_TodaySelfTaskReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        // setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      {FunctionsData.map((x, i) => {
        return (
          <TeamTaskReportView
            key={i}
            projectId={projectId}
            projectName={projectName}
            projectReportData={projectReportData}
            funcTiersData={x}
            techTiersData={techTiersData}
            funcAttrId={x.functionalAttributeId._id}
          />
        )
      })}
      {/* <CForm style={{ marginBottom: '20px' }}>
        <CRow>
          <CCol xs={12}>
            <CCard className="mb-6">
              <CCardBody>
                <CForm>
                  <div>
                    <CRow className="">
                      <div>
                        {tableData.length > 0 ? (
                          <h3
                            className="escols"
                            style={{ textAlign: 'center', padding: '10px 20px' }}
                          >
                            {projectName}
                          </h3>
                        ) : null}
                      </div>
                      {tableData.length > 0 && (
                        <CTable
                          bordered
                          responsive
                          activePage={1}
                          clickableRows
                          columns={columns}
                          columnFilter
                          columnSorter
                          items={tableData}
                          scopedColumns={{}}
                          sorterValue={{ column: 'name', state: 'asc' }}
                          tableProps={{
                            striped: true,
                            hover: true,
                            responsive: true,
                          }}
                        />
                      )}
                    </CRow>
                  </div>
                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CForm> */}
    </div>
  )
}
