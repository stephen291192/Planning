import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  generateReport,
  projectmaptable,
  roleTable,
  downloadAppraisalTodayPdf,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'

export const TodayReportAppraisel = () => {
  const { state, dispatch } = useContext(GlobalContext)

  console.log(state, 'USER DATA')
  const [projectDrop, setProjectDrop] = useState([])
  const [projectValue, setProjectValue] = useState('')
  const [tableData, setTableData] = useState([])

  const [tableShow, setTableShow] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [date, setDate] = useState('')
  const [week, setWeek] = useState(false)
  const [month, setMonth] = useState(false)

  const [listData, setListData] = useState('')

  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [reportbtn, setreportbtn] = React.useState(false)
  const [isDisabled, setIsDisabled] = useState(false)
  const ref = React.createRef()

  const openModal = () => {
    setIsOpen(true)
  }

  const closeModal = () => {
    setIsOpen(false)
  }

  const optionsans = {
    orientation: 'landscape',
  }

  const options = [
    { value: 'chocolate', label: 'yet to start' },
    { value: 'strawberry', label: 'In Progress' },
    { value: 'vanilla', label: 'Completed' },
    { value: 'hold', label: 'Hold' },
  ]

  const task = [
    { value: 'chocolateq', label: 'Daily' },
    { value: 'strawberryq', label: 'Weekly' },
    { value: 'vanillaq', label: 'Monthly' },
  ]

  const monthly = [
    { value: 'jan', label: 'January' },
    { value: 'feb', label: 'February' },
    { value: 'mar', label: 'March' },
    { value: 'apr', label: 'April' },
    { value: 'may', label: 'May' },
    { value: 'jun', label: 'June' },
    { value: 'jul', label: 'July' },
    { value: 'aug', label: 'August' },
    { value: 'sep', label: 'September' },
    { value: 'oct', label: 'October' },
    { value: 'nov', label: 'November' },
    { value: 'dec', label: 'December' },
  ]

  const taskChange = (e) => {
    if (e.value === 'chocolateq') {
      setTableShow(true)
      setreportbtn(true)
      setWeek(false)
      setMonth(false)
    }
    if (e.value === 'strawberryq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(true)
      setMonth(false)
    }
    if (e.value === 'vanillaq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(false)
      setMonth(true)
    }
  }

  useEffect(() => {
    taskTable()
  }, [])

  const initalColumn = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'project',
      label: 'Project',
      _style: { width: '15%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
  ]

  const RemainingInitialColumn = [
    {
      key: 'TodayActivity',
      label: 'Activity',
      _style: { width: '15%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EstimatedDate',
      label: 'Est. Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EstimatedTime',
      label: 'Est. Time',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'LastDate',
      label: 'Actual Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'ActualTime',
      label: 'Act. Time',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    // {
    //   key: 'plannedduration',
    //   label: 'Planned Duration (Mins)',
    //   _style: { width: '10%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'EstimatedStartDate',
    //   label: 'Est. Start Time',
    //   _style: { width: '18%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'EstimatedEndDate',
    //   label: 'Est. End Time',
    //   _style: { width: '17%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'actualduration',
    //   label: 'Actual Duration (Mins)',
    //   _style: { width: '14%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'actualStartDate',
    //   label: 'Actual Start Time',
    //   _style: { width: '12%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'actualEndDate',
    //   label: 'Actual End Time',
    //   _style: { width: '12%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'differenceBetweenTwoDuration',
    //   label: 'Duration Difference (Mins)',
    //   _style: { width: '12%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    {
      key: 'status',
      label: 'Status',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'summary',
      label: 'Summary',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
  ]

  const [columns, setColumns] = useState(initalColumn)
  const [DataReport, setDataReport] = useState([])

  const taskTable = async () => {
    setTableData([])
    let today = new Date().toISOString().slice(0, 10)
    const data = {
      date: today,
    }
    try {
      const response = await generateReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            const InterMediateColumn = response.data.map((x, i) => {
              const functionColumnName = x.functionalTierDetails.map((y, i) => {
                return {
                  key: y._id,
                  label: y.value,
                  _style: { width: '10%' },
                  _props: { color: '#fff', className: 'fw-semibold' },
                  filter: true,
                  sorter: false,
                }
              })

              const TierColumnName = x.technicalTierDetails.map((y, i) => {
                return {
                  key: y._id,
                  label: y.value,
                  _style: { width: '10%' },
                  _props: { color: '#fff', className: 'fw-semibold' },
                  filter: true,
                  sorter: false,
                }
              })

              return [...functionColumnName, ...TierColumnName]
            })
            console.log(InterMediateColumn, 'COLUMN VALUES')
            const getInterMediateColumn = getValue(InterMediateColumn[0], TYPES.ARRAY, [])
            console.log(getInterMediateColumn, 'COLUMN VALUES')
            setColumns([...initalColumn, ...getInterMediateColumn, ...RemainingInitialColumn])
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')

            const data = response.data.map((x, i) => {
              let functionalVariableDetailsObject = {}
              let technicalVariableDetailsObject = {}
              const functionalVariableDetailsValues = x.functionalVariableDetails.map((y, i) => {
                functionalVariableDetailsObject[getValue(y.tierId, TYPES.STRING, '')] = getValue(
                  y.variableName,
                  TYPES.STRING,
                  '',
                )
              })

              const technicalVariableDetailsValues = x.technicalVariableDetails.map((y, i) => {
                technicalVariableDetailsObject[getValue(y.tierId, TYPES.STRING, '')] = getValue(
                  y.variableName,
                  TYPES.STRING,
                  '',
                )
              })

              return {
                S_no: i + 1,
                project: x.projectId.projectName,
                functionalattributeName: `${
                  x.functionalAttributeId.attributeName
                } - ${x.functionalVariableDetails.map((x) => x.variableName)} `,
                technicalattributeName: `${
                  x.technicalAttributeId.attributeName
                } - ${x.technicalVariableDetails.map((x) => x.variableName)} `,
                TodayActivity: x.description,
                EstimatedDate: tConvertDate(x.efd),
                EstimatedTime: `${x.est} - ${x.eft}`,
                LastDate: tConvertDate(x.lfd),
                ActualTime: `${x.ast} - ${x.aft}`,
                // plannedduration: String(x.plannedDuration),
                // EstimatedStartDate: tConvert(x.est),
                // EstimatedEndDate: tConvert(x.eft),
                // actualduration: String(x.actualDuration),
                // actualStartDate: tConvert(x.ast),
                // actualEndDate: tConvert(x.aft),
                // differenceBetweenTwoDuration: String(
                //   Number(x.actualDuration) - Number(x.plannedDuration),
                // ),
                status: x.Status,
                summary: x.remark,
                label: `${x.employeeId.firstName} ${x.employeeId.lastName}`,
                ...functionalVariableDetailsObject,
                ...technicalVariableDetailsObject,
              }
            })
            console.log(data, 'DJSJDS')

            setTableData(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const tConvertDate = (date) => {
    // alert(date)
    console.log(date, 'FORMAT DATE')
    if (date !== undefined && date !== '' && date !== null) {
      var RDate = date.split('T')[0]
      var RDate = moment(RDate).format('DD MMM YYYY')
      return RDate // return adjusted time or original string
    } else {
      return 'NULL'
    }
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  const onClickDownloadFuc = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (DataReport.length > 0) {
      data = data + `<table style="width:100%;">`

      columns.map(async (x, i) => {
        data =
          data +
          `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">${x.label}</th>`

        return data
      })

      console.log(columns, 'PDF REPORT DATA')

      // let jii = 0;

      DataReport.map(async (x, i) => {
        data = data + '<tr>'
        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`
        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${x.projectId.projectName}</td>`

        x.functionalVariableDetails.map(async (x, i) => {
          data =
            data +
            `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${x.variableName}</td>`
        })

        x.technicalVariableDetails.map(async (x, i) => {
          data =
            data +
            `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.variableName}</td>`
        })

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${x.description}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvert(x.est)} - ${tConvert(x.eft)}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${tConvertDate(x.lfd)}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;  width:5%; text-align: center;
          padding: 5px;" >${tConvert(x.ast)} - ${tConvert(x.aft)}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.Status}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.remark}</td>`

        return data
      })

      console.log(DataReport, 'PDF REPORT DATA')

      data = data + `</table>`
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment().format('DD MMM YYYY')} Detailed Today Appraisal Report of{' '}
                {state.firstName} {state.lastName}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_TodaySelfAppraisal_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
            <CCard className="mb-6">
              <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">Appraisal Report</h3>
                </div>
              </div>
              <CCardBody>
                <CForm>
                  <div>
                    <CRow className="">
                      <div>
                        {tableData.length > 0 ? (
                          <h3
                            className="escols"
                            style={{ textAlign: 'center', padding: '10px 20px' }}
                          >
                            Todays Appraisal Report - {moment().format('DD MMM YYYY')}
                          </h3>
                        ) : null}
                      </div>
                      <div className="d-flex flex-row justify-content-end mb-3">
                        {tableData.length > 0 ? (
                          <div>
                            <button
                              className="loginBtn1 mright"
                              type="submit"
                              // onClick={(e) => {
                              //   openModal()
                              //   e.preventDefault()
                              // }}
                              onClick={(e) => {
                                e.preventDefault()
                                onClickDownloadFuc()
                              }}
                              disabled={isDisabled}
                            >
                              Download Report
                            </button>
                          </div>
                        ) : null}
                      </div>
                      {tableData.length > 0 ? (
                        <CTable
                          bordered
                          responsive
                          activePage={1}
                          clickableRows
                          columns={columns}
                          columnFilter
                          columnSorter
                          items={tableData}
                          scopedColumns={{
                            show_details: (item) => {
                              return (
                                <td>
                                  <Select
                                    defaultValue={options[0]}
                                    onChange={setListData}
                                    options={options}
                                    className={'inputfieldso txtransform'}
                                  />
                                </td>
                              )
                            },
                            // EstimatedStartDate: (start) => {
                            //   return (
                            //     <td>
                            //       <CFormInput type="date" className="inputfieldgo" />
                            //     </td>
                            //   )
                            // },
                            // EstimatedEndDate: (start) => {
                            //   return (
                            //     <td>
                            //       <CFormInput type="date" className="inputfieldgo" />
                            //     </td>
                            //   )
                            // },
                          }}
                          sorterValue={{ column: 'name', state: 'asc' }}
                          tableProps={{
                            striped: true,
                            hover: true,
                            responsive: true,
                          }}
                        />
                      ) : (
                        <h3 className="center">NO DATA FOUND</h3>
                      )}
                    </CRow>
                  </div>

                  {/* Modal for Pdf Downloader */}
                  <React.Fragment>
                    <CModal
                      size="xl"
                      visible={modalIsOpen}
                      onClose={() => {
                        closeModal()
                      }}
                    >
                      <ReactToPdf targetRef={ref} options={optionsans} filename="Report.pdf">
                        {({ toPdf }) => (
                          <div className="PdfButton">
                            <button
                              onClick={() => {
                                toPdf()
                                closeModal()
                              }}
                              className="pdfbtnsDwn"
                            >
                              Download <ImDownload3 size="15" />
                            </button>
                          </div>
                        )}
                      </ReactToPdf>
                      <div id="printablediv">
                        <div ref={ref}>
                          {console.log(state.companyLogo)}
                          {/* <div>
              
            </div> */}

                          <div className="PdfTableHeader">
                            {state?.companyLogo !== '' && (
                              <img src={state.companyLogo} alt="" className="LogoPDFPicture" />
                            )}
                            <div className="d-flex flex-column">
                              <h3 className="pdfModelTitle">
                                {state.companies.find((x) => x.value == state.companyId)?.label}
                              </h3>
                              <h6 className="retporttabledetail">
                                Detailed Today Appraisal Report of {state.userName}
                              </h6>
                            </div>
                            <div></div>
                          </div>

                          <div className="d-flex flex-row justify-content-around mt-5">
                            {/* <div>
                              {' '}
                              <span className="subhead">User Login:</span>{' '}
                              <span className="username">{state.userName}</span>
                            </div> */}
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div>
                              <span className="subhead">Date:</span>
                              <span className="username">
                                {new Date().toLocaleDateString('en-us', {
                                  // weekday: 'short',
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric',
                                })}
                              </span>
                            </div>
                          </div>

                          <div className="PdfTable">
                            <CTable
                              bordered
                              responsive
                              // itemsPerPageSelect
                              // activePage={1}
                              // cleaner
                              clickableRows
                              columns={columns.filter((x) => x.label != 'Action')}
                              // columnFilter
                              // columnSorter

                              items={tableData}
                              itemsPerPage={Number(itemsPerPage)}
                              sorterValue={{ column: 'name', state: 'asc' }}
                              tableProps={{
                                striped: true,
                                hover: true,
                              }}
                              className="repottable"
                            />
                          </div>
                        </div>
                      </div>
                    </CModal>
                  </React.Fragment>
                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
