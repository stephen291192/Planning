import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  generateWeeklyAppraiselReport,
  roleTable,
  downloadAppraisalTodayPdf,
  generateReport,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { AppraisalReportFunctions } from '../Report/AppraisalReportFunctions'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import momentBusinessDays from 'moment-business-days'

momentBusinessDays.updateLocale('us', {
  workingWeekdays: [1, 2, 3, 4, 5, 6],
})

export const MonthlyAppraiselReport = () => {
  const { state, dispatch } = useContext(GlobalContext)

  console.log(state, 'USER DATA')
  const [projectDrop, setProjectDrop] = useState([])
  const [projectValue, setProjectValue] = useState('')
  const [tableData, setTableData] = useState([])

  const [tableShow, setTableShow] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [date, setDate] = useState('')
  const [week, setWeek] = useState(false)
  const [month, setMonth] = useState(false)

  const [listData, setListData] = useState('')

  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [reportbtn, setreportbtn] = React.useState(false)
  const ref = React.createRef()

  const [startDateM, setStartDateM] = useState('')
  const [startDate, setStartDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [startDateper, setStartDateper] = useState('')
  const [toDatePer, setToDatePer] = useState('')
  const [holidayDates, setHolidayDates] = useState([])
  const [isDisabled, setIsDisabled] = useState(false)
  const [UniqueProData, setUniqueProData] = useState([])
  const [UniqueProDataWeek, setUniqueProDataWeek] = useState([])
  const [UniqueProDataTod, setUniqueProDataTod] = useState([])
  const [UniqueProDataperiod, setUniqueProDataperiod] = useState([])

  const dateDurationFuc = async (data, date1, dates, k) => {
    while (date1.length > 0) {
      let date = await dates
      date1 = await data.filter((x) => {
        if (moment(moment(date).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      if (date1.length > 0) {
        date = await momentBusinessDays(date).businessAdd(1)._d
      }
      dates = await date
    }
    return dates
  }

  const dateDuration = async (date, duration, data) => {
    let i = 0
    while (i < Number(duration)) {
      let dates = await date
      let k = i + 1
      let date1 = await data.filter(async (x) => {
        dates = await momentBusinessDays(dates).businessAdd(1)._d
        if (moment(moment(dates).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      console.log(date1.length)
      if (date1.length > 0) {
        dates = await dateDurationFuc(data, date1, dates, k)
      }
      i = i + 1
      date = await dates
    }
    return date
  }

  const selectDateFuc = async (date) => {
    if (date) {
      setStartDateM(date)
      taskTable(moment(date).format('YYYY-MM-DD'), moment(date).endOf('month').format('YYYY-MM-DD'))
      // getContentFuc(
      //     companyId,
      //     bookType._id,
      //     country._id,
      //     institution._id,
      //     tier._id,
      //     moment(date).format("DD-MM-YYYY"),
      //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
      // );
    }
  }

  const [DataReport, setDataReport] = useState([])

  const getMostFuncTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.functionalTierDetails.length > max) {
        max = item.functionalTierDetails.length
        maxObj = [item]
      } else if (item.functionalTierDetails.length === max) {
        maxObj.push(item)
      }
    })

    return maxObj
  }

  const getMostTechTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.technicalTierDetails !== null) {
        if (item.technicalTierDetails.length > max) {
          max = item.technicalTierDetails.length
          maxObj = [item]
        } else if (item.technicalTierDetails.length === max) {
          maxObj.push(item)
        }
      }
    })

    return maxObj
  }

  const taskTable = async (FromDate, ToDate) => {
    setTableData([])
    const data = {
      employeeId: state.employeeId._id,
      fromDate: FromDate,
      toDate: ToDate,
    }
    try {
      const response = await generateWeeklyAppraiselReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            console.log(unique, 'REPORT DATA VALUES')
            setUniqueProData(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'REPORT DATA VALUES')
          }
          // toast.success(response.message)
        } else {
          setUniqueProData([])
          setDataReport([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const tConvertDate = (date) => {
    // alert(date)
    console.log(date, 'FORMAT DATE')
    if (date !== undefined && date !== '' && date !== null) {
      var RDate = date.split('T')[0]
      var RDate = moment(RDate).format('DD MMM YYYY')
      return RDate // return adjusted time or original string
    } else {
      return 'NULL'
    }
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  const onClickDownloadFuctod = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProDataTod.length > 0) {
      UniqueProDataTod.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`

        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        // data = data + `<h4 style="font-family:arial;text-align:right;">Reporting To : ${k.contentDeveloperId.reportingTo.userName}</h4>`;
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                        padding: 5px;font-size:9px;
                        text-align: center;
                        background-color: #3c4b64;
                        color: white;" class="tableHeader">Act. Finish Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Act. Finish Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                            padding: 5px;font-size:9px;
                            text-align: center;
                            background-color: #3c4b64;
                            color: white;" class="tableHeader">Status</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">Summary</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Img/Video/File</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Code URL</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              console.log(tConvertDate(x.lsd), tConvertDate(x.lfd), 'WWWWWWWWWWWWWWWWWWWWWWWWWW')

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)} - ${tConvertDate(x.efd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.est} - ${x.eft}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${
            x.lfd === undefined
              ? tConvertDate(x.lsd)
              : tConvertDate(x.lsd) + ' - ' + tConvertDate(x.lfd)
          }</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.ast} - ${x.aft}</td>`

              //   data =
              //     data +
              //     `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(Number(x.actualDuration) - Number(x.plannedDuration))}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.Status}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.remark}</td>`

              if (x?.fileType && x?.fileType === 'image/png') {
                //       data =
                //         data +
                //         `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                // padding: 5px;" ><img src=${x.fileurl} style="width:50px;height:50px;" /></td>`
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >
                <a href=${x.fileurl} target="_blank">
                <img src=${x.fileurl} style="width:50px;height:50px;" />
                </a>
          </td>`
              } else if (x?.fileType && x?.fileType === 'video/mp4') {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ><a target="_blank" href=${x.fileurl}>View Video</a></td>`
              } else if (
                x?.fileType &&
                x?.fileType !== 'video/mp4' &&
                x?.fileType !== 'image/png'
              ) {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ><a target="_blank" href=${x.fileurl}>View Document</a></td>`
              } else {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" > - </td>`
              }

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ><a target="_blank" href=${x.codeurl}>View Code</a></td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment().format('DD MMM YYYY')} Detailed Today Appraisal Report of{' '}
                {state.firstName} {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuctiontod(data, htmlToConvert)
    }
  }

  const downloadFuctiontod = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `AppraisalReport_${moment().format('DD_MM_YYYY')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  const onClickDownloadFucweek = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProDataWeek.length > 0) {
      UniqueProDataWeek.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`

        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        // data = data + `<h4 style="font-family:arial;text-align:right;">Reporting To : ${k.contentDeveloperId.reportingTo.userName}</h4>`;
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                        padding: 5px;font-size:9px;
                        text-align: center;
                        background-color: #3c4b64;
                        color: white;" class="tableHeader">Act. Finish Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Act. Finish Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                            padding: 5px;font-size:9px;
                            text-align: center;
                            background-color: #3c4b64;
                            color: white;" class="tableHeader">Status</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">Summary</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)} - ${tConvertDate(x.efd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.est} - ${x.eft}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${
            x.lfd === undefined
              ? tConvertDate(x.lsd)
              : tConvertDate(x.lsd) + ' - ' + tConvertDate(x.lfd)
          }</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.ast} - ${x.aft}</td>`

              //   data =
              //     data +
              //     `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(Number(x.actualDuration) - Number(x.plannedDuration))}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.Status}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.remark}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment(startDate).format('DD MMM YYYY')} - {moment(toDate).format('DD MMM YYYY')}{' '}
                Week of {moment(startDate).format('MMMM')} - Appraisal Report of {state.firstName}{' '}
                {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuctionweek(data, htmlToConvert)
    }
  }

  const downloadFuctionweek = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_WeeklyAppraisalReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  const onClickDownloadFucperiod = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProDataperiod.length > 0) {
      UniqueProDataperiod.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`

        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        // data = data + `<h4 style="font-family:arial;text-align:right;">Reporting To : ${k.contentDeveloperId.reportingTo.userName}</h4>`;
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                        padding: 5px;font-size:9px;
                        text-align: center;
                        background-color: #3c4b64;
                        color: white;" class="tableHeader">Act. Finish Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Act. Finish Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                            padding: 5px;font-size:9px;
                            text-align: center;
                            background-color: #3c4b64;
                            color: white;" class="tableHeader">Status</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">Summary</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)} - ${tConvertDate(x.efd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.est} - ${x.eft}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${
            x.lfd === undefined
              ? tConvertDate(x.lsd)
              : tConvertDate(x.lsd) + ' - ' + tConvertDate(x.lfd)
          }</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.ast} - ${x.aft}</td>`

              //   data =
              //     data +
              //     `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(Number(x.actualDuration) - Number(x.plannedDuration))}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.Status}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.remark}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment(startDateper).format('DD MMM YYYY')} -{' '}
                {moment(toDatePer).format('DD MMM YYYY')} Periodically Appraisal Report of{' '}
                {state.firstName} {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuctionweekperiod(data, htmlToConvert)
    }
  }

  const downloadFuctionweekperiod = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_Periodically_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  const onClickDownloadFuc = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProData.length > 0) {
      UniqueProData.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`

        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                        padding: 5px;font-size:9px;
                        text-align: center;
                        background-color: #3c4b64;
                        color: white;" class="tableHeader">Act. Finish Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Act. Finish Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                            padding: 5px;font-size:9px;
                            text-align: center;
                            background-color: #3c4b64;
                            color: white;" class="tableHeader">Status</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">Summary</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)} - ${tConvertDate(x.efd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.est} - ${x.eft}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${
            x.lfd === undefined
              ? tConvertDate(x.lsd)
              : tConvertDate(x.lsd) + ' - ' + tConvertDate(x.lfd)
          }</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.ast} - ${x.aft}</td>`

              //   data =
              //     data +
              //     `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(Number(x.actualDuration) - Number(x.plannedDuration))}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.Status}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.remark}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment(startDateM).format('MMMM')} Month - Appraisal Report of {state.firstName}{' '}
                {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_MonthlyAppraisalReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  const [selectedOption, setSelectedOption] = useState('')
  const tasks = [
    { value: 'today', label: 'Today Appraisal Report' },
    { value: 'weekly', label: 'Weekly Appraisal Report' },
    { value: 'monthly', label: 'Monthly Appraisal Report' },
    { value: 'periodically', label: 'Periodically Appraisal Report' },
  ]

  const [states, setStates] = useState({
    today: false,
    week: false,
    month: false,
    periodically: false,
  })

  const handletypeReport = (e, date) => {
    setSelectedOption(e)
    setUniqueProData([])
    setUniqueProDataWeek([])
    setUniqueProDataTod([])
    setUniqueProDataperiod([])
    setStartDate('')
    setToDate('')
    setStartDateM('')
    setStartDateper('')
    setToDatePer('')
    setStates({
      today: false,
      week: false,
      month: false,
      periodically: false,
    })
    if (e.value === 'today') {
      setStates({
        today: true,
        week: false,
        month: false,
        periodically: false,
      })
      taskTabletod(date)
    }
    if (e.value === 'weekly') {
      setStates({
        today: false,
        week: true,
        month: false,
        periodically: false,
      })
    }
    if (e.value === 'monthly') {
      setStates({
        today: false,
        week: false,
        month: true,
        periodically: false,
      })
    }
    if (e.value === 'periodically') {
      setStates({
        today: false,
        week: false,
        month: false,
        periodically: true,
      })
    }
  }

  function disableWeekends(date) {
    let day = new Date(date)
    day = day.getDay()
    return day !== 0
  }

  const selectDateFucperiod = async (e) => {
    e.preventDefault()
    setToDatePer(e.target.value)
    // if (date) {
    //   setStartDate(date)
    //   let toDa = await momentBusinessDays(date).businessAdd(6)._d
    //   //   let toDa = await dateDuration(date, 6, holidayDates)
    //   console.log([projectValue.value], 'TO DATE')
    //   setToDate(toDa)
    //   taskTableweek(date, momentBusinessDays(toDa).businessAdd(1)._d)
    //   // getContentFuc(
    //   //     companyId,
    //   //     bookType._id,
    //   //     country._id,
    //   //     institution._id,
    //   //     tier._id,
    //   //     moment(date).format("DD-MM-YYYY"),
    //   //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
    //   // );
    // }
    setStates({
      today: false,
      week: false,
      month: false,
      periodically: true,
    })
    taskTableperiod(e.target.value)
  }

  const taskTableperiod = async (ToDate) => {
    setTableData([])
    setUniqueProDataperiod([])
    const data = {
      employeeId: state.employeeId._id,
      fromDate: startDateper,
      toDate: ToDate,
    }
    try {
      const response = await generateWeeklyAppraiselReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProDataperiod(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProDataperiod([])
          setDataReport([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const selectDateFucweek = async (date) => {
    if (date) {
      setStartDate(date)
      let toDa = await momentBusinessDays(date).businessAdd(6)._d
      //   let toDa = await dateDuration(date, 6, holidayDates)
      console.log([projectValue.value], 'TO DATE')
      setToDate(toDa)
      taskTableweek(date, momentBusinessDays(toDa).businessAdd(1)._d)
      // getContentFuc(
      //     companyId,
      //     bookType._id,
      //     country._id,
      //     institution._id,
      //     tier._id,
      //     moment(date).format("DD-MM-YYYY"),
      //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
      // );
    }
  }

  const taskTableweek = async (FromDate, ToDate) => {
    setTableData([])
    setUniqueProDataWeek([])
    const data = {
      employeeId: state.employeeId._id,
      fromDate: FromDate,
      toDate: ToDate,
    }
    try {
      const response = await generateWeeklyAppraiselReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProDataWeek(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProDataWeek([])
          setDataReport([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const [selectedTodayDate, setselectedTodayDate] = useState(new Date())

  const isToday = moment(selectedTodayDate).isSame(moment(), 'day')

  const selectDateFuctod = async (date) => {
    if (date) {
      setselectedTodayDate(date)
      // taskTable(momentBusinessDays(date).businessAdd(1)._d)
      taskTabletod(date)
    }
  }

  const taskTabletod = async (date) => {
    setTableData([])
    setUniqueProDataTod([])
    // let today = new Date().toISOString().slice(0, 10)

    const today = moment(date).format('YYYY-MM-DD')
    // alert(today)
    const data = {
      date: today,
    }
    try {
      const response = await generateReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProDataTod(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProDataTod([])
          // toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
            <div className="panel-heading">
              <div className="col-xs-6">
                <h3 className="font_Title">Appraisal Report List</h3>
              </div>
            </div>
            <CCard className="mb-6">
              <CCardBody>
                <CForm>
                  <CRow className="mb-3">
                    <CCol sm={3}>
                      <CFormLabel className="col-form-label donlabel text-align-left">
                        Select Appraisal Report <code>*</code>
                      </CFormLabel>
                      <Select
                        className={'inputfieldso'}
                        options={tasks}
                        value={selectedOption}
                        onChange={handletypeReport}
                        placeholder="Select Task Report"
                      />
                    </CCol>

                    {states.today && (
                      <CCol sm={3}>
                        <CRow className="mb-3">
                          <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Select Date <code>*</code>
                          </CFormLabel>
                          <CCol sm={12}>
                            <DatePicker
                              placeholderText={'Select the Date'}
                              selected={selectedTodayDate}
                              onChange={(date) => {
                                console.log(date, 'SJSJDLSDJOHDJFFJLDJL?FJLSJFDLJFSLF')
                                selectDateFuctod(date)
                              }}
                              dateFormat="dd/MM/yyyy"
                              dayClassName={(date) =>
                                date.getDay() === 0 ? 'weekend-days' : undefined
                              }
                              filterDate={disableWeekends}
                              customInput={
                                <CFormInput
                                  value={selectedTodayDate}
                                  className="reportInputwidth"
                                ></CFormInput>
                              }
                            />
                          </CCol>
                        </CRow>
                      </CCol>
                    )}

                    {states.week && (
                      <>
                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Select From Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <DatePicker
                                placeholderText={'Select the  From Date'}
                                selected={startDate && startDate}
                                onChange={(date) => {
                                  selectDateFucweek(date)
                                }}
                                dateFormat="dd/MM/yyyy"
                                excludeDates={
                                  holidayDates && holidayDates.length > 0
                                    ? holidayDates.map((x) => x)
                                    : []
                                }
                                dayClassName={(date) =>
                                  date.getDay() === 0 ? 'weekend-days' : undefined
                                }
                                highlightDates={[
                                  {
                                    'react-datepicker__day--highlighted-custom-1': [
                                      ...holidayDates,
                                    ],
                                  },
                                ]}
                                filterDate={disableWeekends}
                                customInput={
                                  <CFormInput
                                    value={startDate}
                                    className="reportInputwidth"
                                  ></CFormInput>
                                }
                              />
                            </CCol>
                          </CRow>
                        </CCol>

                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Select To Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <DatePicker
                                placeholderText={'Select the To Date'}
                                selected={toDate && toDate}
                                dateFormat="dd/MM/yyyy"
                                // onChange={(date) => {
                                //     selectDateFuc(date);
                                // }}
                                disabled={true}
                                customInput={
                                  <CFormInput
                                    value={startDate}
                                    className="reportInputwidth"
                                  ></CFormInput>
                                }
                              />
                            </CCol>
                          </CRow>
                        </CCol>
                      </>
                    )}

                    {states.month && (
                      <CCol sm={3}>
                        <CRow className="mb-3">
                          <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Select Month <code>*</code>
                          </CFormLabel>
                          <CCol sm={12}>
                            <DatePicker
                              placeholderText={'Select the month'}
                              dateFormat={'MM/yyyy'}
                              selected={startDateM && startDateM}
                              onChange={(date) => {
                                selectDateFuc(date)
                              }}
                              customInput={
                                <CFormInput
                                  className="reportInputwidth"
                                  value={startDateM}
                                ></CFormInput>
                              }
                              showMonthYearPicker
                            />
                          </CCol>
                        </CRow>
                      </CCol>
                    )}

                    {states.periodically && (
                      <>
                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Select From Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <input
                                type="date"
                                id="startDate"
                                value={startDateper}
                                onChange={(e) => {
                                  setStartDateper(e.target.value)
                                }}
                                className="form-control"
                                style={{ width: '300px' }}
                              />
                            </CCol>
                          </CRow>
                        </CCol>

                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Select To Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <input
                                type="date"
                                id="endDate"
                                value={toDatePer}
                                onChange={(e) => selectDateFucperiod(e)}
                                className="form-control"
                                style={{ width: '300px' }}
                              />
                            </CCol>
                          </CRow>
                        </CCol>
                      </>
                    )}
                  </CRow>
                </CForm>
              </CCardBody>
            </CCard>
            {/* Today Appraisal Report */}
            <CForm>
              {/* <div>
                <CRow className=""> */}
              {/* <div>
                    {UniqueProDataTod.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        {isToday
                          ? 'Today Appraisal Report'
                          : `Appraisal Report of - ${moment(selectedTodayDate).format(
                              'DD MMM YYYY',
                            )}`}
                      </h3>
                    ) : null}
                  </div> */}
              <div className="mt-4 d-flex align-items-center justify-content-between">
                {UniqueProDataTod.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        {isToday
                          ? 'Today Appraisal Report'
                          : `Appraisal Report of - ${moment(selectedTodayDate).format(
                              'DD MMM YYYY',
                            )}`}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        type="submit"
                        // onClick={(e) => {
                        //   openModal()
                        //   e.preventDefault()
                        // }}
                        onClick={(e) => {
                          e.preventDefault()
                          onClickDownloadFuctod()
                        }}
                        disabled={isDisabled}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {selectedTodayDate && (
                <>
                  {UniqueProDataTod.length > 0 ? (
                    <>
                      {UniqueProDataTod.map((x, i) => {
                        return (
                          <AppraisalReportFunctions
                            className="escols"
                            key={i}
                            projectId={x.projectId._id}
                            projectName={'Project Name : ' + x.projectId.projectName}
                            projectReportData={DataReport.filter(
                              (item) => item.projectId._id === x.projectId._id,
                            )}
                            // funcTiersData={getMostFuncTiers(
                            //   DataReport.filter(
                            //     (item) => item.projectId._id === x.projectId._id,
                            //   ),
                            // )}
                            techTiersData={getMostTechTiers(
                              DataReport.filter((item) => item.projectId._id === x.projectId._id),
                            )}
                            funcTiersData={[
                              ...new Map(
                                DataReport.filter(
                                  (item) => item.projectId._id === x.projectId._id,
                                ).map((item123) => [item123.functionalAttributeId._id, item123]),
                              ).values(),
                            ]}
                          />
                        )
                      })}
                    </>
                  ) : null}
                </>
              )}
              {/* </CRow>
              </div> */}
            </CForm>

            {/* Weekly Appraisal Report */}
            <CForm>
              {/* <div>
                <CRow className=""> */}
              {/* <div>
                    {startDate && UniqueProDataWeek.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        Weekly Appraisal Report for the Month of {moment(startDate).format('MMMM')}{' '}
                        from <br />
                        {moment(startDate).format('DD MMM YYYY')} -{' '}
                        {moment(toDate).format('DD MMM YYYY')}{' '}
                      </h3>
                    ) : null}
                  </div> */}
              <div className="mt-3 d-flex align-items-center justify-content-between">
                {UniqueProDataWeek.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        Weekly Appraisal Report for the Month of {moment(startDate).format('MMMM')}{' '}
                        from {moment(startDate).format('DD MMM YYYY')} -{' '}
                        {moment(toDate).format('DD MMM YYYY')}{' '}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        type="submit"
                        // onClick={(e) => {
                        //   openModal()
                        //   e.preventDefault()
                        // }}
                        onClick={(e) => {
                          e.preventDefault()
                          onClickDownloadFucweek()
                        }}
                        disabled={isDisabled}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {UniqueProDataWeek.length > 0 ? (
                <>
                  {UniqueProDataWeek.map((x, i) => {
                    return (
                      <AppraisalReportFunctions
                        className="escols"
                        key={i}
                        projectId={x.projectId._id}
                        projectName={'Project Name : ' + x.projectId.projectName}
                        projectReportData={DataReport.filter(
                          (item) => item.projectId._id === x.projectId._id,
                        )}
                        // funcTiersData={getMostFuncTiers(
                        //   DataReport.filter(
                        //     (item) => item.projectId._id === x.projectId._id,
                        //   ),
                        // )}
                        techTiersData={getMostTechTiers(
                          DataReport.filter((item) => item.projectId._id === x.projectId._id),
                        )}
                        funcTiersData={[
                          ...new Map(
                            DataReport.filter((item) => item.projectId._id === x.projectId._id).map(
                              (item123) => [item123.functionalAttributeId._id, item123],
                            ),
                          ).values(),
                        ]}
                      />
                    )
                  })}
                </>
              ) : null}
              {/* </CRow>
              </div> */}

              {/* Modal for Pdf Downloader */}
            </CForm>

            {/* Monthly Task Appraisal Report */}
            <CForm>
              {/* <div>
                <CRow className=""> */}
              {/* <div>
                    {startDateM && UniqueProData.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        Monthly Task Appraisal Report for the Month of{' '}
                        {moment(startDateM).format('MMMM')}
                      </h3>
                    ) : null}
                  </div> */}
              <div className="d-flex align-items-center justify-content-between">
                {UniqueProData.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        Monthly Task Appraisal Report for the Month of{' '}
                        {moment(startDateM).format('MMMM')}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        type="submit"
                        // onClick={(e) => {
                        //   openModal()
                        //   e.preventDefault()
                        // }}
                        onClick={(e) => {
                          e.preventDefault()
                          onClickDownloadFuc()
                        }}
                        disabled={isDisabled}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {UniqueProData.length > 0 ? (
                <>
                  {UniqueProData.map((x, i) => {
                    return (
                      <AppraisalReportFunctions
                        className="escols"
                        key={i}
                        projectId={x.projectId._id}
                        projectName={'Project Name : ' + x.projectId.projectName}
                        projectReportData={DataReport.filter(
                          (item) => item.projectId._id === x.projectId._id,
                        )}
                        // funcTiersData={getMostFuncTiers(
                        //   DataReport.filter(
                        //     (item) => item.projectId._id === x.projectId._id,
                        //   ),
                        // )}
                        techTiersData={getMostTechTiers(
                          DataReport.filter((item) => item.projectId._id === x.projectId._id),
                        )}
                        funcTiersData={[
                          ...new Map(
                            DataReport.filter((item) => item.projectId._id === x.projectId._id).map(
                              (item123) => [item123.functionalAttributeId._id, item123],
                            ),
                          ).values(),
                        ]}
                      />
                    )
                  })}
                </>
              ) : null}
              {/* </CRow>
              </div> */}

              {/* Modal for Pdf Downloader */}
            </CForm>

            {/* Periodically Appraisal Report from */}
            <CForm>
              {/* <div>
                <CRow className=""> */}
              {/* <div>
                    {startDateper && UniqueProDataperiod.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        Periodically Appraisal Report from  
                        {moment(startDateper).format('DD MMM YYYY')} -{' '}
                        {moment(toDatePer).format('DD MMM YYYY')}{' '}
                      </h3>
                    ) : null}
                  </div> */}
              <div className="d-flex align-items-center justify-content-between">
                {UniqueProDataperiod.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        Periodically Appraisal Report from{' '}
                        {moment(startDateper).format('DD MMM YYYY')} -{' '}
                        {moment(toDatePer).format('DD MMM YYYY')}{' '}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        type="submit"
                        // onClick={(e) => {
                        //   openModal()
                        //   e.preventDefault()
                        // }}
                        onClick={(e) => {
                          e.preventDefault()
                          onClickDownloadFucperiod()
                        }}
                        disabled={isDisabled}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {UniqueProDataperiod.length > 0 ? (
                <>
                  {UniqueProDataperiod.map((x, i) => {
                    return (
                      <AppraisalReportFunctions
                        className="escols"
                        key={i}
                        projectId={x.projectId._id}
                        projectName={'Project Name : ' + x.projectId.projectName}
                        projectReportData={DataReport.filter(
                          (item) => item.projectId._id === x.projectId._id,
                        )}
                        // funcTiersData={getMostFuncTiers(
                        //   DataReport.filter(
                        //     (item) => item.projectId._id === x.projectId._id,
                        //   ),
                        // )}
                        techTiersData={getMostTechTiers(
                          DataReport.filter((item) => item.projectId._id === x.projectId._id),
                        )}
                        funcTiersData={[
                          ...new Map(
                            DataReport.filter((item) => item.projectId._id === x.projectId._id).map(
                              (item123) => [item123.functionalAttributeId._id, item123],
                            ),
                          ).values(),
                        ]}
                      />
                    )
                  })}
                </>
              ) : null}
              {/* </CRow>
              </div> */}

              {/* Modal for Pdf Downloader */}
            </CForm>
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
