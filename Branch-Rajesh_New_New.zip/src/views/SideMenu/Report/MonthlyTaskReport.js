import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  generateWeekMonthTaskReport,
  projectmaptable,
  roleTable,
  downloadAppraisalTodayPdf,
  TaskReportGenerate,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { TaskReportFunctions } from '../Report/TaskReportFunctions'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import momentBusinessDays from 'moment-business-days'

momentBusinessDays.updateLocale('us', {
  workingWeekdays: [1, 2, 3, 4, 5, 6],
})

export const MonthlyTaskReport = () => {
  const { state, dispatch } = useContext(GlobalContext)

  console.log(state, 'USER DATA')
  const [projectDrop, setProjectDrop] = useState([])
  const [projectValue, setProjectValue] = useState('')
  const [tableData, setTableData] = useState([])

  const [tableShow, setTableShow] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [date, setDate] = useState('')
  const [week, setWeek] = useState(false)
  const [month, setMonth] = useState(false)

  const [listData, setListData] = useState('')

  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [reportbtn, setreportbtn] = React.useState(false)
  const ref = React.createRef()

  const [startDatem, setStartDatem] = useState('')
  const [startDateper, setStartDateper] = useState('')
  const [toDatePer, setToDatePer] = useState('')
  const [startDate, setStartDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [holidayDates, setHolidayDates] = useState([])
  const [isDisabled, setIsDisabled] = useState(false)

  const [UniqueProData, setUniqueProData] = useState([])
  const [UniqueProDatatod, setUniqueProDatatod] = useState([])
  const [UniqueProDataweek, setUniqueProDataweek] = useState([])
  const [UniqueProDataperiod, setUniqueProDataperiod] = useState([])

  const openModal = () => {
    setIsOpen(true)
  }

  const closeModal = () => {
    setIsOpen(false)
  }

  const optionsans = {
    orientation: 'landscape',
  }

  const options = [
    { value: 'chocolate', label: 'yet to start' },
    { value: 'strawberry', label: 'In Progress' },
    { value: 'vanilla', label: 'Completed' },
    { value: 'hold', label: 'Hold' },
  ]

  const task = [
    { value: 'chocolateq', label: 'Daily' },
    { value: 'strawberryq', label: 'Weekly' },
    { value: 'vanillaq', label: 'Monthly' },
  ]

  const monthly = [
    { value: 'jan', label: 'January' },
    { value: 'feb', label: 'February' },
    { value: 'mar', label: 'March' },
    { value: 'apr', label: 'April' },
    { value: 'may', label: 'May' },
    { value: 'jun', label: 'June' },
    { value: 'jul', label: 'July' },
    { value: 'aug', label: 'August' },
    { value: 'sep', label: 'September' },
    { value: 'oct', label: 'October' },
    { value: 'nov', label: 'November' },
    { value: 'dec', label: 'December' },
  ]

  const taskChange = (e) => {
    if (e.value === 'chocolateq') {
      setTableShow(true)
      setreportbtn(true)
      setWeek(false)
      setMonth(false)
    }
    if (e.value === 'strawberryq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(true)
      setMonth(false)
    }
    if (e.value === 'vanillaq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(false)
      setMonth(true)
    }
  }

  //   useEffect(() => {
  //     selectProject(state.employeeId._id)
  //   }, [])

  //   const selectProject = async (employeeId) => {
  //     var response
  //     try {
  //       response = await projectmaptable(employeeId)
  //       if (response) {
  //         const data = response.data.projects.map((x) => {
  //           return {
  //             value: x._id,
  //             label: x.projectName,
  //           }
  //         })
  //         setProjectDrop(data)
  //       }
  //     } catch (err) {
  //       if (err.response) {
  //         if (err.response.data && err.response.data.success == false) {
  //           toast.error(err.response.data.error)
  //         }
  //       } else if (err.request) {
  //         toast.error('No Internet')
  //       } else {
  //         toast.error('Something Went Wrong' + err)
  //       }
  //     }
  //   }

  function disableWeekends(date) {
    let day = new Date(date)
    day = day.getDay()
    return day !== 0
  }

  const dateDurationFuc = async (data, date1, dates, k) => {
    while (date1.length > 0) {
      let date = await dates
      date1 = await data.filter((x) => {
        if (moment(moment(date).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      if (date1.length > 0) {
        date = await momentBusinessDays(date).businessAdd(1)._d
      }
      dates = await date
    }
    return dates
  }

  const dateDuration = async (date, duration, data) => {
    let i = 0
    while (i < Number(duration)) {
      let dates = await date
      let k = i + 1
      let date1 = await data.filter(async (x) => {
        dates = await momentBusinessDays(dates).businessAdd(1)._d
        if (moment(moment(dates).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      console.log(date1.length)
      if (date1.length > 0) {
        dates = await dateDurationFuc(data, date1, dates, k)
      }
      i = i + 1
      date = await dates
    }
    return date
  }

  const selectDateFuc = async (date) => {
    if (date) {
      setStartDatem(date)
      taskTable(moment(date).format('YYYY-MM-DD'), moment(date).endOf('month').format('YYYY-MM-DD'))
      // getContentFuc(
      //     companyId,
      //     bookType._id,
      //     country._id,
      //     institution._id,
      //     tier._id,
      //     moment(date).format("DD-MM-YYYY"),
      //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
      // );
    }
  }

  const initalColumn = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '2%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'project',
      label: 'Project',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
  ]

  const RemainingInitialColumn = [
    {
      key: 'TodayActivity',
      label: 'Activity',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'StartDate',
      label: 'Est. Start Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EndDate',
      label: 'Est. End Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    // {
    //   key: 'EstimatedStartTime',
    //   label: 'Est. Start Time',
    //   _style: { width: '18%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'EstimatedEndTime',
    //   label: 'Est. End Time',
    //   _style: { width: '17%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'plannedduration',
    //   label: 'Est. Duration (Mins)',
    //   _style: { width: '10%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
  ]

  const [columns, setColumns] = useState(initalColumn)
  const [DataReport, setDataReport] = useState([])

  const getMostFuncTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.functionalTierDetails.length > max) {
        max = item.functionalTierDetails.length
        maxObj = [item]
      } else if (item.functionalTierDetails.length === max) {
        maxObj.push(item)
      }
    })

    return maxObj
  }

  const getMostTechTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.technicalTierDetails !== null) {
        if (item.technicalTierDetails.length > max) {
          max = item.technicalTierDetails.length
          maxObj = [item]
        } else if (item.technicalTierDetails.length === max) {
          maxObj.push(item)
        }
      }
    })

    return maxObj
  }

  const taskTable = async (FromDate, ToDate) => {
    setTableData([])
    setUniqueProData([])
    const data = {
      //   projectId: [projectValue.value],
      employeeId: state.employeeId._id,
      fromDate: FromDate,
      toDate: ToDate,
    }
    try {
      const response = await generateWeekMonthTaskReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            // console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProData(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProData([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const tConvertDate = (date) => {
    var RDate = date.split('T')[0]
    var RDate = moment(RDate).format('DD MMM YYYY')
    return RDate // return adjusted time or original string
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  const onClickDownloadFuctod = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProDatatod.length > 0) {
      UniqueProDatatod.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`

        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        // data = data + `<h4 style="font-family:arial;text-align:right;">Reporting To : ${k.contentDeveloperId.reportingTo.userName}</h4>`;
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Start Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. End Date</th>`

            // data =
            //   data +
            //   `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //           padding: 5px;font-size:9px;
            //           text-align: center;
            //           background-color: #3c4b64;
            //           color: white;" class="tableHeader">Status</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              // padding: 5px;" >${x.Status}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment().format('DD MMM YYYY')} Detailed Today Task Report of {state.firstName}{' '}
                {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuctiontod(data, htmlToConvert)
    }
  }

  const downloadFuctiontod = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_TodaySelfTaskReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  const onClickDownloadFucweek = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProDataweek.length > 0) {
      UniqueProDataweek.map((x, i) => {
        console.log(x, 'IIIIIIIIIIIIIIIIIIIIIII')
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`
        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        // data = data + `<h4 style="font-family:arial;text-align:right;">Reporting To : ${k.contentDeveloperId.reportingTo.userName}</h4>`;
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Start Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. End Date</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment(startDate).format('DD MMM YYYY')} - {moment(toDate).format('DD MMM YYYY')}{' '}
                Week of {moment(startDate).format('MMMM')} - Task Report of {state.firstName}{' '}
                {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuctionweek(data, htmlToConvert)
    }
  }

  const downloadFuctionweek = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_WeeklyTaskReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  const onClickDownloadFuc = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProData.length > 0) {
      UniqueProData.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:15px;">
        Project: ${x.projectId.projectName}
        </h4>`
        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:15px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`
            console.log(z, 'UUUUUUUUUUUUUUUUUUUUUUU')
            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            // z.functionalTierDetails.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //       padding: 5px;font-size:9px;
            //       text-align: center;
            //       background-color: #3c4b64;
            //       color: white;" class="tableHeader">${x.value}</th>`

            //   return data
            // })

            // getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
            //   .length > 0 &&
            //   getMostTechTiers(
            //     DataReport.filter((item) => item.projectId._id === x.projectId._id),
            //   )[0].technicalTierDetails.map(async (x, i) => {
            //     data =
            //       data +
            //       `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //       padding: 5px;font-size:9px;
            //       text-align: center;
            //       background-color: #3c4b64;
            //       color: white;" class="tableHeader">${x.value}</th>`

            //     return data
            //   })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Functional Requirements</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:12px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Technical Requirements</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Task Description</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:12px;width:5%;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Start Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:12px;width:5%;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">End Date</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
              padding: 5px;" >`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `${
                    x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                      ? `${
                          x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                            .variableName
                        }, `
                      : ''
                  }`

                if (z.functionalTierDetails.length === i + 1) {
                  data = data + `${dDesc.innerText}`
                }

                return data
              })

              data = data + `</td>`

              //       data =
              //         data +
              //         `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
              // padding: 5px;" >`

              //       z.functionalTierDetails.map(async (y, i) => {
              //         data =
              //           data +
              //           `${
              //             x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
              //               ? `${y.value} - ${
              //                   x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
              //                     .variableName
              //                 }, `
              //               : ''
              //           }`

              //         data = data + `<br>`

              //         if (z.functionalTierDetails.length === i + 1) {
              //           data = data + `${dDesc.innerText}`
              //         }

              //         return data
              //       })

              //       data = data + `</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
            padding: 5px;" >`

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `${
                      x.technicalVariableDetails === null
                        ? ''
                        : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                            .length === 0
                        ? ''
                        : `${
                            x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                              ?.variableName
                          }${
                            getMostTechTiers(
                              DataReport.filter((item) => item.projectId._id === x.projectId._id),
                            )[0].technicalTierDetails.length ===
                            i + 1
                              ? ''
                              : ', '
                          }`
                    }`

                  return data
                })

              data = data + `</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
            padding: 5px;" >`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `${
                    x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                      ? `${
                          x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                            .variableName
                        }, `
                      : ''
                  }`

                if (z.functionalTierDetails.length === i + 1) {
                  data = data + `${dDesc.innerText}, `
                }

                return data
              })

              // data = data + `${dDesc.innerText}`

              if (
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                ).length > 0
              ) {
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                ).length > 0 &&
                  getMostTechTiers(
                    DataReport.filter((item) => item.projectId._id === x.projectId._id),
                  )[0].technicalTierDetails.map(async (z, i) => {
                    data =
                      data +
                      `${
                        x.technicalVariableDetails === null
                          ? ''
                          : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                              .length === 0
                          ? ''
                          : `${
                              x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                                ?.variableName
                            }${
                              getMostTechTiers(
                                DataReport.filter((item) => item.projectId._id === x.projectId._id),
                              )[0].technicalTierDetails.length ===
                              i + 1
                                ? ''
                                : ', '
                            }`
                      }`

                    return data
                  })
              }

              data = data + `</td>`

              //       data =
              //         data +
              //         `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              //   padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '18px',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Project Management Software
              </p>
              <p
                style={{
                  fontSize: '18px',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment(startDatem).format('MMMM')} Month - Task Report of {state.firstName}{' '}
                {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_MonthlyTaskReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  const onClickDownloadFucperiod = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProDataperiod.length > 0) {
      UniqueProDataperiod.map((x, i) => {
        console.log(x, 'IIIIIIIIIIIIIIIIIIIIIII')
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`
        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        // data = data + `<h4 style="font-family:arial;text-align:right;">Reporting To : ${k.contentDeveloperId.reportingTo.userName}</h4>`;
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Start Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. End Date</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment(startDateper).format('DD MMM YYYY')} -{' '}
                {moment(toDatePer).format('DD MMM YYYY')} Periodiaclly Task Report of{' '}
                {state.firstName} {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuctionperiod(data, htmlToConvert)
    }
  }

  const downloadFuctionperiod = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `${
          String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        }_Periodically_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }
  const [selectedOption, setSelectedOption] = useState('')
  const tasks = [
    { value: 'today', label: 'Today Task Report' },
    { value: 'weekly', label: 'Weekly Task Report' },
    { value: 'monthly', label: 'Monthly Task Report' },
    { value: 'periodically', label: 'Periodically Task Report' },
  ]

  const [states, setStates] = useState({
    today: false,
    week: false,
    month: false,
    periodically: false,
  })

  const handletypeReport = (e, date) => {
    setSelectedOption(e)
    setUniqueProData([])
    setUniqueProDatatod([])
    setUniqueProDataweek([])
    setUniqueProDataperiod([])
    setStartDate('')
    setToDate('')
    setStartDatem('')
    setStartDateper('')
    setToDatePer('')
    setStates({
      today: false,
      week: false,
      month: false,
      periodically: false,
    })

    if (e.value === 'today') {
      setStates({
        today: true,
        week: false,
        month: false,
        periodically: false,
      })

      taskTabletod(date)
    }
    if (e.value === 'weekly') {
      setStates({
        today: false,
        week: true,
        month: false,
        periodically: false,
      })
    }
    if (e.value === 'monthly') {
      setStates({
        today: false,
        week: false,
        month: true,
        periodically: false,
      })
    }
    if (e.value === 'periodically') {
      setStates({
        today: false,
        week: false,
        month: false,
        periodically: true,
      })
    }
  }

  const selectDateFucweek = async (date) => {
    if (date) {
      setStartDate(date)
      let toDa = await momentBusinessDays(date).businessAdd(6)._d
      //   let toDa = await dateDuration(date, 6, holidayDates)
      console.log([projectValue.value], 'TO DATE')
      setToDate(toDa)
      taskTableweek(date, momentBusinessDays(toDa).businessAdd(1)._d)
      // getContentFuc(
      //     companyId,
      //     bookType._id,
      //     country._id,
      //     institution._id,
      //     tier._id,
      //     moment(date).format("DD-MM-YYYY"),
      //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
      // );
    }
  }

  const selectDateFucperiod = async (e) => {
    e.preventDefault()
    setToDatePer(e.target.value)
    // if (date) {
    //   setStartDate(date)
    //   let toDa = await momentBusinessDays(date).businessAdd(6)._d
    //   //   let toDa = await dateDuration(date, 6, holidayDates)
    //   console.log([projectValue.value], 'TO DATE')
    //   setToDate(toDa)
    //   taskTableweek(date, momentBusinessDays(toDa).businessAdd(1)._d)
    //   // getContentFuc(
    //   //     companyId,
    //   //     bookType._id,
    //   //     country._id,
    //   //     institution._id,
    //   //     tier._id,
    //   //     moment(date).format("DD-MM-YYYY"),
    //   //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
    //   // );
    // }
    setStates({
      today: false,
      week: false,
      month: false,
      periodically: true,
    })
    taskTableperiod(e.target.value)
  }

  const taskTableperiod = async (ToDate) => {
    setTableData([])
    setUniqueProDataperiod([])
    const data = {
      //   projectId: [projectValue.value],
      employeeId: state.employeeId._id,
      fromDate: startDateper,
      toDate: ToDate,
    }
    try {
      const response = await generateWeekMonthTaskReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            // console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProDataperiod(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProDataperiod([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const taskTableweek = async (FromDate, ToDate) => {
    setTableData([])
    setUniqueProDataweek([])
    const data = {
      //   projectId: [projectValue.value],
      employeeId: state.employeeId._id,
      fromDate: FromDate,
      toDate: ToDate,
    }
    try {
      const response = await generateWeekMonthTaskReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            // console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProDataweek(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProDataweek([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }
  var today = new Date()
  var dd = String(today.getDate()).padStart(2, '0')
  var mm = String(today.getMonth() + 1).padStart(2, '0') //January is 0!
  var yyyy = today.getFullYear()

  var today = dd + '/' + mm + '/' + yyyy

  const currentDate = moment()

  // Format the moment object to the desired format
  const formattedDate = currentDate.format('ddd MMM D YYYY')

  const [selectedTodayDate, setselectedTodayDate] = useState(new Date())

  const isToday = moment(selectedTodayDate).isSame(moment(), 'day')

  const selectDateFucTod = async (date) => {
    if (date) {
      console.log(date, 'SJSJDLSDJOHDJFFJLDJL?FJLSJFDLJFSLF')
      setselectedTodayDate(date)
      taskTabletod(date)
    }
  }

  const taskTabletod = async (date) => {
    setTableData([])
    setUniqueProDatatod([])
    console.log(moment(date).format('YYYY-MM-DD'), 'TOday DATE')
    console.log(date, 'JDSOJSAJLDSAJSADLJLJDSALJASLDJLSDA')
    const fromDate = moment(date).format('YYYY-MM-DD')
    // const fromDate = moment(date).format('YYYY-MM-DD');
    // + 'T18:30:00.000Z'
    const data = {
      employeeId: state.employeeId._id,
      fromDate: fromDate,
      // toDate: moment(date).format('YYYY-MM-DD'),
    }
    try {
      const response = await TaskReportGenerate(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            // console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProDatatod(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProDatatod([])
          // toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
            <div className="panel-heading">
              <div className="col-xs-6">
                <h3 className="font_Title">Task Report List</h3>
              </div>
            </div>
            <CCard className="mb-6">
              <CCardBody>
                <CForm>
                  <CRow className="mb-3">
                    {/* <CRow className="col-sm-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Project Name <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <Select
                          className={'inputfieldso'}
                          options={projectDrop}
                          value={projectValue}
                          onChange={(e) => {
                            setProjectValue(e)
                            setStartDate('')
                            setToDate('')
                            setTableData([])
                          }}
                          placeholder="Project Name"
                        />
                      </CCol>
                    </CRow> */}

                    <CCol sm={3}>
                      <CFormLabel className="col-form-label donlabel text-align-left">
                        Select Task Report <code>*</code>
                      </CFormLabel>
                      <Select
                        className={'inputfieldso'}
                        options={tasks}
                        value={selectedOption}
                        onChange={handletypeReport}
                        placeholder="Select Task Report"
                      />
                    </CCol>

                    {states.today && (
                      <CCol sm={3}>
                        <CRow className="mb-3">
                          <CFormLabel className="col-form-label donlabel text-align-left">
                            Select Date <code>*</code>
                          </CFormLabel>
                          <CCol sm={12}>
                            <DatePicker
                              placeholderText={'Select the Date'}
                              selected={selectedTodayDate}
                              // value={selectedTodayDate}
                              onChange={(date) => {
                                console.log(date, 'SJSJDLSDJOHDJFFJLDJL?FJLSJFDLJFSLF')
                                selectDateFucTod(date)
                              }}
                              dateFormat="dd/MM/yyyy"
                              dayClassName={(date) =>
                                date.getDay() === 0 ? 'weekend-days' : undefined
                              }
                              filterDate={disableWeekends}
                              customInput={
                                <CFormInput
                                  value={selectedTodayDate}
                                  style={{ width: '300px' }}
                                ></CFormInput>
                              }
                            />
                          </CCol>
                        </CRow>
                      </CCol>
                    )}

                    {states.week && (
                      <>
                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-form-label donlabel text-align-left">
                              Select From Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <DatePicker
                                placeholderText={'Select the  From Date'}
                                selected={startDate && startDate}
                                onChange={(date) => {
                                  selectDateFucweek(date)
                                }}
                                dateFormat="dd/MM/yyyy"
                                excludeDates={
                                  holidayDates && holidayDates.length > 0
                                    ? holidayDates.map((x) => x)
                                    : []
                                }
                                dayClassName={(date) =>
                                  date.getDay() === 0 ? 'weekend-days' : undefined
                                }
                                highlightDates={[
                                  {
                                    'react-datepicker__day--highlighted-custom-1': [
                                      ...holidayDates,
                                    ],
                                  },
                                ]}
                                filterDate={disableWeekends}
                                customInput={
                                  <CFormInput
                                    value={startDate}
                                    style={{ width: '300px' }}
                                  ></CFormInput>
                                }
                              />
                            </CCol>
                          </CRow>
                        </CCol>

                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-form-label donlabel text-align-left">
                              Select To Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <DatePicker
                                placeholderText={'Select the To Date'}
                                selected={toDate && toDate}
                                dateFormat="dd/MM/yyyy"
                                // onChange={(date) => {
                                //     selectDateFuc(date);
                                // }}
                                disabled={true}
                                customInput={
                                  <CFormInput
                                    value={startDate}
                                    style={{ width: '300px' }}
                                  ></CFormInput>
                                }
                              />
                            </CCol>
                          </CRow>
                        </CCol>
                      </>
                    )}

                    {states.periodically && (
                      <>
                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-form-label donlabel text-align-left">
                              Select From Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <input
                                type="date"
                                id="startDate"
                                value={startDateper}
                                onChange={(e) => {
                                  setStartDateper(e.target.value)
                                }}
                                className="form-control"
                                style={{ width: '300px' }}
                              />
                            </CCol>
                          </CRow>
                        </CCol>

                        <CCol sm={3}>
                          <CRow className="mb-3">
                            <CFormLabel className="col-form-label donlabel text-align-left">
                              Select To Date <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <input
                                type="date"
                                id="endDate"
                                value={toDatePer}
                                onChange={(e) => selectDateFucperiod(e)}
                                className="form-control"
                                style={{ width: '300px' }}
                              />
                            </CCol>
                          </CRow>
                        </CCol>
                      </>
                    )}

                    {states.month && (
                      <CCol sm={3}>
                        <CRow className="mb-3">
                          <CFormLabel className="col-form-label donlabel text-align-left">
                            Select Month <code>*</code>
                          </CFormLabel>
                          <CCol sm={12}>
                            <DatePicker
                              placeholderText={'Select the month'}
                              dateFormat={'MM/yyyy'}
                              selected={startDatem && startDatem}
                              onChange={(date) => {
                                selectDateFuc(date)
                              }}
                              customInput={
                                <CFormInput
                                  value={startDatem}
                                  style={{ width: '300px' }}
                                ></CFormInput>
                              }
                              showMonthYearPicker
                            />
                          </CCol>
                        </CRow>
                      </CCol>
                    )}

                    {/* <CRow className="col-sm-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Select Month <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <DatePicker
                          placeholderText={'Select the month'}
                          dateFormat={'MM/yyyy'}
                          selected={startDate && startDate}
                          onChange={(date) => {
                            selectDateFuc(date)
                          }}
                          customInput={
                            <CFormInput
                              style={{ width: '700px !important' }}
                              value={startDate}
                            ></CFormInput>
                          }
                          showMonthYearPicker
                        />
                      </CCol>
                    </CRow> */}
                  </CRow>
                </CForm>
              </CCardBody>
            </CCard>
            {/* Today Task Report */}
            <CForm>
              {/* <div> */}
              {/* <CRow className=""> */}
              {/* <div>
                    {UniqueProDatatod.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        {isToday
                          ? 'Today Task Report'
                          : `Task Report of - ${moment(selectedTodayDate).format('DD MMM YYYY')}`}
                      </h3>
                    ) : null}
                  </div> */}
              <div className="mt-4 d-flex align-items-center justify-content-between">
                {UniqueProDatatod.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        {isToday
                          ? 'Today Task Report'
                          : `Task Report of - ${moment(selectedTodayDate).format('DD MMM YYYY')}`}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        disabled={isDisabled}
                        type="submit"
                        // onClick={(e) => {
                        //   openModal()
                        //   e.preventDefault()
                        // }}
                        onClick={(e) => {
                          e.preventDefault()
                          onClickDownloadFuctod()
                        }}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {selectedTodayDate && (
                <>
                  {UniqueProDatatod.length > 0 ? (
                    <>
                      {UniqueProDatatod.map((x, i) => {
                        return (
                          <TaskReportFunctions
                            className="escols"
                            key={i}
                            projectId={x.projectId._id}
                            projectName={'Project Name : ' + x.projectId.projectName}
                            projectReportData={DataReport.filter(
                              (item) => item.projectId._id === x.projectId._id,
                            )}
                            // funcTiersData={getMostFuncTiers(
                            //   DataReport.filter(
                            //     (item) => item.projectId._id === x.projectId._id,
                            //   ),
                            // )}
                            techTiersData={getMostTechTiers(
                              DataReport.filter((item) => item.projectId._id === x.projectId._id),
                            )}
                            funcTiersData={[
                              ...new Map(
                                DataReport.filter(
                                  (item) => item.projectId._id === x.projectId._id,
                                ).map((item123) => [item123.functionalAttributeId._id, item123]),
                              ).values(),
                            ]}
                          />
                        )
                      })}
                    </>
                  ) : null}
                </>
              )}
              {/* </CRow>
              </div> */}
            </CForm>

            {/*  Weekly Task Report for the Month  */}
            <CForm>
              {/* <CRow className=""> */}
              {/* <div>
                    {startDate && UniqueProDataweek.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        Weekly Task Report for the Month of {moment(startDate).format('MMMM')} from{' '}
                        <br />
                        {moment(startDate).format('DD MMM YYYY')} -{' '}
                        {moment(toDate).format('DD MMM YYYY')}{' '}
                      </h3>
                    ) : null}
                  </div> */}
              <div className=" d-flex align-items-center justify-content-between">
                {UniqueProDataweek.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        Weekly Task Report for the Month of {moment(startDate).format('MMMM')} from{' '}
                        {moment(startDate).format('DD MMM YYYY')} -{' '}
                        {moment(toDate).format('DD MMM YYYY')}{' '}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        type="submit"
                        onClick={(e) => {
                          e.preventDefault()
                          onClickDownloadFucweek()
                        }}
                        disabled={isDisabled}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {/* {!startDate && UniqueProData.length > 0 ? (
                        <> */}
              {UniqueProDataweek.map((x, i) => {
                return (
                  <TaskReportFunctions
                    className="escols"
                    key={i}
                    projectId={x.projectId._id}
                    projectName={'Project Name : ' + x.projectId.projectName}
                    projectReportData={DataReport.filter(
                      (item) => item.projectId._id === x.projectId._id,
                    )}
                    // funcTiersData={getMostFuncTiers(
                    //   DataReport.filter((item) => item.projectId._id === x.projectId._id),
                    // )}
                    techTiersData={getMostTechTiers(
                      DataReport.filter((item) => item.projectId._id === x.projectId._id),
                    )}
                    funcTiersData={[
                      ...new Map(
                        DataReport.filter((item) => item.projectId._id === x.projectId._id).map(
                          (item123) => [item123.functionalAttributeId._id, item123],
                        ),
                      ).values(),
                    ]}
                  />
                )
              })}
              {/* </>
                      ) : (
                        <h3 className="center">NO DATA FOUND</h3>
                      )} */}
              {/* </CRow> */}

              {/* Modal for Pdf Downloader */}
            </CForm>

            {/* Monthly Task Report */}
            <CForm>
              {/* <div>
                <CRow className=""> */}
              {/* <div>
                    {startDatem && UniqueProData.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        Monthly Task Report for the Month of{' '}
                        {moment(startDatem).format('MMMM YYYY')}
                      </h3>
                    ) : null}
                  </div> */}
              <div className="d-flex align-items-center justify-content-between">
                {UniqueProData.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        Monthly Task Report for the Month of{' '}
                        {moment(startDatem).format('MMMM YYYY')}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        type="submit"
                        // onClick={(e) => {
                        //   openModal()
                        //   e.preventDefault()
                        // }}
                        onClick={() => onClickDownloadFuc()}
                        disabled={isDisabled}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {UniqueProData.map((x, i) => {
                return (
                  <TaskReportFunctions
                    className="escols"
                    key={i}
                    projectId={x.projectId._id}
                    projectName={'Project Name : ' + x.projectId.projectName}
                    projectReportData={DataReport.filter(
                      (item) => item.projectId._id === x.projectId._id,
                    )}
                    // funcTiersData={getMostFuncTiers(
                    //   DataReport.filter((item) => item.projectId._id === x.projectId._id),
                    // )}
                    techTiersData={getMostTechTiers(
                      DataReport.filter((item) => item.projectId._id === x.projectId._id),
                    )}
                    funcTiersData={[
                      ...new Map(
                        DataReport.filter((item) => item.projectId._id === x.projectId._id).map(
                          (item123) => [item123.functionalAttributeId._id, item123],
                        ),
                      ).values(),
                    ]}
                  />
                )
              })}
              {/* </CRow>
              </div> */}

              {/* Modal for Pdf Downloader */}
            </CForm>

            {/*  Periodically Task Report */}
            <CForm>
              {/* <div>
                <CRow className=""> */}
              {/* <div>
                    {startDateper && UniqueProDataperiod.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        Periodically Task Report from <br />
                        {moment(startDateper).format('DD MMM YYYY')} -{' '}
                        {moment(toDatePer).format('DD MMM YYYY')}{' '}
                      </h3>
                    ) : null}
                  </div> */}
              <div className="d-flex align-items-center justify-content-between">
                {UniqueProDataperiod.length > 0 ? (
                  <>
                    <div>
                      <h3 className="escolsTitle">
                        Periodically Task Report from {moment(startDateper).format('DD MMM YYYY')} -{' '}
                        {moment(toDatePer).format('DD MMM YYYY')}{' '}
                      </h3>
                    </div>
                    <div>
                      <button
                        className="save mright"
                        type="submit"
                        // onClick={(e) => {
                        //   openModal()
                        //   e.preventDefault()
                        // }}
                        onClick={(e) => {
                          e.preventDefault()
                          onClickDownloadFucperiod()
                        }}
                        disabled={isDisabled}
                      >
                        Download Report
                      </button>
                    </div>
                  </>
                ) : null}
              </div>
              {/* {!startDate && UniqueProData.length > 0 ? (
                        <> */}
              {UniqueProDataperiod.map((x, i) => {
                return (
                  <TaskReportFunctions
                    className="escols"
                    key={i}
                    projectId={x.projectId._id}
                    projectName={'Project Name : ' + x.projectId.projectName}
                    projectReportData={DataReport.filter(
                      (item) => item.projectId._id === x.projectId._id,
                    )}
                    // funcTiersData={getMostFuncTiers(
                    //   DataReport.filter((item) => item.projectId._id === x.projectId._id),
                    // )}
                    techTiersData={getMostTechTiers(
                      DataReport.filter((item) => item.projectId._id === x.projectId._id),
                    )}
                    funcTiersData={[
                      ...new Map(
                        DataReport.filter((item) => item.projectId._id === x.projectId._id).map(
                          (item123) => [item123.functionalAttributeId._id, item123],
                        ),
                      ).values(),
                    ]}
                  />
                )
              })}
              {/* </>
                      ) : (
                        <h3 className="center">NO DATA FOUND</h3>
                      )} */}
              {/* </CRow>
              </div> */}

              {/* Modal for Pdf Downloader */}
            </CForm>
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
