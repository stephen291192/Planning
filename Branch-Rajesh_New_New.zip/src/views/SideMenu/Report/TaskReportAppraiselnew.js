import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import { generateReport, projectmaptable, roleTable } from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'

export const TaskReportAppraiselnew = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [projectDrop, setProjectDrop] = useState([])
  const [projectValue, setProjectValue] = useState('')
  const [tableData, setTableData] = useState([])

  const [tableShow, setTableShow] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [date, setDate] = useState('')
  const [week, setWeek] = useState(false)
  const [month, setMonth] = useState(false)

  const [listData, setListData] = useState('')

  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [reportbtn, setreportbtn] = React.useState(false)
  const ref = React.createRef()

  const openModal = () => {
    setIsOpen(true)
  }

  const closeModal = () => {
    setIsOpen(false)
  }

  const optionsans = {
    orientation: 'landscape',
  }

  const options = [
    { value: 'chocolate', label: 'yet to start' },
    { value: 'strawberry', label: 'In Progress' },
    { value: 'vanilla', label: 'Completed' },
    { value: 'hold', label: 'Hold' },
  ]

  const task = [
    { value: 'chocolateq', label: 'Daily' },
    { value: 'strawberryq', label: 'Weekly' },
    { value: 'vanillaq', label: 'Monthly' },
  ]

  const monthly = [
    { value: 'jan', label: 'January' },
    { value: 'feb', label: 'February' },
    { value: 'mar', label: 'March' },
    { value: 'apr', label: 'April' },
    { value: 'may', label: 'May' },
    { value: 'jun', label: 'June' },
    { value: 'jul', label: 'July' },
    { value: 'aug', label: 'August' },
    { value: 'sep', label: 'September' },
    { value: 'oct', label: 'October' },
    { value: 'nov', label: 'November' },
    { value: 'dec', label: 'December' },
  ]

  const taskChange = (e) => {
    if (e.value === 'chocolateq') {
      setTableShow(true)
      setreportbtn(true)
      setWeek(false)
      setMonth(false)
    }
    if (e.value === 'strawberryq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(true)
      setMonth(false)
    }
    if (e.value === 'vanillaq') {
      setTableShow(false)
      setreportbtn(false)
      setWeek(false)
      setMonth(true)
    }
  }

  useEffect(() => {
    selectProject(state.employeeId._id)
    taskTable()
  }, [])

  const selectProject = async (employeeId) => {
    var response
    try {
      response = await projectmaptable(employeeId)
      if (response) {
        const data = response.data.projects.map((x) => {
          return {
            value: x._id,
            label: x.projectName,
          }
        })
        setProjectDrop(data)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const columns = [
    {
      key: 'S_no',
      label:'S.No',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'project',
      label: 'Project Name',
      _style: { width: '15%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'functionalattributeName',
      label: 'Functional Specification',
      _style: { width: '25%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'technicalattributeName',
      label: 'Technical Specification',
      _style: { width: '25%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'TodayActivity',
      label: 'Activity',
      _style: { width: '15%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'plannedduration',
      label: 'Planned Duration',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EstimatedStartDate',
      label: 'Start Time',
      _style: { width: '18%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EstimatedEndDate',
      label: 'End Time',
      _style: { width: '17%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'actualduration',
      label: 'Actual Duration',
      _style: { width: '14%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'actualStartDate',
      label: 'Actual Start Time',
      _style: { width: '12%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'actualEndDate',
      label: 'Actual End Time',
      _style: { width: '12%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'status',
      label: 'Status',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'summary',
      label: 'Summary',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
  ]

  const taskTable = async () => {
    setTableData([])
    let today = new Date().toISOString().slice(0, 10)
    const data = {
      date: today,
    }
    try {
      const response = await generateReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x, i) => {
              return {
                S_no: i + 1,
                project: x.projectId.projectName,
                functionalattributeName: `${
                  x.functionalAttributeId.attributeName
                } - ${x.functionalVariableDetails.map((x) => x.variableName)} `,
                technicalattributeName: `${
                  x.technicalAttributeId.attributeName
                } - ${x.technicalVariableDetails.map((x) => x.variableName)} `,
                TodayActivity: x.description,
                plannedduration: x.plannedDuration,
                EstimatedStartDate: x.est,
                EstimatedEndDate: x.eft,
                actualduration: x.actualDuration,
                actualStartDate: x.ast,
                actualEndDate: x.aft,
                status: x.Status,
                summary: x.remark,
                label: `${x.employeeId.firstName} ${x.employeeId.lastName}`,
              }
            })
            setTableData(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
            <CCard className="mb-6">
              <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">Appraisal Report</h3>
                </div>
              </div>
              <CCardBody>
                <CForm>
                  <div>
                    <CRow className="mt-5">
                      <div>
                        {tableData.length > 0 ? (
                          <h5 className="pdfModelTitle1 escols">
                            {state.companies.find((x) => x.value == state.companyId)?.label}
                          </h5>
                        ) : null}
                      </div>
                      {tableData.length > 0 ? (
                        <CTable
                          bordered
                          responsive
                          activePage={1}
                          clickableRows
                          columns={columns}
                          columnFilter
                          columnSorter
                          items={tableData}
                          scopedColumns={{
                            show_details: (item) => {
                              return (
                                <td>
                                  <Select
                                    defaultValue={options[0]}
                                    onChange={setListData}
                                    options={options}
                                    className={'inputfieldso txtransform'}
                                  />
                                </td>
                              )
                            },
                            // EstimatedStartDate: (start) => {
                            //   return (
                            //     <td>
                            //       <CFormInput type="date" className="inputfieldgo" />
                            //     </td>
                            //   )
                            // },
                            // EstimatedEndDate: (start) => {
                            //   return (
                            //     <td>
                            //       <CFormInput type="date" className="inputfieldgo" />
                            //     </td>
                            //   )
                            // },
                          }}
                          sorterValue={{ column: 'name', state: 'asc' }}
                          tableProps={{
                            striped: true,
                            hover: true,
                            responsive: true,
                          }}
                        />
                      ) : (
                        <h3 className="center">NO DATA FOUND</h3>
                      )}
                    </CRow>
                  </div>
                  <div className="d-flex flex-row justify-content-end mt-3">
                    {tableData.length > 0 ? (
                      <div>
                        <button
                          className="loginBtn1 mright"
                          type="submit"
                          onClick={(e) => {
                            openModal()
                            e.preventDefault()
                          }}
                        >
                          Report
                        </button>
                      </div>
                    ) : null}
                  </div>
                  {/* Modal for Pdf Downloader */}
                  <React.Fragment>
                    <CModal
                      size="xl"
                      visible={modalIsOpen}
                      onClose={() => {
                        closeModal()
                      }}
                    >
                      <ReactToPdf targetRef={ref} options={optionsans} filename="Report.pdf">
                        {({ toPdf }) => (
                          <div className="PdfButton">
                            <button
                              onClick={() => {
                                toPdf()
                                closeModal()
                              }}
                              className="pdfbtnsDwn"
                            >
                              Download <ImDownload3 size="15" />
                            </button>
                          </div>
                        )}
                      </ReactToPdf>
                      <div id="printablediv">
                        <div ref={ref}>
                          {console.log(state.companyLogo)}
                          {/* <div>
              
            </div> */}

                          <div className="PdfTableHeader">
                            {state?.companyLogo !== '' && (
                              <img src={state.companyLogo} alt="" className="LogoPDFPicture" />
                            )}
                            <div className="d-flex flex-column">
                              <h3 className="pdfModelTitle">
                                {state.companies.find((x) => x.value == state.companyId)?.label}
                              </h3>
                              <h6 className="retporttabledetail">
                                Detailed Today Appraisal Report of {state.userName}
                              </h6>
                            </div>
                            <div></div>
                          </div>

                          <div className="d-flex flex-row justify-content-around mt-5">
                            {/* <div>
                              {' '}
                              <span className="subhead">User Login:</span>{' '}
                              <span className="username">{state.userName}</span>
                            </div> */}
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div>
                              <span className="subhead">Date:</span>
                              <span className="username">
                                {new Date().toLocaleDateString('en-us', {
                                  // weekday: 'short',
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric',
                                })}
                              </span>
                            </div>
                          </div>

                          <div className="PdfTable">
                            <CTable
                              bordered
                              responsive
                              // itemsPerPageSelect
                              // activePage={1}
                              // cleaner
                              clickableRows
                              columns={columns.filter((x) => x.label != 'Action')}
                              // columnFilter
                              // columnSorter

                              items={tableData}
                              itemsPerPage={Number(itemsPerPage)}
                              sorterValue={{ column: 'name', state: 'asc' }}
                              tableProps={{
                                striped: true,
                                hover: true,
                              }}
                              className="repottable"
                            />
                          </div>
                        </div>
                      </div>
                    </CModal>
                  </React.Fragment>
                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
