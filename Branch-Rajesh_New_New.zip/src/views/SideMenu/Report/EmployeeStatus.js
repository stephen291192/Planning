import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  projectmaptable,
  empbyproject,
  downloadAppraisalTodayPdf,
  getEmployeeStatusCount,projectdropdown,empbyprojectNew
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { MultiSelect } from 'react-multi-select-component'
import { toast } from 'react-toastify'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import momentBusinessDays from 'moment-business-days'
import loadingGif from '../../../assets/images/loading-gif.gif'

momentBusinessDays.updateLocale('us', {
  workingWeekdays: [1, 2, 3, 4, 5, 6],
})

export const EmployeeStatus = () => {
  const { state, dispatch } = useContext(GlobalContext)

  const [projectId, setProjectId] = useState('')
  const [empData, setempData] = useState([])

  console.log(state, 'USER DATA')
  const [projectDrop, setProjectDrop] = useState([])
  const [userDrop, setUserDrop] = useState([])
  const [userEmps, setuserEmps] = useState([])
  const [empCountData, setempCountData] = useState([])
  const [completedCount, setcompletedCount] = useState(0)
  const [isDisabled, setIsDisabled] = useState(false)

  const ref = React.createRef()

  const [isLoading, setisLoading] = useState(false)

  useEffect(() => {
    selectProject()
  }, [])

  const selectProject = async () => {
    var response
    try {
      response = await projectdropdown(state.companyId)
      if (response) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: x.projectName,
          }
        })
        setProjectDrop(data)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const EmployeeCount = (data) => {
    const getEmpData = async (value) => {
      let EmpCount = await getEmployeeStatusCount(value)

      if (EmpCount.success) {
        console.log(EmpCount, 'HHHHHHHHHHHHHHHH')
        return { value: EmpCount }
      } else {
        return ''
      }
    }

    getEmpData(data)
  }

  const viewReportsData = async () => {
    setisLoading(true)
    let Arr2 = []
    for (let i = 0; i < empData.length; i++) {
      let empdataqw = {
        employee: empData[i].value,
        projectId: projectId.value,
      }

      let EmpCount = await getEmployeeStatusCount(empdataqw)
      console.log(EmpCount, 'HHHHHHHHHHHHHHHH')
      let ResultData = {
        employee: EmpCount.success ? EmpCount.data : '',
        value: empData[i].value,
        label: empData[i].label,
      }

      console.log(ResultData, 'HHHHHHHHHHHHHHHH')

      Arr2.push(ResultData)
    }

    setUserDrop(Arr2)
    setisLoading(false)
  }

  const SelectEmployee = async (e) => {
    setempData(e)
    console.log(e, 'FFFFFFFFFFFFFFF')
  }

  const showUser = async (projectId) => {
    var response
    try {
      response = await empbyprojectNew(projectId)
      console.log(response, 'lpopop')
      if (response) {
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x) => {
              return {
                value: x?.employeeId?._id,
                label: `${x.firstName} ${x.lastName}`,
              }
            })
            setuserEmps(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const onClickDownloadFuc = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (userDrop.length > 0) {
      data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`
      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">S.No</th>`

      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Project</th>`

      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Employee</th>`

      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                        padding: 5px;font-size:9px;
                        text-align: center;
                        background-color: #3c4b64;
                        color: white;" class="tableHeader">Completed</th>`

      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">InProgress</th>`

      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Pending</th>`

      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Scheduled</th>`

      data =
        data +
        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">UnScheduled</th>`

      userDrop.map(async (x, i) => {
        data = data + '<tr>'

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${projectId.label}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${x.label}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
padding: 5px; 5px;color: green;
font-weight: 600;
font-size: 17px;" >${x.employee?.completed}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
padding: 5px;color: #c1c126;
font-weight: 600;
font-size: 17px;" >${x.employee?.inprogress}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
padding: 5px;color: red;
font-weight: 600;
font-size: 17px;" >${x.employee?.pendingTask}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
padding: 5px;color: blue;
font-weight: 600;
font-size: 17px;" >${x.employee?.scheduled}</td>`

        data =
          data +
          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
padding: 5px;color: pink;
font-weight: 600;
font-size: 17px;" >${x.employee?.unscheduled}</td>`

        return data
      })

      data = data + '<tr>'

      data =
        data +
        `<td colspan="3" style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >Total</td>`

      data =
        data +
        `<td  style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
            padding: 5px;color: green;
            font-weight: 600;
            font-size: 17px;" >${userDrop.reduce(
              (a, v) => (a = a + v.employee?.completed),
              0,
            )}</td>`
      data =
        data +
        `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;color: #c1c126;
          font-weight: 600;
          font-size: 17px;" >${userDrop.reduce((a, v) => (a = a + v.employee?.inprogress), 0)}</td>`
      data =
        data +
        `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;color: red;
          font-weight: 600;
          font-size: 17px;" >${userDrop.reduce(
            (a, v) => (a = a + v.employee?.pendingTask),
            0,
          )}</td>`
      data =
        data +
        `<td  style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;color: blue;
          font-weight: 600;
          font-size: 17px;" >${userDrop.reduce((a, v) => (a = a + v.employee?.scheduled), 0)}</td>`
      data =
        data +
        `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;color: pink;
          font-weight: 600;
          font-size: 17px;" >${userDrop.reduce(
            (a, v) => (a = a + v.employee?.unscheduled),
            0,
          )}</td>`

      data = data + '</tr>'

      data = data + `</table>`
    }

    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {`Employee Status Count Report of ${projectId.label}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `EmployeeStatusReport_${projectId.label}_${moment().format(
          'MMMM Do YYYY, h:mm:ss a',
        )}.pdf`
        // a.download = `${
        //   String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        // }_MonthlyTaskReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
          <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">Employee Project Status</h3>
                </div>
              </div>
            <CCard className="mb-6">
             
              <CCardBody>
                <CForm>
                  <CRow className="mb-3">
                    <CRow className="col-sm-3 mb-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Select Project <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <Select
                          className={'inputfieldso'}
                          options={projectDrop}
                          value={projectId}
                          onChange={(e) => {
                            setProjectId(e)
                            showUser(e.value)
                          }}
                          placeholder="Select Project"
                          //   isDisabled={projectId}
                        />
                      </CCol>
                    </CRow>

                    <CRow className="col-sm-3 mb-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Select Employee <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <MultiSelect
                          options={userEmps}
                          value={empData && empData}
                          placeholder="Select Employee"
                          onChange={(e) => {
                            SelectEmployee(e)
                          }}
                        />
                      </CCol>
                    </CRow>

                    <div className="d-flex flex-row justify-content-end">
                      {empData.length > 0 && (
                        <div>
                          <button
                            className="loginBtn1 mright"
                            type="submit"
                            onClick={(e) => {
                              e.preventDefault()
                              viewReportsData(e)
                            }}
                          >
                            View
                          </button>
                        </div>
                      )}
                    </div>
                  </CRow>
                </CForm>
              </CCardBody>
            </CCard>
              <div>
                {isLoading ? (
                  <>
                    <div
                      className={'mt-4 mb-4'}
                      style={{ display: 'flex', justifyContent: 'center' }}
                    >
                      <img src={loadingGif} width="40px" />
                    </div>
                  </>
                ) : (
                  <>
                    {/* <div className="d-flex flex-row justify-content-end mb-3">
                      {userDrop.length > 0 ? (
                        <div><br />
                          <button
                            className="loginBtn1 mright"
                            type="submit"
                            // onClick={(e) => {
                            //   openModal()
                            //   e.preventDefault()
                            // }}
                            onClick={() => onClickDownloadFuc()}
                            disabled={isDisabled}
                          >
                            Download Report
                          </button>
                        </div>
                      ) : null}
                    </div> */}
                    {userDrop.length > 0 && (
                      <>
                      <div className="mt-3 mb-3 d-flex align-items-center justify-content-between">
                        <div className="font_Title pt-2 pb-0">Employee Status Count</div>
                        <div>
                          <button
                            className="loginBtn mright loginBtn_New"
                            onClick={() => onClickDownloadFuc()}
                          >
                             Download Report
                          </button>
                        </div>
                      </div>
                        {/* <h4>Employee Status Count</h4>
                        <br /> */}
                        <table className={'EmployeeList'}>
                          <thead>
                            <th>S.No</th>
                            <th>Project</th>
                            <th>Employee</th>
                            <th>Completed</th>
                            <th>Inprogress</th>
                            <th>Pending</th>
                            <th>Scheduled</th>
                            <th>UnScheduled</th>
                          </thead>
                          <tbody>
                            {userDrop.map((x, i, sum) => (
                              <tr key={i}>
                                <td>{i + 1}</td>
                                <td>{projectId.label}</td>
                                {/* {JSON.stringify(x)} */}
                                <td>{x.label}</td>
                                <td className={'comp_txt'}>{x.employee === "" ? 0 : x.employee?.completed}</td>
                                <td className={'inp_txt'}>{x.employee === "" ? 0 :x.employee?.inprogress}</td>
                                <td className={'pend_txt'}>{x.employee === "" ? 0 :x.employee?.pendingTask}</td>
                                <td className={'sche_txt'}>{x.employee === "" ? 0 :x.employee?.scheduled}</td>
                                <td className={'unsh_txt'}>{x.employee === "" ? 0 :x.employee?.unscheduled}</td>
                              </tr>
                            ))}
                            {userDrop.length > 0 && (
                             
                              <tr>
                                <td colSpan={3}>Total</td>
                              
                                <td className={'comp_txt'}>
                                  
                                  {userDrop.reduce((a, v) => (a = a +  v.employee?.completed), 0)}
                                
                                </td>
                                <td className={'inp_txt'}>
                                  {userDrop.reduce((a, v) => (a = a + v.employee?.inprogress), 0)}
                                </td>
                                <td className={'pend_txt'}>
                                  {userDrop.reduce((a, v) => (a = a + v.employee?.pendingTask), 0)}
                                </td>
                                <td className={'sche_txt'}>
                                  {userDrop.reduce((a, v) => (a = a + v.employee?.scheduled), 0)}
                                </td>
                                <td className={'unsh_txt'}>
                                  {userDrop.reduce((a, v) => (a = a + v.employee?.unscheduled), 0)}
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </>
                    )}
                  </>
                )}
              </div>
            <br />
            <br />
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
