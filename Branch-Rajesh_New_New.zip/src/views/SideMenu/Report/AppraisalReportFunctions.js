/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  TaskReportGenerate,
  projectmaptable,
  roleTable,
  downloadAppraisalTodayPdf,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { toast } from 'react-toastify'
import { AppraisalReportView } from '../Report/AppraisalReportView'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'

export const AppraisalReportFunctions = ({
  projectId,
  projectName,
  projectReportData,
  funcTiersData,
  techTiersData,
}) => {
  const { state, dispatch } = useContext(GlobalContext)

  const [tableData, setTableData] = useState([])

  const [FunctionsData, setFunctionsData] = useState([])

  useEffect(() => {
    taskTable()
  }, [])

  const taskTable = async () => {
    setTableData([])

    if (projectReportData.length > 0) {
      console.log(funcTiersData, 'PROJECT DATA')
      console.log(techTiersData, 'PROJECT DATA')

      const funcsunique = [
        ...new Map(
          funcTiersData.map((item123) => [item123.functionalAttributeId._id, item123]),
        ).values(),
      ]
      // console.log(unique, 'REPORT DATA VALUES')
      setFunctionsData(funcsunique)

      //   console.log(funcsunique, 'PROJECT DATA')
    } else {
      //   toast.error(response.error)
    }
  }

  return (
    <div>
      {FunctionsData.map((x, i) => {
        return (
          <AppraisalReportView
            key={i}
            projectId={projectId}
            projectName={projectName}
            projectReportData={projectReportData}
            funcTiersData={x}
            techTiersData={techTiersData}
            funcAttrId={x.functionalAttributeId._id}
          />
        )
      })}
    </div>
  )
}
