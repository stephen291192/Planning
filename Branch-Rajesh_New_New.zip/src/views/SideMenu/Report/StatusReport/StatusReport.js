import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  generateWeekMonthTaskReport,
  getUnscheduledreport,
  getScheduledreport,
  projectmaptable,
  getcompletedStatusReport,
  getTotalStatusReport,
  getBalanceStatusReport,
  empbyproject,
  roleTable,
  downloadAppraisalTodayPdf,projectdropdown,empbyprojectNew
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { StatusReportFunctions } from './StatusReportFunctions'
import { MultiSelect } from 'react-multi-select-component'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import momentBusinessDays from 'moment-business-days'
import loadingGif from '../../../../assets/images/loading-gif.gif'

momentBusinessDays.updateLocale('us', {
  workingWeekdays: [1, 2, 3, 4, 5, 6],
})

export const StatusReport = () => {
  const { state, dispatch } = useContext(GlobalContext)

  const [projectId, setProjectId] = useState('')
  const [statusType, setstatusType] = useState('')
  const [balanceType, setbalanceType] = useState('')
  const [empData, setempData] = useState([])

  console.log(state, 'USER DATA')
  const [projectDrop, setProjectDrop] = useState([])
  const [typeDrop, settypeDrop] = useState([])
  const [balanceDrop, setbalanceDrop] = useState([])
  const [userDrop, setUserDrop] = useState([])
  const [projectValue, setProjectValue] = useState('')
  const [tableData, setTableData] = useState([])

  const [tableShow, setTableShow] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [date, setDate] = useState('')
  const [week, setWeek] = useState(false)
  const [month, setMonth] = useState(false)

  const [listData, setListData] = useState('')

  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [reportbtn, setreportbtn] = React.useState(false)
  const ref = React.createRef()

  const [startDate, setStartDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [holidayDates, setHolidayDates] = useState([])
  const [isDisabled, setIsDisabled] = useState(false)

  const [isLoading, setisLoading] = useState(false)

  const [UniqueProData, setUniqueProData] = useState([])

  const openModal = () => {
    setIsOpen(true)
  }

  const closeModal = () => {
    setIsOpen(false)
  }

  const optionsans = {
    orientation: 'landscape',
  }


  useEffect(() => {
    selectProject()
  }, [])

  const statusTypeFunc = async () => {
    setTableData([])
    setUniqueProData([])
    settypeDrop([])
    setempData([])
    setstatusType('')
    setbalanceDrop([])
    let Typevals = [
      {
        label: 'Total',
        value: 'total',
      },
      {
        label: 'Balance',
        value: 'balance',
      },
      {
        label: 'Completed',
        value: 'completed',
      },
    ]
    settypeDrop(Typevals)
  }

  const SelectEmployee = async (e) => {
    settypeDrop([])
    statusTypeFunc()
    setempData(e)
  }

  const balsTypeFunc = async (e) => {
    // console.log(empData, 'IIIIIIIIIIIIIIIIIII')
    setTableData([])
    setUniqueProData([])
    setbalanceDrop([])
    setbalanceType('')
    if (e.value === 'balance') {
      let Balsdatas = [
        {
          label: 'UnScheduled',
          value: 'unscheduled',
        },
        {
          label: 'Scheduled',
          value: 'scheduled',
        },
        {
          label: 'Pending',
          value: 'Pending',
        },
        {
          label: 'InProgress',
          value: 'InProgress',
        },
      ]
      setbalanceDrop(Balsdatas)
    }
  }

  const selectProject = async () => {
    var response
    try {
      response = await projectdropdown(state.companyId)
      if (response) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: x.projectName,
          }
        })
        setProjectDrop(data)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const showUser = async (projectId) => {
    var response
    try {
      response = await empbyprojectNew(projectId)
      console.log(response, 'lpopop')
      if (response) {
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x) => {
              return {
                value: x?.employeeId?._id,
                label: `${x.firstName} ${x.lastName}`,
                // employeeId:x?.employeeId?._id,
              }
            })
            setUserDrop(data)
            console.log("fe",data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  function disableWeekends(date) {
    let day = new Date(date)
    day = day.getDay()
    return day !== 0
  }

  const dateDurationFuc = async (data, date1, dates, k) => {
    while (date1.length > 0) {
      let date = await dates
      date1 = await data.filter((x) => {
        if (moment(moment(date).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      if (date1.length > 0) {
        date = await momentBusinessDays(date).businessAdd(1)._d
      }
      dates = await date
    }
    return dates
  }

  const dateDuration = async (date, duration, data) => {
    let i = 0
    while (i < Number(duration)) {
      let dates = await date
      let k = i + 1
      let date1 = await data.filter(async (x) => {
        dates = await momentBusinessDays(dates).businessAdd(1)._d
        if (moment(moment(dates).format('YYYY-MM-DD')).isSame(moment(x).format('YYYY-MM-DD'))) {
          return true
        }
        return false
      })
      console.log(date1.length)
      if (date1.length > 0) {
        dates = await dateDurationFuc(data, date1, dates, k)
      }
      i = i + 1
      date = await dates
    }
    return date
  }

  const selectDateFuc = async (date) => {
    if (date) {
      setStartDate(date)
      taskTable(moment(date).format('YYYY-MM-DD'), moment(date).endOf('month').format('YYYY-MM-DD'))
      // getContentFuc(
      //     companyId,
      //     bookType._id,
      //     country._id,
      //     institution._id,
      //     tier._id,
      //     moment(date).format("DD-MM-YYYY"),
      //     moment(momentBusinessDays(date).businessAdd(6)._d).format("DD-MM-YYYY")
      // );
    }
  }

  const initalColumn = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '2%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'project',
      label: 'Project',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
  ]

  const RemainingInitialColumn = [
    {
      key: 'TodayActivity',
      label: 'Activity',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'AssignedBy',
      label: 'Assigned By',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'StartDate',
      label: 'Est. Start Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EndDate',
      label: 'Est. End Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    // {
    //   key: 'EstimatedStartTime',
    //   label: 'Est. Start Time',
    //   _style: { width: '18%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'EstimatedEndTime',
    //   label: 'Est. End Time',
    //   _style: { width: '17%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'plannedduration',
    //   label: 'Est. Duration (Mins)',
    //   _style: { width: '10%' },
    //   _props: { color: '#fff', className: 'fw-semibold' },
    //   filter: true,
    //   sorter: false,
    // },
  ]

  const [columns, setColumns] = useState(initalColumn)
  const [DataReport, setDataReport] = useState([])

  const getMostFuncTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.functionalTierDetails.length > max) {
        max = item.functionalTierDetails.length
        maxObj = [item]
      } else if (item.functionalTierDetails.length === max) {
        maxObj.push(item)
      }
    })

    return maxObj
  }

  const getMostTechTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      // console.log(item.technicalTierDetails, 'OOOOOOOOOOOOOOOOOOOOOO')
      if (item.technicalTierDetails !== null && item.technicalTierDetails !== undefined) {
        if (item.technicalTierDetails.length > max) {
          max = item.technicalTierDetails.length
          maxObj = [item]
        } else if (item.technicalTierDetails.length === max) {
          maxObj.push(item)
        }
      }
    })

    return maxObj
  }

  const CompletedEmpResults = async () => {
    setisLoading(true)
    setTableData([])
    setUniqueProData([])
    const data = {
      employees: empData,
      projectId: projectId.value,
    }
    try {
      const response = await getcompletedStatusReport(data)
      if (response) {
        if (response.success === true) {
          // if (response) {
            console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProData(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            // console.log(response.data, 'DJSJDS')
          // }
          // toast.success(response.message)
        } else {
          setUniqueProData([])
          toast.error(response.error)
        }
        setisLoading(false)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const TotalEmpResults = async () => {
    setisLoading(true)
    setTableData([])
    setUniqueProData([])
    const data = {
      employees: empData,
      projectId: projectId.value,
      status: 'Total',
    }
    try {
      const response = await getTotalStatusReport(data)
      // console.log(response, 'TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT')
      if (response) {
        if (response.success) {
          if (response.data) {
            // console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProData(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProData([])
          toast.error(response.error)
        }
        setisLoading(false)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const BalanceTypeResults = async (e) => {
    setisLoading(true)
    setTableData([])
    setUniqueProData([])
    if (e.value === 'unscheduled') {
      const data = {
        employees: empData,
        projectId: projectId.value,
      }
      try {
        const response = await getUnscheduledreport(data)
        if (response) {
          if (response.success) {
            if (response.data) {
              // console.log(response.data, 'REPORT DATA VALUES')
              const unique = [
                ...new Map(
                  response.data.map((item123) => [item123.projectId._id, item123]),
                ).values(),
              ]
              // console.log(unique, 'REPORT DATA VALUES')
              setUniqueProData(unique)

              // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
              setDataReport(response.data)
              console.log(response.data, 'DJSJDS')
            }
            // toast.success(response.message)
          } else {
            setUniqueProData([])
            toast.error(response.error)
          }
        }
      } catch (err) {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      }
    } else if (e.value === 'scheduled') {
      const data = {
        employees: empData,
        projectId: projectId.value,
      }
      try {
        const response = await getScheduledreport(data)
        if (response) {
          if (response.success) {
            if (response.data) {
              // console.log(response.data, 'REPORT DATA VALUES')
              const unique = [
                ...new Map(
                  response.data.map((item123) => [item123.projectId._id, item123]),
                ).values(),
              ]
              // console.log(unique, 'REPORT DATA VALUES')
              setUniqueProData(unique)

              // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
              setDataReport(response.data)
              console.log(response.data, 'DJSJDS')
            }
            // toast.success(response.message)
          } else {
            setUniqueProData([])
            toast.error(response.error)
          }
        }
      } catch (err) {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      }
    } else if (e.value === 'Pending' || e.value === 'InProgress') {
      // console.log(e.value, 'QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ')
      const data2 = {
        employees: empData,
        projectId: projectId.value,
        status: e.value,
      }
      try {
        const response = await getBalanceStatusReport(data2)
        if (response) {
          if (response.success) {
            if (response.data) {
              // console.log(response.data, 'REPORT DATA VALUES')
              const unique = [
                ...new Map(
                  response.data.map((item123) => [item123.projectId._id, item123]),
                ).values(),
              ]
              // console.log(unique, 'REPORT DATA VALUES')
              setUniqueProData(unique)

              // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
              setDataReport(response.data)
              console.log(response.data, 'DJSJDS')
            }
            // toast.success(response.message)
          } else {
            setUniqueProData([])
            toast.error(response.error)
          }
        }
      } catch (err) {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      }
    }
    setisLoading(false)
  }

  const taskTable = async (FromDate, ToDate) => {
    setTableData([])
    setUniqueProData([])
    const data = {
      //   projectId: [projectValue.value],
      employeeId: state.employeeId._id,
      fromDate: FromDate,
      toDate: ToDate,
    }
    try {
      const response = await generateWeekMonthTaskReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            // console.log(response.data, 'REPORT DATA VALUES')
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProData(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProData([])
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const tConvertDate = (date) => {
    var RDate = date.split('T')[0]
    var RDate = moment(RDate).format('DD MMM YYYY')
    return RDate // return adjusted time or original string
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  const onClickDownloadFuc = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProData.length > 0) {
      UniqueProData.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        // data =
        //   data +
        //   `<h4 style="width:100%;text-align:center;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        // Project - ${x.projectId.projectName}
        // </h4>`
        // if (x.reportingEmployee !== null) {
        //   data =
        //     data +
        //     `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        // Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        // </h4>`
        // }
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            let techsunique, techsunique2, TechniclslaUnique
            if (statusType.value === 'total') {
              techsunique = [
                ...new Map(
                  DataReport.filter(
                    (item) =>
                      item.projectId._id === x.projectId._id &&
                      item?.functionalAttributeId?._id === z?.functionalAttributeId?._id &&
                      item.Status !== 'UnScheduled',
                  ).map((item1234) => [item1234?.technicalAttributeId?._id, item1234]),
                ).values(),
                ...new Map(
                  DataReport.filter(
                    (item) =>
                      item.projectId._id === x.projectId._id &&
                      item?.functionalAttributeId?._id === z?.functionalAttributeId?._id &&
                      item.Status === 'UnScheduled',
                  ).map((item1234) => [item1234.Status === 'UnScheduled', item1234]),
                ).values(),
              ]

              // techsunique2 = [
              //   ...new Map(
              //     DataReport.filter(
              //       (item) =>
              //         item.projectId._id === x.projectId._id &&
              //         item?.functionalAttributeId?._id === z?.functionalAttributeId?._id &&
              //         item.Status === 'UnScheduled',
              //     ).map((item1234) => [item1234.Status === 'UnScheduled', item1234]),
              //   ).values(),
              // ]
            } else {
              TechniclslaUnique = [
                ...new Map(
                  DataReport.filter(
                    (item) =>
                      item.projectId._id === x.projectId._id &&
                      item.technicalAttributeId !== null &&
                      item?.functionalAttributeId?._id === z?.functionalAttributeId?._id,
                  ).map((item1234) => [item1234?.technicalAttributeId?._id, item1234]),
                ).values(),
                ...new Map(
                  DataReport.filter(
                    (item) =>
                      item.projectId._id === x.projectId._id &&
                      item.technicalAttributeId === null &&
                      item?.functionalAttributeId?._id === z?.functionalAttributeId?._id,
                  ).map((item1234) => [item1234?.technicalAttributeId === null, item1234]),
                ).values(),
              ]
            }

            // console.log(
            //   TechniclslaUnique.filter((it) => it.technicalTierDetails !== null),
            //   'EEEEEEEEEEEEEE',
            // )

            if (statusType.value === 'total') {
              if (techsunique.length > 0) {
                // techsunique
                //   .filter((it) => it.technicalTierDetails !== null)
                //   .map((a, s) => {
                techsunique.map((a, s) => {
                  data =
                    data +
                    `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`
                  console.log(z, 'UUUUUUUUUUUUUUUUUUUUUUU')
                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">S.No</th>`

                  z.functionalTierDetails.map(async (x, i) => {
                    data =
                      data +
                      `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                        padding: 5px;font-size:9px;
                        text-align: center;
                        background-color: #3c4b64;
                        color: white;" class="tableHeader">${x.value}</th>`

                    return data
                  })

                  if (a.technicalTierDetails !== null && a.technicalTierDetails !== undefined) {
                    a.technicalTierDetails.map(async (x, i) => {
                      data =
                        data +
                        `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">${x.value}</th>`

                      return data
                    })
                  }

                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Activity</th>`

                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Work Description</th>`

                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Assigned By</th>`

                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">Est. Start Date</th>`

                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Est. End Date</th>`

                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Status</th>`

                  // columns.map(async (x, i) => {
                  //   data =
                  //     data +
                  //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  //         padding: 5px;font-size:9px;
                  //         text-align: center;
                  //         background-color: #3c4b64;
                  //         color: white;" class="tableHeader">${x.label}</th>`

                  //   return data
                  // })

                  // console.log(columns, 'PDF REPORT DATA')

                  // let jii = 0;

                  DataReport.filter(
                    (item) =>
                      item.projectId._id === x.projectId._id &&
                      item?.functionalAttributeId?._id === z?.functionalAttributeId?._id &&
                      item?.technicalAttributeId?._id === a?.technicalAttributeId?._id,
                  ).map(async (x, i) => {
                    let dDesc
                    if (x.taskDescription) {
                      dDesc = document.createElement('div')
                      dDesc.innerHTML = x.taskDescription
                    } else {
                      dDesc = document.createElement('div')
                      dDesc.innerHTML = x.taskDescription
                    }

                    data = data + '<tr>'

                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
            padding: 5px;" >${i + 1}</td>`

                    z.functionalTierDetails.map(async (y, i) => {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                  padding: 5px;">${
                    x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                      ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                          .variableName
                      : ' - '
                  }</td>`

                      return data
                    })

                    if (a.technicalTierDetails !== null && a.technicalTierDetails !== undefined) {
                      a.technicalTierDetails.map(async (z, i) => {
                        data =
                          data +
                          `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                  padding: 5px;">${
                    x.technicalVariableDetails === null
                      ? ' - '
                      : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                          .length === 0
                      ? ' - '
                      : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                          ?.variableName
                  }</td>`

                        return data
                      })
                    }

                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;" >`

                    if (z.functionalTierDetails.length > 0) {
                      data = data + `<b>Requirement</b> - `
                    }

                    z.functionalTierDetails.map(async (y, i) => {
                      data =
                        data +
                        `${
                          x.functionalVariableDetails.filter((item) => item.tierId === y._id)
                            .length > 0
                            ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                                .variableName
                            : ' - '
                        }`

                      return data
                    })

                    if (a.technicalTierDetails !== null && a.technicalTierDetails !== undefined) {
                      data = data + `, <b>Technology</b> - `
                      a.technicalTierDetails.map(async (z, i) => {
                        data =
                          data +
                          `${
                            x.technicalVariableDetails === null
                              ? ' - '
                              : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                                  .length === 0
                              ? ' - '
                              : x.technicalVariableDetails.filter(
                                  (item) => item.tierId === z._id,
                                )[0]?.variableName
                          }`

                        return data
                      })
                    }

                    data = data + `</td>`

                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;" >${x.employeeId.firstName} ${x.employeeId.lastName}</td>`

                    if (x.esd) {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              padding: 5px;" >${tConvertDate(x.esd)}</td>`
                    } else {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              padding: 5px;" ></td>`
                    }
                    if (x.efd) {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              padding: 5px;" >${tConvertDate(x.efd)}</td>`
                    } else {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              padding: 5px;" ></td>`
                    }

                    if (x.Status === 'Completed') {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;background-color:green;color:#fff;" >${x.Status}</td>`
                    } else if (x.Status === 'Scheduled') {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;background-color:#0b488e;color:#fff;" >${x.Status}</td>`
                    } else if (x.Status === 'UnScheduled') {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;background-color:yellow;color:#000;" >${x.Status}</td>`
                    } else if (x.Status === 'Pending') {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;background-color:red;color:#fff;" >${x.Status}</td>`
                    } else if (x.Status === 'InProgress') {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;background-color:orange;color:#fff;" >${x.Status}</td>`
                    } else {
                      data =
                        data +
                        `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
            padding: 5px;" >${x.Status}</td>`
                    }

                    // data =
                    //   data +
                    //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                    //   padding: 5px;" >${tConvert(x.est)}</td>`

                    // data =
                    //   data +
                    //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                    //   padding: 5px;" >${tConvert(x.eft)}</td>`

                    // data =
                    //   data +
                    //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                    //   padding: 5px;" >${String(x.plannedDuration)}</td>`

                    return data
                  })

                  console.log(DataReport, 'PDF REPORT DATA')

                  data = data + `</table>`
                })
              }

              //   if (techsunique2.length > 0) {
              //     techsunique2
              //       .filter((it) => it.technicalTierDetails !== null)
              //       .map((a, s) => {
              //         data =
              //           data +
              //           `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`
              //         console.log(z, 'UUUUUUUUUUUUUUUUUUUUUUU')
              //         data =
              //           data +
              //           `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //           padding: 5px;font-size:9px;
              //           text-align: center;
              //           background-color: #3c4b64;
              //           color: white;" class="tableHeader">S.No</th>`

              //         z.functionalTierDetails.map(async (x, i) => {
              //           data =
              //             data +
              //             `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //             padding: 5px;font-size:9px;
              //             text-align: center;
              //             background-color: #3c4b64;
              //             color: white;" class="tableHeader">${x.value}</th>`

              //           return data
              //         })

              //         if (a.technicalTierDetails !== null && a.technicalTierDetails !== undefined) {
              //           a.technicalTierDetails.map(async (x, i) => {
              //             data =
              //               data +
              //               `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //         padding: 5px;font-size:9px;
              //         text-align: center;
              //         background-color: #3c4b64;
              //         color: white;" class="tableHeader">${x.value}</th>`

              //             return data
              //           })
              //         }

              //         data =
              //           data +
              //           `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //       padding: 5px;font-size:9px;
              //       text-align: center;
              //       background-color: #3c4b64;
              //       color: white;" class="tableHeader">Activity</th>`

              //         data =
              //           data +
              //           `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //         padding: 5px;font-size:9px;
              //         text-align: center;
              //         background-color: #3c4b64;
              //         color: white;" class="tableHeader">Assigned By</th>`

              //         data =
              //           data +
              //           `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //           padding: 5px;font-size:9px;
              //           text-align: center;
              //           background-color: #3c4b64;
              //           color: white;" class="tableHeader">Est. Start Date</th>`

              //         data =
              //           data +
              //           `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //     padding: 5px;font-size:9px;
              //     text-align: center;
              //     background-color: #3c4b64;
              //     color: white;" class="tableHeader">Est. End Date</th>`

              //         // columns.map(async (x, i) => {
              //         //   data =
              //         //     data +
              //         //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              //         //         padding: 5px;font-size:9px;
              //         //         text-align: center;
              //         //         background-color: #3c4b64;
              //         //         color: white;" class="tableHeader">${x.label}</th>`

              //         //   return data
              //         // })

              //         // console.log(columns, 'PDF REPORT DATA')

              //         // let jii = 0;

              //         DataReport.filter(
              //           (item) =>
              //             item.projectId._id === x.projectId._id &&
              //             item?.functionalAttributeId?._id === z?.functionalAttributeId?._id &&
              //             item?.technicalAttributeId?._id === a?.technicalAttributeId?._id,
              //         ).map(async (x, i) => {
              //           let dDesc
              //           if (x.taskDescription) {
              //             dDesc = document.createElement('div')
              //             dDesc.innerHTML = x.taskDescription
              //           } else {
              //             dDesc = document.createElement('div')
              //             dDesc.innerHTML = x.description
              //           }

              //           data = data + '<tr>'

              //           data =
              //             data +
              //             `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
              // padding: 5px;" >${i + 1}</td>`

              //           z.functionalTierDetails.map(async (y, i) => {
              //             data =
              //               data +
              //               `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              //       padding: 5px;">${
              //         x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
              //           ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
              //               .variableName
              //           : ' - '
              //       }</td>`

              //             return data
              //           })

              //           if (a.technicalTierDetails !== null && a.technicalTierDetails !== undefined) {
              //             a.technicalTierDetails.map(async (z, i) => {
              //               data =
              //                 data +
              //                 `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              //       padding: 5px;">${
              //         x.technicalVariableDetails === null
              //           ? ' - '
              //           : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
              //               .length === 0
              //           ? ' - '
              //           : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
              //               ?.variableName
              //       }</td>`

              //               return data
              //             })
              //           }

              //           data =
              //             data +
              //             `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              // padding: 5px;" >${dDesc.innerText}</td>`

              //           data =
              //             data +
              //             `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              // padding: 5px;" >${x.employeeId.firstName} ${x.employeeId.lastName}</td>`

              //           if (x.esd) {
              //             data =
              //               data +
              //               `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvertDate(x.esd)}</td>`
              //           } else {
              //             data =
              //               data +
              //               `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" ></td>`
              //           }
              //           if (x.efd) {
              //             data =
              //               data +
              //               `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvertDate(x.efd)}</td>`
              //           } else {
              //             data =
              //               data +
              //               `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" ></td>`
              //           }

              //           // data =
              //           //   data +
              //           //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //           //   padding: 5px;" >${tConvert(x.est)}</td>`

              //           // data =
              //           //   data +
              //           //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //           //   padding: 5px;" >${tConvert(x.eft)}</td>`

              //           // data =
              //           //   data +
              //           //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //           //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              //           return data
              //         })

              //         console.log(DataReport, 'PDF REPORT DATA')

              //         data = data + `</table>`
              //       })
              //   }
            } else {
              if (balanceType.value === 'unscheduled') {
                data =
                  data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`
                console.log(z, 'UUUUUUUUUUUUUUUUUUUUUUU')
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">S.No</th>`

                z.functionalTierDetails.map(async (x, i) => {
                  data =
                    data +
                    `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">${x.value}</th>`

                  return data
                })

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Work Description</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Assigned By</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Start Date</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. End Date</th>`

                DataReport.filter(
                  
                  (item) =>
                    item.projectId._id === x.projectId._id &&
                    item?.functionalAttributeId?._id === z?.functionalAttributeId?._id,
                ).map(async (x, i) => {
                  let dDesc
                  if (x.taskDescription) {
                    dDesc = document.createElement('div')
                    dDesc.innerHTML = x.taskDescription
                  } else {
                    dDesc = document.createElement('div')
                    dDesc.innerHTML = x.taskDescription
                  }

                  data = data + '<tr>'

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
        padding: 5px;" >${i + 1}</td>`

                  z.functionalTierDetails.map(async (y, i) => {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
              padding: 5px;">${
                x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                  ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                      .variableName
                  : ' - '
              }</td>`

                    return data
                  })

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
padding: 5px;" >`

                  if (z.functionalTierDetails.length > 0) {
                    data = data + `<b>Requirement</b> - `
                  }

                  z.functionalTierDetails.map(async (y, i) => {
                    data =
                      data +
                      `${
                        x.functionalVariableDetails.filter((item) => item.tierId === y._id).length >
                        0
                          ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                              .variableName
                          : ' - '
                      }`

                    return data
                  })

                  data = data + `</td>`

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
        padding: 5px;" >${dDesc.innerText}</td>`

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
        padding: 5px;" >${x.employeeId.firstName} ${x.employeeId.lastName}</td>`

                  if (x.esd) {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)}</td>`
                  } else {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ></td>`
                  }
                  if (x.efd) {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.efd)}</td>`
                  } else {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ></td>`
                  }

                  return data
                })

                console.log(DataReport, 'PDF REPORT DATA')

                data = data + `</table>`
              } else if (TechniclslaUnique.length > 0) {
                data =
                  data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`
                console.log(z, 'UUUUUUUUUUUUUUUUUUUUUUU')
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:12px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">S.No</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Functional Requirements</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:12px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Technical Requirements</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:12px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Task Description</th>`

                //   z.functionalTierDetails.map(async (x, i) => {
                //     data =
                //       data +
                //       `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                //       padding: 5px;font-size:9px;
                //       text-align: center;
                //       background-color: #3c4b64;
                //       color: white;" class="tableHeader">${x.value}</th>`

                //     return data
                //   })

                //   if (a.technicalTierDetails !== null && a.technicalTierDetails !== undefined) {
                //     a.technicalTierDetails.map(async (x, i) => {
                //       data =
                //         data +
                //         `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                //   padding: 5px;font-size:9px;
                //   text-align: center;
                //   background-color: #3c4b64;
                //   color: white;" class="tableHeader">${x.value}</th>`

                //       return data
                //     })
                //   }

                //   data =
                //     data +
                //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                // padding: 5px;font-size:9px;
                // text-align: center;
                // background-color: #3c4b64;
                // color: white;" class="tableHeader">Activity</th>`

                //   data =
                //     data +
                //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                // padding: 5px;font-size:9px;
                // text-align: center;
                // background-color: #3c4b64;
                // color: white;" class="tableHeader">Work Description</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:12px;width:5%;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Assigned By</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:12px;width:5%;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Start Date</th>`

                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:12px;width:5%;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">End Date</th>`

                // columns.map(async (x, i) => {
                //   data =
                //     data +
                //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                //         padding: 5px;font-size:9px;
                //         text-align: center;
                //         background-color: #3c4b64;
                //         color: white;" class="tableHeader">${x.label}</th>`

                //   return data
                // })

                // console.log(columns, 'PDF REPORT DATA')

                // let jii = 0;
                // TechniclslaUnique.map((a, s) => {
                DataReport.filter(
                  (item) =>
                    item.projectId._id === x.projectId._id &&
                    item?.functionalAttributeId?._id === z?.functionalAttributeId?._id,
                  // && item?.technicalAttributeId?._id === a?.technicalAttributeId?._id,
                ).map(async (x, i) => {
                  let dDesc
                  if (x.taskDescription) {
                    dDesc = document.createElement('div')
                    dDesc.innerHTML = x.taskDescription
                  } else {
                    dDesc = document.createElement('div')
                    dDesc.innerHTML = x.taskDescription
                  }

                  data = data + '<tr>'

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:12px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
        padding: 5px;" >`

                  z.functionalTierDetails.map(async (y, i) => {
                    data =
                      data +
                      `${
                        x.functionalVariableDetails.filter((item) => item.tierId === y._id).length >
                        0
                          ? `${
                              x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                                .variableName
                            }`
                          : ''
                      }, `

                    if (z.functionalTierDetails.length === i + 1) {
                      data = data + `${dDesc.innerText}`
                    }

                    return data
                  })

                  data = data + `</td>`

                  if (x.technicalTierDetails !== null && x.technicalTierDetails !== undefined) {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
    padding: 5px;" >`

                    x.technicalTierDetails.map(async (z, i) => {
                      data =
                        data +
                        `${
                          x.technicalVariableDetails === null
                            ? ''
                            : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                                .length === 0
                            ? ''
                            : `${
                                x.technicalVariableDetails.filter(
                                  (item) => item.tierId === z._id,
                                )[0]?.variableName
                              }${x.technicalTierDetails.length === i + 1 ? '' : ', '}`
                        }`

                      return data
                    })

                    data = data + `</td>`
                  } else {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
    padding: 5px;" > - </td>`
                  }

                  //     z.functionalTierDetails.map(async (y, i) => {
                  //       data =
                  //         data +
                  //         `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                  // padding: 5px;">${
                  //   x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                  //     ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                  //         .variableName
                  //     : ' - '
                  // }</td>`

                  //       return data
                  //     })

                  //     if (a.technicalTierDetails !== null && a.technicalTierDetails !== undefined) {
                  //       a.technicalTierDetails.map(async (z, i) => {
                  //         data =
                  //           data +
                  //           `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                  // padding: 5px;">${
                  //   x.technicalVariableDetails === null
                  //     ? ' - '
                  //     : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                  //       0
                  //     ? ' - '
                  //     : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                  //         ?.variableName
                  // }</td>`

                  //         return data
                  //       })
                  //     }

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
            padding: 5px;" >`

                  z.functionalTierDetails.map(async (y, i) => {
                    data =
                      data +
                      `${
                        x.functionalVariableDetails.filter((item) => item.tierId === y._id).length >
                        0
                          ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                              .variableName
                          : ' - '
                      }`

                    if (z.functionalTierDetails.length === i + 1) {
                      data = data + `${dDesc.innerText}`
                    }
                    if (x.technicalTierDetails !== null && x.technicalTierDetails !== undefined) {
                      data = data + `, `
                    }

                    return data
                  })

                  // data = data + `${dDesc.innerText}`

                  if (x.technicalTierDetails !== null && x.technicalTierDetails !== undefined) {
                    x.technicalTierDetails.map(async (z, i) => {
                      data =
                        data +
                        `${
                          x.technicalVariableDetails === null
                            ? ''
                            : x.technicalVariableDetails.filter((item) => item.tierId === z._id)
                                .length === 0
                            ? ''
                            : `${
                                x.technicalVariableDetails.filter(
                                  (item) => item.tierId === z._id,
                                )[0]?.variableName
                              }${x.technicalTierDetails.length === i + 1 ? '' : ', '}`
                        }`

                      return data
                    })
                  }

                  data = data + `</td>`

                  //           data =
                  //             data +
                  //             `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                  // padding: 5px;" >${dDesc.innerText}</td>`

                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:12px;width:5%;   text-align: center;
          padding: 5px;" >${x.employeeId.firstName} ${x.employeeId.lastName}</td>`

                  if (x.esd) {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
            padding: 5px;" >${tConvertDate(x.esd)}</td>`
                  } else {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
            padding: 5px;" ></td>`
                  }
                  if (x.efd) {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
            padding: 5px;" >${tConvertDate(x.efd)}</td>`
                  } else {
                    data =
                      data +
                      `<td style="border: 1px solid #ddd; font-size:12px; width:5%;  text-align: center;
            padding: 5px;" ></td>`
                  }

                  // data =
                  //   data +
                  //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                  //   padding: 5px;" >${tConvert(x.est)}</td>`

                  // data =
                  //   data +
                  //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                  //   padding: 5px;" >${tConvert(x.eft)}</td>`

                  // data =
                  //   data +
                  //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                  //   padding: 5px;" >${String(x.plannedDuration)}</td>`
                  data = data + '</tr>'

                  return data
                })
                // })

                console.log(DataReport, 'PDF REPORT DATA')

                data = data + `</table>`
              }
            }
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '18px',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Project Management Software
              </p>
              <p
                style={{
                  fontSize: '18px',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {balanceType.value === 'unscheduled'
                  ? `UnScheduled Task of ${projectId.label}`
                  : balanceType.value === 'scheduled'
                  ? `All Scheduled Task Report of ${projectId.label}`
                  : balanceType.value === 'Pending'
                  ? `Scheduled - Pending Task of ${projectId.label}`
                  : balanceType.value === 'InProgress'
                  ? `Scheduled - InProgress Task of ${projectId.label}`
                  : statusType.value === 'completed'
                  ? `Scheduled - Completed Task of ${projectId.label}`
                  : statusType.value === 'total'
                  ? `Total Task of ${projectId.label}`
                  : ''}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download =
          balanceType.value === 'unscheduled'
            ? `UnScheduledStatusReport_${projectId.label}_${moment().format(
                'MMMM Do YYYY, h:mm:ss a',
              )}.pdf`
            : balanceType.value === 'scheduled'
            ? `ScheduledStatusReport_${projectId.label}_${moment().format(
                'MMMM Do YYYY, h:mm:ss a',
              )}.pdf`
            : balanceType.value === 'Pending'
            ? `PendingStatusReport_${projectId.label}_${moment().format(
                'MMMM Do YYYY, h:mm:ss a',
              )}.pdf`
            : balanceType.value === 'InProgress'
            ? `InProgressStatusReport_${projectId.label}_${moment().format(
                'MMMM Do YYYY, h:mm:ss a',
              )}.pdf`
            : statusType.value === 'completed'
            ? `CompletedStatusReport_${projectId.label}_${moment().format(
                'MMMM Do YYYY, h:mm:ss a',
              )}.pdf`
            : statusType.value === 'total'
            ? `TotalStatusReport_${projectId.label}_${moment().format(
                'MMMM Do YYYY, h:mm:ss a',
              )}.pdf`
            : `StatusReport_${projectId.label}_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        // a.download = `${
        //   String(state.firstName).toUpperCase() + String(state.lastName).toUpperCase()
        // }_MonthlyTaskReport_${moment().format('MMMM Do YYYY, h:mm:ss a')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
          <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">Status Report</h3>
                </div>
              </div>
            <CCard className="mb-6">
             
              <CCardBody>
                <CForm>
                  <CRow className="mb-3">
                    {/* <CRow className="col-sm-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Project Name <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <Select
                          className={'inputfieldso'}
                          options={projectDrop}
                          value={projectValue}
                          onChange={(e) => {
                            setProjectValue(e)
                            setStartDate('')
                            setToDate('')
                            setTableData([])
                          }}
                          placeholder="Project Name"
                        />
                      </CCol>
                    </CRow> */}
                    <CRow className="col-sm-3 mb-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Select Project <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <Select
                          className={'inputfieldso'}
                          options={projectDrop}
                          value={projectId}
                          onChange={(e) => {
                            setProjectId(e)
                            showUser(e.value)
                            statusTypeFunc()
                          }}
                          placeholder="Select Project"
                          //   isDisabled={projectId}
                        />
                      </CCol>
                    </CRow>

                    <CRow className="col-sm-3 mb-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Select Employee <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <MultiSelect
                          options={userDrop}
                          value={empData && empData}
                          placeholder="Select Employee"
                          onChange={(e) => {
                            SelectEmployee(e)
                          }}
                          // onChange={(e) => {
                          //   SelectEmployee()
                          // }}
                        />
                      </CCol>
                    </CRow>

                    <CRow className="col-sm-3 mb-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Type of Status <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <Select
                          className={'inputfieldso'}
                          options={typeDrop}
                          value={statusType}
                          onChange={(e) => {
                            setstatusType(e)
                            if (e.value === 'balance') {
                              balsTypeFunc(e)
                            } else if (e.value === 'completed') {
                              setbalanceDrop([])
                              setbalanceType('')
                              CompletedEmpResults(e)
                            } else if (e.value === 'total') {
                              setbalanceDrop([])
                              setbalanceType('')
                              TotalEmpResults(e)
                            } else {
                              setbalanceType('')
                              setTableData([])
                              setUniqueProData([])
                            }
                          }}
                          placeholder="Select Type"
                          //   isDisabled={projectId}
                        />
                      </CCol>
                    </CRow>
                    {balanceDrop.length > 0 && (
                      <CRow className="col-sm-3 mb-4">
                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                          Balance Status Type <code>*</code>
                        </CFormLabel>
                        <CCol sm={12}>
                          <Select
                            className={'inputfieldso'}
                            options={balanceDrop}
                            value={balanceType}
                            onChange={(e) => {
                              setbalanceType(e)
                              BalanceTypeResults(e)
                            }}
                            placeholder="Balance Type"
                            //   isDisabled={projectId}
                          />
                        </CCol>
                      </CRow>
                    )}
                  </CRow>
                </CForm>
              </CCardBody>
           </CCard>
              <div className='cardRemove'>
                {/* <CForm> */}
                
                  {/* <div>
                    <CRow className=""> */}
                      {isLoading ? (
                        <>
                          <div
                            className={'mt-4 mb-4'}
                            style={{ display: 'flex', justifyContent: 'center' }}
                          >
                            <img src={loadingGif} width="40px" />
                          </div>
                        </>
                      ) : (
                        <>
                        
                          <div className="mt-3 d-flex flex-row justify-content-end mb-3">
                            {UniqueProData.length > 0 ? (
                              <div>
                                <div className="d-flex align-items-center justify-content-between">
                                  {/* <div className="font_Title pt-2 pb-0">List of Role</div> */}
                                  <div>
                                    <button
                                      className="loginBtn mright loginBtn_New"
                                      onClick={() => onClickDownloadFuc()}
                                    >
                                      Download Report
                                    </button>
                                  </div>
                                </div>
                                {/* <button
                                  className="loginBtn1 mright"
                                  type="submit"
                                  // onClick={(e) => {
                                  //   openModal()
                                  //   e.preventDefault()
                                  // }}
                                  onClick={() => onClickDownloadFuc()}
                                  disabled={isDisabled}
                                >
                                  Download Report 01
                                </button> */}
                                
                              </div>
                            ) : null}
                          </div>
                          {UniqueProData.map((x, i) => {
                              
                            return (
                              <StatusReportFunctions
                              
                                key={i}
                                projectId={x.projectId._id}
                                projectName={"Project Name : " + x.projectId.projectName}
                                projectReportData={DataReport.filter(
                                  (item) => item.projectId._id === x.projectId._id,
                                )}
                                // funcTiersData={getMostFuncTiers(
                                //   DataReport.filter((item) => item.projectId._id === x.projectId._id),
                                // )}
                                techTiersData={DataReport.filter(
                                  (item) => item.projectId._id === x.projectId._id,
                                )}
                                // techTiersData={[
                                //   ...new Map(
                                //     DataReport.filter(
                                //       (item) => item.projectId._id === x.projectId._id,
                                //     ).map((item1234) => [
                                //       item1234.technicalAttributeId._id,
                                //       item1234,
                                //     ]),
                                //   ).values(),
                                // ]}
                                funcTiersData={[
                                  ...new Map(
                                    DataReport.filter(
                                      (item) => item.projectId._id === x.projectId._id,
                                    ).map((item123) => [
                                      item123.functionalAttributeId._id,
                                      item123,
                                    ]),
                                  ).values(),
                                ]}
                                balanceType={balanceType}
                                statusType={statusType}
                              />
                            )
                          })}
                        </>
                      )}
                    {/* </CRow>
                  </div> */}

                  {/* Modal for Pdf Downloader */}
                {/* </CForm> */}
              </div>
           
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
