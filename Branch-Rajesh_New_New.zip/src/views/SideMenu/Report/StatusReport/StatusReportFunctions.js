/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  TaskReportGenerate,
  projectmaptable,
  roleTable,
  downloadAppraisalTodayPdf,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { toast } from 'react-toastify'
import { StatusReportTechnicals } from './StatusReportTechnicals'
import { StatusReportTechnicalsTotal } from './StatusReportTechnicalsTotal'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'

export const StatusReportFunctions = ({
  projectId,
  projectName,
  projectReportData,
  funcTiersData,
  techTiersData,
  balanceType,
  statusType,
}) => {
  const { state, dispatch } = useContext(GlobalContext)

  const [tableData, setTableData] = useState([])

  useEffect(() => {
    taskTable()
  }, [])

  const initalColumn = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-bold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'project',
      label: 'Project',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-bold' },
      filter: true,
      sorter: false,
    },
  ]

  const RemainingInitialColumn = [
    {
      key: 'TodayActivity',
      label: 'Activity',
      _style: { width: '15%' },
      _props: { color: '#fff', className: 'fw-bold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EstimatedStartDate',
      label: 'Est. Start Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-bold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'EstimatedEndDate',
      label: 'Est. End Date',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-bold' },
      filter: true,
      sorter: false,
    },
    // {
    //   key: 'EstimatedStartTime',
    //   label: 'Est. Start Time',
    //   _style: { width: '15%' },
    //   _props: { color: '#fff', className: 'fw-bold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'EstimatedEndTime',
    //   label: 'Est. End Time',
    //   _style: { width: '15%' },
    //   _props: { color: '#fff', className: 'fw-bold' },
    //   filter: true,
    //   sorter: false,
    // },
    // {
    //   key: 'plannedduration',
    //   label: 'Est. Duration (Mins)',
    //   _style: { width: '5%' },
    //   _props: { color: '#fff', className: 'fw-bold' },
    //   filter: true,
    //   sorter: false,
    // },
  ]

  const [columns, setColumns] = useState(initalColumn)
  const [DataReport, setDataReport] = useState([])
  const [FunctionsData, setFunctionsData] = useState([])
  const [TechnicalsData, setTechnicalsData] = useState([])

  const taskTable = async () => {
    setTableData([])

    if (projectReportData.length > 0) {
      // console.log(projectReportData, 'PROJECT DATA')
      // console.log(funcTiersData, 'PROJECT DATA')
      // console.log(techTiersData, 'PROJECT DATA')

      const funcsunique = [
        ...new Map(
          funcTiersData.map((item123) => [item123.functionalAttributeId._id, item123]),
        ).values(),
      ]
      // console.log(unique, 'REPORT DATA VALUES')
      setFunctionsData(funcsunique)

      console.log(funcsunique, 'PROJECT DATA')

      // console.log(techTiersData.filter(g => g.functionalAttributeId._id ===), 'PROJECT DATA')

      //   const InterMediateColumn = projectReportData.map((x, i) => {
      //     const functionColumnName =
      //       funcTiersData.length > 0 &&
      //       funcTiersData[0].functionalTierDetails.map((y, i) => {
      //         // console.log(x.functionalTierDetails[i], 'TTTTTTTTTTTTTTTT')
      //         return {
      //           key: y._id,
      //           label: y.value,
      //           _style: { width: '10%' },
      //           _props: { color: '#fff', className: 'fw-bold' },
      //           filter: true,
      //           sorter: false,
      //         }
      //       })

      //     const TierColumnName =
      //       techTiersData.length > 0 &&
      //       techTiersData[0].technicalTierDetails.map((y, i) => {
      //         return {
      //           key: y._id,
      //           label: y.value,
      //           _style: { width: '10%' },
      //           _props: { color: '#fff', className: 'fw-bold' },
      //           filter: true,
      //           sorter: false,
      //         }
      //       })

      //     console.log(functionColumnName, 'PROJECT DATA')
      //     console.log(TierColumnName, 'PROJECT DATA')
      //     // const functionColumnName = x.functionalTierDetails.map((y, i) => {
      //     //   return {
      //     //     key: y._id,
      //     //     label: y.value,
      //     //     _style: { width: '10%' },
      //     //     _props: { color: '#fff', className: 'fw-bold' },
      //     //     filter: true,
      //     //     sorter: false,
      //     //   }
      //     // })

      //     //   const TierColumnName = x.technicalTierDetails.map((y, i) => {
      //     //     return {
      //     //       key: y._id,
      //     //       label: y.value,
      //     //       _style: { width: '10%' },
      //     //       _props: { color: '#fff', className: 'fw-bold' },
      //     //       filter: true,
      //     //       sorter: false,
      //     //     }
      //     //   })
      //     if (TierColumnName === false) {
      //       return [...functionColumnName]
      //     } else {
      //       return [...functionColumnName, ...TierColumnName]
      //     }

      //     // return [...functionColumnName]
      //   })
      //   console.log(InterMediateColumn, 'COLUMN VALUES')
      //   const getInterMediateColumn = getValue(InterMediateColumn[0], TYPES.ARRAY, [])
      //   console.log(getInterMediateColumn, 'COLUMN VALUES')
      //   setColumns([...initalColumn, ...getInterMediateColumn, ...RemainingInitialColumn])
      //   console.log(
      //     [...initalColumn, ...getInterMediateColumn, ...RemainingInitialColumn],
      //     'COLUMN VALUES',
      //   )
      //   setDataReport(projectReportData)
      //   console.log(projectReportData, 'DJSJDS')
      //   console.log(columns, 'DJSJDS')
      //   const data = projectReportData.map((x, i) => {
      //     let functionalVariableDetailsObject = {}
      //     let technicalVariableDetailsObject = {}
      //     const functionalVariableDetailsValues = funcTiersData[0].functionalTierDetails.map(
      //       (y, i) => {
      //         functionalVariableDetailsObject[getValue(y._id, TYPES.STRING, '')] = getValue(
      //           x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
      //             ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
      //                 .variableName
      //             : ' - ',
      //           TYPES.STRING,
      //           '',
      //         )
      //       },
      //     )

      //     console.log(x.technicalVariableDetails, 'DJSJDS')

      //     const technicalVariableDetailsValues =
      //       techTiersData.length > 0 &&
      //       techTiersData[0].technicalTierDetails.map((z, i) => {
      //         const displayVals =
      //           x.technicalVariableDetails === null
      //             ? ' - '
      //             : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length === 0
      //             ? ' - '
      //             : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
      //                 ?.variableName
      //         console.log(displayVals, 'DJSJDS')
      //         technicalVariableDetailsObject[getValue(z._id, TYPES.STRING, '')] = displayVals
      //       })

      //     // techTiersData[0].technicalTierDetails.map((y, i) => {
      //     //   console.log(
      //     //     x.technicalVariableDetails.filter((item) => item.tierId === y._id).length > 0
      //     //       ? x.technicalVariableDetails.filter((item) => item.tierId === y._id)[0].variableName
      //     //       : '',
      //     //     'DJSJDS',
      //     //   )
      //     // })

      //     console.log(techTiersData[0], 'DJSJDS')
      //     console.log(technicalVariableDetailsValues, 'DJSJDS')
      //     //   const technicalVariableDetailsValues = x.technicalVariableDetails.map((y, i) => {
      //     //     technicalVariableDetailsObject[getValue(y.tierId, TYPES.STRING, '')] = getValue(
      //     //       y.variableName,
      //     //       TYPES.STRING,
      //     //       '',
      //     //     )
      //     //   })

      //     // const firstfunc = x.functionalVariableDetails.map((x) => x.variableName)

      //     // const secfunc = funcTiersData[0].functionalTierDetails.map((y, i) =>
      //     //   x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
      //     //     ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0].variableName
      //     //     : ' - ',
      //     // )

      //     // const thirdfunc = techTiersData[0].technicalTierDetails.map((y, i) =>
      //     //   x.technicalVariableDetails === null
      //     //     ? ' - '
      //     //     : x.technicalVariableDetails.filter((item) => item.tierId === y._id).length > 0
      //     //     ? x.technicalVariableDetails.filter((item) => item.tierId === y._id)[0].variableName
      //     //     : ' - ',
      //     // )

      //     // console.log(firstfunc, 'NEW GETTING FUNC')

      //     // console.log(secfunc, 'NEW GETTING FUNC')

      //     // funcTiersData[0].functionalTierDetails.map((y, i) => {
      //     //   console.log(
      //     //     x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
      //     //       ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0].variableName
      //     //       : '',
      //     //     'DJSJDS',
      //     //   )
      //     // })
      //     //     return {
      //     //       functionalattributeName:
      //     //         //   `${x.functionalVariableDetails.map((x) => x.variableName)} `,
      //     //         `${funcTiersData[0].functionalTierDetails.map((x, i) =>
      //     //           x.functionalVariableDetails.filter((item) => item.tierId === x._id).length > 0
      //     //             ? x.functionalVariableDetails.filter((item) => item.tierId === x._id)[0]
      //     //                 .variableName
      //     //             : '',
      //     //         )}`,
      //     //     }
      //     //   })

      //     const dDesc = document.createElement('div')
      //     dDesc.innerHTML = x.description

      //     return {
      //       S_no: i + 1,
      //       project: x.projectId.projectName,
      //       functionalattributeName: `${x.functionalVariableDetails.map((x) => x.variableName)} `,
      //       //   technicalattributeName: `${x.technicalVariableDetails.map((x) => x.variableName)} `,
      //       TodayActivity: dDesc.innerText,
      //       EstimatedStartDate: tConvertDate(x.esd),
      //       EstimatedEndDate: tConvertDate(x.efd),
      //       // EstimatedStartTime: tConvert(x.est),
      //       // EstimatedEndTime: tConvert(x.eft),
      //       // plannedduration: String(x.plannedDuration),
      //       // actualduration: String(x.actualDuration),
      //       // actualStartDate: tConvert(x.ast),
      //       // actualEndDate: tConvert(x.aft),
      //       // differenceBetweenTwoDuration: String(
      //       //   Number(x.actualDuration) - Number(x.plannedDuration),
      //       // ),
      //       // status: x.Status,
      //       // summary: x.remark,
      //       label: `${x.employeeId.firstName} ${x.employeeId.lastName}`,
      //       ...functionalVariableDetailsObject,
      //       ...technicalVariableDetailsObject,
      //     }
      //   })
      //   console.log(columns, 'DJSJDS')
      //   console.log(data, 'DJSJDS')

      //   setTableData(data)
      // toast.success(response.message)
    } else {
      //   toast.error(response.error)
    }
  }

  const tConvertDate = (date) => {
    var RDate = date.split('T')[0]
    var RDate = moment(RDate).format('DD MMM YYYY')
    return RDate // return adjusted time or original string
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  return (
    <div>
      {statusType.value === 'total' ? (
        <>
          {FunctionsData.map((x, i) => {
            return (
              <StatusReportTechnicalsTotal
                key={i}
                projectId={projectId}
                projectName={projectName}
                projectReportData={projectReportData.filter(
                  (g) => g.functionalAttributeId._id === x.functionalAttributeId._id,
                )}
                funcTiersData={x}
                // techTiersData={techTiersData}
                techTiersData={techTiersData.filter(
                  (g) => g.functionalAttributeId._id === x.functionalAttributeId._id,
                )}
                funcAttrId={x.functionalAttributeId._id}
                balanceType={balanceType}
                statusType={statusType}
              />
            )
          })}
        </>
      ) : (
        <>
          {FunctionsData.map((x, i) => {
            return (
              <StatusReportTechnicals
                key={i}
                projectId={projectId}
                projectName={projectName}
                projectReportData={projectReportData.filter(
                  (g) => g.functionalAttributeId._id === x.functionalAttributeId._id,
                )}
                funcTiersData={x}
                // techTiersData={techTiersData}
                techTiersData={techTiersData.filter(
                  (g) => g.functionalAttributeId._id === x.functionalAttributeId._id,
                )}
                funcAttrId={x.functionalAttributeId._id}
                balanceType={balanceType}
                statusType={statusType}
              />
            )
          })}
        </>
      )}
    </div>
  )
}
