import React, { useState, useEffect, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import {
  generateReport,
  projectmaptable,
  roleTable,
  downloadAppraisalTodayPdf,
} from 'src/services/ApiServices'
import { GlobalContext } from 'src/context'
import { AppraisalReportFunctions } from '../Report/AppraisalReportFunctions'
import { toast } from 'react-toastify'
import {
  CSmartTable,
  CBadge,
  CCollapse,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { CTable } from '@coreui/react'

import ReactToPdf from 'react-to-pdf'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { Link, Navigate } from 'react-router-dom'
import { getValue, TYPES } from 'src/services/utility'
import moment from 'moment'
import { renderToString } from 'react-dom/server'
import parse from 'html-react-parser'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import momentBusinessDays from 'moment-business-days'

momentBusinessDays.updateLocale('us', {
  workingWeekdays: [1, 2, 3, 4, 5, 6],
})

export const TodayReportAppraisel = () => {
  const { state, dispatch } = useContext(GlobalContext)

  console.log(state, 'USER DATA')
  const [projectDrop, setProjectDrop] = useState([])
  const [projectValue, setProjectValue] = useState('')
  const [tableData, setTableData] = useState([])

  const [tableShow, setTableShow] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [date, setDate] = useState('')
  const [week, setWeek] = useState(false)
  const [month, setMonth] = useState(false)

  const [listData, setListData] = useState('')

  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [reportbtn, setreportbtn] = React.useState(false)
  const [UniqueProData, setUniqueProData] = useState([])
  const [isDisabled, setIsDisabled] = useState(false)
  const [selectedTodayDate, setselectedTodayDate] = useState('')

  const ref = React.createRef()

  // useEffect(() => {
  //   taskTable()
  // }, [])

  //   const [columns, setColumns] = useState(initalColumn)
  const [DataReport, setDataReport] = useState([])

  const getMostFuncTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.functionalTierDetails.length > max) {
        max = item.functionalTierDetails.length
        maxObj = [item]
      } else if (item.functionalTierDetails.length === max) {
        maxObj.push(item)
      }
    })

    return maxObj
  }

  const getMostTechTiers = (o) => {
    var max = 0,
      maxObj = []

    o.map((item) => {
      if (item.technicalTierDetails !== null) {
        if (item.technicalTierDetails.length > max) {
          max = item.technicalTierDetails.length
          maxObj = [item]
        } else if (item.technicalTierDetails.length === max) {
          maxObj.push(item)
        }
      }
    })

    return maxObj
  }

  const taskTable = async (date) => {
    setTableData([])
    setUniqueProData([])
    // let today = new Date().toISOString().slice(0, 10)

    const today = moment(date).format('YYYY-MM-DD')
    // alert(today)
    const data = {
      date: today,
    }
    try {
      const response = await generateReport(data)
      if (response) {
        if (response.success) {
          if (response.data) {
            const unique = [
              ...new Map(response.data.map((item123) => [item123.projectId._id, item123])).values(),
            ]
            // console.log(unique, 'REPORT DATA VALUES')
            setUniqueProData(unique)

            // console.log(getMostWeapons(response.data), 'REPORT DATA VALUES')
            setDataReport(response.data)
            console.log(response.data, 'DJSJDS')
          }
          // toast.success(response.message)
        } else {
          setUniqueProData([])
          // toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const tConvertDate = (date) => {
    // alert(date)
    console.log(date, 'FORMAT DATE')
    if (date !== undefined && date !== '' && date !== null) {
      var RDate = date.split('T')[0]
      var RDate = moment(RDate).format('DD MMM YYYY')
      return RDate // return adjusted time or original string
    } else {
      return 'NULL'
    }
  }

  const tConvert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time]

    if (time.length > 1) {
      // If time format correct
      time = time.slice(1) // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM' // Set AM/PM
      time[0] = +time[0] % 12 || 12 // Adjust hours
    }
    return time.join('') // return adjusted time or original string
  }

  function disableWeekends(date) {
    let day = new Date(date)
    day = day.getDay()
    return day !== 0
  }

  const selectDateFuc = async (date) => {
    if (date) {
      setselectedTodayDate(date)
      // taskTable(momentBusinessDays(date).businessAdd(1)._d)
      taskTable(date)
    }
  }

  const onClickDownloadFuc = async () => {
    setIsDisabled(true)
    let data = '',
      header = ''
    // let ti = 1;
    if (UniqueProData.length > 0) {
      UniqueProData.map((x, i) => {
        data = data + `<div style="display:flex;width:100%">`
        data =
          data +
          `<h4 style="width:50%;float:left;text-align:left;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold!important;margin-bottom:5px;font-size:12px;">
        Project - ${x.projectId.projectName}
        </h4>`

        if (x.reportingEmployee !== null) {
          data =
            data +
            `<h4 style="width:50%;float:right;text-align:right;text-transform:capitalize;display:flex;margin-bottom:0px;font-weight:bold;margin-bottom:5px;font-size:12px;">
        Reporting To : ${x.reportingEmployee.firstName} ${x.reportingEmployee.lastName}
        </h4>`
        }
        // data = data + `<h4 style="font-family:arial;text-align:right;">Reporting To : ${k.contentDeveloperId.reportingTo.userName}</h4>`;
        data = data + `</div>`

        const functionslaUnique = [
          ...new Map(
            DataReport.filter((item) => item.projectId._id === x.projectId._id).map((item123) => [
              item123.functionalAttributeId._id,
              item123,
            ]),
          ).values(),
        ]

        if (functionslaUnique.length > 0) {
          functionslaUnique.map((z, j) => {
            data = data + `<table style="width:100%;border-collapse: collapse;margin-bottom:10px;">`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">S.No</th>`

            z.functionalTierDetails.map(async (x, i) => {
              data =
                data +
                `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

              return data
            })

            getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
              .length > 0 &&
              getMostTechTiers(
                DataReport.filter((item) => item.projectId._id === x.projectId._id),
              )[0].technicalTierDetails.map(async (x, i) => {
                data =
                  data +
                  `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">${x.value}</th>`

                return data
              })

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                padding: 5px;font-size:9px;
                text-align: center;
                background-color: #3c4b64;
                color: white;" class="tableHeader">Activity</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Est. Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
              padding: 5px;font-size:9px;
              text-align: center;
              background-color: #3c4b64;
              color: white;" class="tableHeader">Est. Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                        padding: 5px;font-size:9px;
                        text-align: center;
                        background-color: #3c4b64;
                        color: white;" class="tableHeader">Act. Finish Date</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                  padding: 5px;font-size:9px;
                  text-align: center;
                  background-color: #3c4b64;
                  color: white;" class="tableHeader">Act. Finish Time</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                            padding: 5px;font-size:9px;
                            text-align: center;
                            background-color: #3c4b64;
                            color: white;" class="tableHeader">Status</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                      padding: 5px;font-size:9px;
                      text-align: center;
                      background-color: #3c4b64;
                      color: white;" class="tableHeader">Summary</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Img/Video/File</th>`

            data =
              data +
              `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
                    padding: 5px;font-size:9px;
                    text-align: center;
                    background-color: #3c4b64;
                    color: white;" class="tableHeader">Code URL</th>`

            // columns.map(async (x, i) => {
            //   data =
            //     data +
            //     `<th style="vertical-align: middle; overflow: hidden; cursor: pointer; border: 1px solid #3c4b64;
            //         padding: 5px;font-size:9px;
            //         text-align: center;
            //         background-color: #3c4b64;
            //         color: white;" class="tableHeader">${x.label}</th>`

            //   return data
            // })

            // console.log(columns, 'PDF REPORT DATA')

            // let jii = 0;

            DataReport.filter(
              (item) =>
                item.projectId._id === x.projectId._id &&
                item.functionalAttributeId._id === z.functionalAttributeId._id,
            ).map(async (x, i) => {
              const dDesc = document.createElement('div')
              dDesc.innerHTML = x.description

              console.log(tConvertDate(x.lsd), tConvertDate(x.lfd), 'WWWWWWWWWWWWWWWWWWWWWWWWWW')

              data = data + '<tr>'

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:1%;   text-align: center;
          padding: 5px;" >${i + 1}</td>`

              z.functionalTierDetails.map(async (y, i) => {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.functionalVariableDetails.filter((item) => item.tierId === y._id).length > 0
                    ? x.functionalVariableDetails.filter((item) => item.tierId === y._id)[0]
                        .variableName
                    : ' - '
                }</td>`

                return data
              })

              getMostTechTiers(DataReport.filter((item) => item.projectId._id === x.projectId._id))
                .length > 0 &&
                getMostTechTiers(
                  DataReport.filter((item) => item.projectId._id === x.projectId._id),
                )[0].technicalTierDetails.map(async (z, i) => {
                  data =
                    data +
                    `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
                padding: 5px;">${
                  x.technicalVariableDetails === null
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id).length ===
                      0
                    ? ' - '
                    : x.technicalVariableDetails.filter((item) => item.tierId === z._id)[0]
                        ?.variableName
                }</td>`

                  return data
                })

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px;width:5%;   text-align: center;
          padding: 5px;" >${dDesc.innerText}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${tConvertDate(x.esd)} - ${tConvertDate(x.efd)}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.est} - ${x.eft}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${
            x.lfd === undefined
              ? tConvertDate(x.lsd)
              : tConvertDate(x.lsd) + ' - ' + tConvertDate(x.lfd)
          }</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.ast} - ${x.aft}</td>`

              //   data =
              //     data +
              //     `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(Number(x.actualDuration) - Number(x.plannedDuration))}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.Status}</td>`

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >${x.remark}</td>`

              if (x?.fileType && x?.fileType === 'image/png') {
                //       data =
                //         data +
                //         `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
                // padding: 5px;" ><img src=${x.fileurl} style="width:50px;height:50px;" /></td>`
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" >
                <a href=${x.fileurl} target="_blank">
                <img src=${x.fileurl} style="width:50px;height:50px;" />
                </a>
          </td>`
              } else if (x?.fileType && x?.fileType === 'video/mp4') {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ><a target="_blank" href=${x.fileurl}>View Video</a></td>`
              } else if (
                x?.fileType &&
                x?.fileType !== 'video/mp4' &&
                x?.fileType !== 'image/png'
              ) {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ><a target="_blank" href=${x.fileurl}>View Document</a></td>`
              } else {
                data =
                  data +
                  `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" > - </td>`
              }

              data =
                data +
                `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
          padding: 5px;" ><a target="_blank" href=${x.codeurl}>View Code</a></td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.est)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${tConvert(x.eft)}</td>`

              // data =
              //   data +
              //   `<td style="border: 1px solid #ddd; font-size:9px; width:5%;  text-align: center;
              //   padding: 5px;" >${String(x.plannedDuration)}</td>`

              return data
            })

            console.log(DataReport, 'PDF REPORT DATA')

            data = data + `</table>`
          })
        }
      })
    }

    console.log(data, 'PDF REPORT DATA')
    if (data) {
      // setTCount(ti);
      const htmlToConvert = renderToString(
        <div id="data" className="tableExample">
          <CRow>
            <CCol
              sm="1"
              md="1"
              lg="1"
              style={{
                float: 'left',
                width: '20%',
              }}
            >
              <img src="https://www.kpostindia.com/images/logo.png" width="120" />
            </CCol>
            <CCol
              sm="9"
              md="9"
              lg="9"
              style={{
                float: 'left',
                width: '60%',
              }}
            >
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                }}
              >
                Planning and Scheduling Software
              </p>
              <p
                style={{
                  fontSize: '14',
                  textAlign: 'center',
                  color: '#000000',
                  fontWeight: 'bold',
                  marginBottom: '5px',
                  marginTop: '5px',
                  // display: 'flex',
                  // justifyContent: 'center',
                  // textAlign: 'center',
                }}
              >
                {moment().format('DD MMM YYYY')} Detailed Today Appraisal Report of{' '}
                {state.firstName} {state.lastName}
                {state.employeeId?.reportingTo === null
                  ? ''
                  : ` Reporting To ${state.employeeId?.reportingTo?.firstName} ${state.employeeId?.reportingTo?.lastName}`}
              </p>
            </CCol>
          </CRow>
          {parse(header)}
        </div>,
      )
      downloadFuction(data, htmlToConvert)
    }
  }

  const downloadFuction = async (data, header) => {
    //setDownload(data);
    let response
    try {
      response = await downloadAppraisalTodayPdf(data, header)
      if (response.success) {
        let fetchDataModified = `data:application/pdf;base64,${response.buffer}`
        let a = document.createElement('a')
        a.href = fetchDataModified
        a.download = `AppraisalReport_${moment().format('DD_MM_YYYY')}.pdf`
        a.click()
        setIsDisabled(false)
      } else if (!response.success) {
        // <Danger body={response.error} />
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
            <div className="panel-heading">
              <div className="col-xs-6">
                <h3 className="font_Title">Appraisal Report</h3>
              </div>
            </div>
            <CCard className="mb-6">
              <CCardBody>
                <CForm>
                  <CRow className="mb-3">
                    <CRow className="col-sm-4">
                      <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                        Select Date <code>*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <DatePicker
                          placeholderText={'Select the Date'}
                          selected={selectedTodayDate && selectedTodayDate}
                          onChange={(date) => {
                            console.log(date, 'SJSJDLSDJOHDJFFJLDJL?FJLSJFDLJFSLF')
                            selectDateFuc(date)
                          }}
                          dateFormat="dd/MM/yyyy"
                          dayClassName={(date) =>
                            date.getDay() === 0 ? 'weekend-days' : undefined
                          }
                          filterDate={disableWeekends}
                          customInput={<CFormInput value={selectedTodayDate}></CFormInput>}
                        />
                      </CCol>
                    </CRow>
                  </CRow>
                </CForm>
              </CCardBody>
            </CCard>
            <CForm>
              <div>
                <CRow className="">
                  <div>
                    {UniqueProData.length > 0 ? (
                      <h3 className="escols" style={{ textAlign: 'center', padding: '10px 20px' }}>
                        Todays Appraisal Report - {moment().format('DD MMM YYYY')}
                      </h3>
                    ) : null}
                  </div>
                  <div className="d-flex flex-row justify-content-end mb-3">
                    {UniqueProData.length > 0 ? (
                      <div>
                        <button
                          className="loginBtn1 mright"
                          type="submit"
                          // onClick={(e) => {
                          //   openModal()
                          //   e.preventDefault()
                          // }}
                          onClick={(e) => {
                            e.preventDefault()
                            onClickDownloadFuc()
                          }}
                          disabled={isDisabled}
                        >
                          Download Report
                        </button>
                      </div>
                    ) : null}
                  </div>
                  {selectedTodayDate && (
                    <>
                      {UniqueProData.length > 0 ? (
                        <>
                          {UniqueProData.map((x, i) => {
                            return (
                              <AppraisalReportFunctions
                                key={i}
                                projectId={x.projectId._id}
                                projectName={x.projectId.projectName}
                                projectReportData={DataReport.filter(
                                  (item) => item.projectId._id === x.projectId._id,
                                )}
                                // funcTiersData={getMostFuncTiers(
                                //   DataReport.filter(
                                //     (item) => item.projectId._id === x.projectId._id,
                                //   ),
                                // )}
                                techTiersData={getMostTechTiers(
                                  DataReport.filter(
                                    (item) => item.projectId._id === x.projectId._id,
                                  ),
                                )}
                                funcTiersData={[
                                  ...new Map(
                                    DataReport.filter(
                                      (item) => item.projectId._id === x.projectId._id,
                                    ).map((item123) => [
                                      item123.functionalAttributeId._id,
                                      item123,
                                    ]),
                                  ).values(),
                                ]}
                              />
                            )
                          })}
                        </>
                      ) : (
                        <h3 className="center">NO DATA FOUND</h3>
                      )}
                    </>
                  )}
                </CRow>
              </div>
            </CForm>
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}
