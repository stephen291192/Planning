import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { toast } from 'react-toastify'
import React, { useContext } from 'react'
import { useState } from 'react'
import {
  CSmartTable,
  CButton,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { FaEdit } from 'react-icons/fa'
import { RiDeleteBinFill } from 'react-icons/ri'
import { GlobalContext } from 'src/context'
import { ImDownload3 } from 'react-icons/im'
import ReactToPdf from 'react-to-pdf'
import { technicalattributeDelete, technicalattributeGet } from 'src/services/ApiServices'

// eslint-disable-next-line react/prop-types
function TechnicalAttributeTable({ updateAttributeMaster, setTiers }) {
  const [modalIsOpen, setIsOpen] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')

  const [tableSelectedTechName, settableSelectedTechName] = useState('')

  function openModal() {
    setIsOpen(true)
  }

  function closeModal() {
    setIsOpen(false)
  }

  const ref = React.createRef()

  const options = {
    orientation: 'landscape',
    unit: 'in',
    // format: [12, 0],
  }
  const initialTableStructure = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '6%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'attributeName',
      label: 'Tech Attribute Name',
      _style: { width: '12%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
  ]
  const { state, dispatch } = useContext(GlobalContext)
  const [visible, setVisible] = useState(false)
  const [project, setProject] = useState([])
  const [tableStructure, setTablestructure] = useState(initialTableStructure)

  React.useEffect(() => {
    setProject([])
    showAttributeMaster()
  }, [state?.companyId])

  const GetMaximumArrayLength = (attribute) => {
    let LargestTierLength = []
    for (let i = 0; i < attribute.length; i++) {
      if (attribute[i].tiers.length > LargestTierLength.length) {
        LargestTierLength = attribute[i].tiers
      }
    }
    return LargestTierLength.length
  }

  const ReStructureTableWithTiers = (length) => {
    let NewStructure = []
    for (let i = 0; i < length; i++) {
      NewStructure.push({
        key: `Tier_${i + 1}`,
        label: `Attribute ${i + 1}`,
        _style: { width: '10%', background: '#002663' },
        filter: true,
        sorter: false,
        _props: { color: '#fff', className: 'fw-semibold' },
      })
    }
    NewStructure.push({
      key: 'show_details',
      label: 'Action',
      _style: { width: '10%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    })
    setTablestructure([...initialTableStructure, ...NewStructure])
  }

  const showAttributeMaster = async () => {
    setProject([])
    var response
    try {
      response = await technicalattributeGet()
      if (response) {
        console.log('losangel', response.data)
        if (response.success) {
          if (response.data) {
            const length = GetMaximumArrayLength(response.data)
            ReStructureTableWithTiers(length)
            const data = response.data.map((x, i) => {
              let tiersResponseStructure = {}
              // console.log(x, 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx')
              for (let loop_for_Tiers = 0; loop_for_Tiers < length; loop_for_Tiers++) {
                tiersResponseStructure[`Tier_${loop_for_Tiers + 1}_id`] =
                  x.tiers[loop_for_Tiers]?._id ?? ''
                tiersResponseStructure[`Tier_${loop_for_Tiers + 1}`] =
                  x.tiers[loop_for_Tiers]?.value ?? '-'
              }

              return {
                S_no: i + 1,
                companyId: state.companyId,
                attributeName: x.attributeName,
                attributeId: x._id,
                data: x,
                ...tiersResponseStructure,
              }
            })
            setProject(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const [tableDeleteId, settableDeleteId] = useState('')
  const onDelete = async (attributeId) => {
    var response
    try {
      response = await technicalattributeDelete(attributeId)
      if (response.success) {
        const data = project.filter((item) => item.attributeId !== attributeId)
        showAttributeMaster(data)
        toast.success(response.message)
        
      } else {
        toast.error(response.error)
      }
    } catch (e) {
      if (e.response) {
        if (e.response.data && e.response.data.success == false) {
          toast.error(e.response.data.error)
        }
      } else if (e.request) {
        toast.error('No Internet')
      } else {
        toast.error('' + e)
      }
    }
  }
  return (
    <CContainer className="filterContainer">
        <CSmartTable
          activePage={1}
          clickableRows
          columns={tableStructure}
          columnFilter
          columnSorter
          items={project}
          itemsPerPageSelect
          itemsPerPageLabel={'No of Rows'}
          itemsPerPage={5}
          pagination
          scopedColumns={{
            show_details: (item) => {
              return (
                <td className="gaponly">
                  <CButton className="updateBtn mright" onClick={() => updateAttributeMaster(item)}>
                    <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                  </CButton>
                  <CButton
                    className="deleteBtn"
                    onClick={() => {
                      setVisible(true)
                      settableDeleteId(item.attributeId)
                      settableSelectedTechName(item.attributeName)
                    }}
                  >
                    <RiDeleteBinFill style={{ fontSize: '22px', color: '#ea4335' }} />
                  </CButton>
                </td>
              )
            },
          }}
          sorterValue={{ column: 'name', state: 'asc' }}
          tableProps={{
            striped: true,
            hover: true,
            responsive: true,
          }}
        />
      <>
        <CModal visible={visible} size="sm" alignment="center" onClose={() => setVisible(false)}>
          <CModalHeader>
            <div
              className="times"
              onClick={() => {
                setVisible(false)
              }}
            >
              &times;
            </div>
            <CModalTitle>
              <span>
                <CIcon icon={cilTask} className="me-2" />
              </span>
              Confirm
            </CModalTitle>
          </CModalHeader>
          <CModalBody className="loginModelBody"><span>
            Are you sure do you want to delete the <br />
            Tech Attribute Name : <b>{tableSelectedTechName}</b> </span>
           </CModalBody>
          <CModalFooter>
            <button className="modelBtnNo" onClick={() => setVisible(false)}>
              No
            </button>
            <button
              className="modelBtnYes"
              onClick={() => {
                onDelete(tableDeleteId)
                setVisible(false)
              }}
            >
              Yes
            </button>
          </CModalFooter>
        </CModal>
      </>
      <CModal size="xl" visible={modalIsOpen} onClose={closeModal}>
        <ReactToPdf targetRef={ref} options={options} filename="Report.pdf">
          {({ toPdf }) => (
            <div className="PdfButton">
              <button onClick={toPdf} className="pdfbtnsDwn">
                Download <ImDownload3 size="15" />
              </button>
            </div>
          )}
        </ReactToPdf>
        <div ref={ref}>
          {console.log(state.companyLogo)}
          <div className="PdfTableHeader">
            {state?.companyLogo !== '' && (
              <img src={state.companyLogo} alt="" className="LogoPDFPicture" />
            )}
            <h3 className="pdfModelTitle">
              {state.companies.find((x) => x.value == state.companyId)?.label}
            </h3>
            <div></div>
          </div>

          <div className="d-flex flex-row justify-content-around mt-5">
            <div>
              {' '}
              <span className="subhead">User Login:</span>{' '}
              <span className="username">{state.userName}</span>
            </div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div>
              <span className="subhead">Date:</span>
              <span className="username">
                {new Date().toLocaleDateString('en-us', {
                  // weekday: 'short',
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </span>
            </div>
          </div>

          <div className="PdfTable">
            <CSmartTable
              clickableRows
              columns={tableStructure.filter((x) => x.label != 'Action')}
              items={project}
              itemsPerPage={Number(itemsPerPage)}
              sorterValue={{ column: 'name', state: 'asc' }}
              tableProps={{
                striped: true,
                hover: true,
              }}
            />
          </div>
        </div>
      </CModal>
    </CContainer>
  )
}

export default TechnicalAttributeTable

// .....................................
