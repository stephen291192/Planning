import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CButton, CFormInput, CFormLabel, CRow } from '@coreui/react'
import { toast } from 'react-toastify'
import { GlobalContext } from 'src/context'
import { BsFillPlusCircleFill } from 'react-icons/bs'
import { RiDeleteBin6Line,RiDeleteBinFill } from 'react-icons/ri'
import { FaEdit } from 'react-icons/fa'
import TechnicalAttributeTable from './TechnicalAttributeTable'
import {
  technicalattributeGet,
  technicalattributePost,
  technicalattributeupdate,
} from 'src/services/ApiServices'

export const TechnicalAttribute = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [addScreen, setAddScreen] = useState(true)
  const [update, setupdate] = useState(false)
  const [tierValue, setTierValue] = useState(false)
  const [save, setSave] = useState(false)
  const [attributeName, setAttributeName] = useState('')
  const [tier, setTier] = useState([])
  const [tiers, setTiers] = useState('')
  const [attributeNameDrop, setattributeNameDrop] = useState([])
  const [attributeNameValue, setAttributeNameValue] = useState('')
  const [editTierId, setEditTierId] = useState('')
  
  const [updateTier, setupdateTier] = useState({
    index: null,
  })

  const [table, setTable] = useState(false)

  useEffect(() => {
    showAttribute()
  }, [])

  const showAttribute = async () => {
    const token = await localStorage.getItem('USERTOKEN')
    setattributeNameDrop([])
    try {
      const response = await technicalattributeGet()
      if (response) {
        if (response.data.success) {
          if (response.data.data) {
            const data = response.data.data.map((x) => {
              return {
                value: x._id,
                label: x._id,
              }
            })
            setattributeNameDrop(data)
            setTable(true)
          }
          // toast.success(response.message)
        }
      } else {
        toast.error(response.error)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const addTier = (newTier) => {
    if (newTier !== '') {
      setTier([
        ...tier,
        {
          title: `Tier${tier.length + 1}`,
          value: newTier,
        },
      ])
      setTiers('')
    }
  }

  const updateAttributeMaster = (data) => {
    console.log(data, 'dasse')
    setEditTierId('')
    showAttribute()
    setAddScreen(!addScreen)
    setSave(false)
    setupdate(true)
    setTierValue(true)
    setAttributeName(data.attributeName)
    setTier(data.data.tiers)
  }

  const ConfirmSubmit = async (companyId) => {
    const bod = {
      attributeName,
      tiers: tier,
    }
    try {
      const response = await technicalattributePost(bod, companyId)
      if (response && response.success === true) {
        toast.success(response.message)
        setAddScreen(true)
        showAttribute()
        setAttributeName(attributeName)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success === false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const ConfirmSubmitupdate = async (updateId) => {
    const bod = {
      tierId: updateId,
      value: tier.find((x) => x._id === updateId)?.value
        ? tier.find((x) => x._id === updateId)?.value
        : '',
    }
    try {
      const response = await technicalattributeupdate(bod)
      if (response && response.success === true) {
        toast.success(response.message)
        setAttributeName(attributeName)
      } else {
        toast.error(response.error)
      }
    } catch (e) {
      console.log(e)
    }
  }

  return (
    <div>
      {addScreen ? (
        <div>
          <div className="d-flex align-items-center justify-content-between">
            <div className="font_Title pt-2 pb-0">Technical Attribute List</div>
            <div>
              <button
                className="loginBtn mright loginBtn_New"
                onClick={() => {
                  setAddScreen(!addScreen)
                  setEditTierId('')
                  setTiers('')
                  setTier([])
                  setTierValue(false)
                  setSave(false)
                  setAttributeName('')
                  setSave(false)
                  setupdate(false)
                }}
              >
                Add New
              </button>
            </div>
          </div>
          <CRow>
            <CCol xs={12}>
              <TechnicalAttributeTable updateAttributeMaster={updateAttributeMaster} />
            </CCol>
          </CRow>
        </div>
      ) : (
        <CForm>
          <CRow>
            <CCol xs={12}>
              <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">
                    {update ? 'Update Technical Attribute' : 'Create Technical Attribute'}
                  </h3>
                </div>
              </div>
              <CCard className="mb-6">
                <CCardBody>
                  <CForm>
                    <CRow className="mb-3">
                      <CRow className="col-sm-3">
                        <CFormLabel className="col-sm-12 donlabel text-align-left">
                          Enter Tech. Attribute Name <code>*</code>
                        </CFormLabel>
                        <CCol sm={12}>
                          <CFormInput
                            type="text"
                            value={attributeName}
                            onChange={(e) => {
                              setAttributeName(e.target.value)
                            }}
                            disabled={tierValue}
                            className="inputfieldgo"
                            placeholder="Enter here..."
                          />
                        </CCol>
                      </CRow>
                    </CRow>

                    {tierValue && !update && (
                      <CRow className="mb-3">
                        <CCol sm={2}></CCol>
                        <CFormLabel className="col-sm-2 donlabel">Attribute</CFormLabel>
                        <CCol sm={4}>
                          <CFormInput
                            type="text"
                            value={tiers}
                            onChange={(e) => {
                              setTiers(e.target.value)
                            }}
                            className="inputfieldgo"
                            placeholder="Attribute"
                          />
                        </CCol>

                        <CCol sm={1}>
                          <BsFillPlusCircleFill
                            onClick={(e) => {
                              addTier(tiers)
                            }}
                            style={{
                              width: '25px',
                              height: '25px',
                              display: 'inline',
                              marginTop: '7px',
                              cursor: 'pointer',
                            }}
                          />
                        </CCol>
                      </CRow>
                    )}

                    {tier.length > 0 &&
                      tier.map((x, i) => (
                        <div key={i}>
                          <CRow className="mb-3">
                            <CCol sm={2}></CCol>

                            <CFormLabel className="col-sm-2 donlabel">Attribute {i + 1}</CFormLabel>
                            <CCol sm={4}>
                              <CFormInput
                                type="text"
                                className="inputfieldgo"
                                placeholder="Attribute"
                                value={x?.value}
                                onChange={(e) => {
                                  // setTier(e.target.value)
                                  if (update) {
                                    const alteredArray = tier.map((z) => {
                                      if (z._id === x._id) {
                                        return {
                                          ...z,
                                          value: e.target.value,
                                        }
                                      } else {
                                        return z
                                      }
                                    })
                                    setTier(alteredArray)
                                  }

                                  if (editTierId == i) {
                                    setTier(
                                      tier.map((y) => {
                                        if (y.title == `Tier${i + 1}`) {
                                          return {
                                            ...y,
                                            title: `Tier${i + 1}`,
                                            value: e.target.value,
                                          }
                                        } else {
                                          return y
                                        }
                                      }),
                                    )
                                  }
                                }}
                                disabled={
                                  (update && updateTier.index !== null && updateTier.index == i) ||
                                  editTierId === i
                                    ? false
                                    : true
                                }
                              />
                            </CCol>
                            <CCol>
                              {(update && updateTier.index !== null && updateTier.index == i) ||
                              editTierId === i ? (
                                <button
                                  className="loginBtn mright"
                                  onClick={() => {
                                    if (update) {
                                      addTier(tiers)
                                      setTable(false)
                                      setAttributeNameValue('')
                                      console.log(x, 'TIERUPDATEDVALUE', tier)
                                      ConfirmSubmitupdate(x._id, state.companyId)
                                      setupdateTier({
                                        index: null,
                                      })
                                    } else {
                                      setEditTierId('')
                                    }
                                  }}
                                >
                                  Update
                                </button>
                              ) : (
                                <CButton
                                  className="updateBtn"
                                  onClick={() => {
                                    if (update) {
                                      setupdateTier({
                                        index: i,
                                      })
                                    } else {
                                      setEditTierId(i)
                                    }
                                  }}
                                >
                                  <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                                </CButton>
                              )}
                              {tier.length === i + 1 && !update && (
                                <CButton
                                  className="deleteBtn"
                                  onClick={() => {
                                    setTier(tier.filter((y) => y.title !== `Tier${i + 1}`))
                                    setEditTierId('')
                                  }}
                                >
                                   <RiDeleteBinFill style={{ fontSize: '22px', color: '#ea4335' }} />
                                </CButton>
                              )}
                            </CCol>
                          </CRow>
                        </div>
                      ))}

                    {save ? (
                      <div className="d-flex flex-row justify-content-end">
                        {tier.length > 0 && (
                          <div>
                            <button
                              className="loginBtn1 mright"
                              onClick={(e) => {
                                e.preventDefault()
                                ConfirmSubmit(state.companyId)
                              }}
                            >
                              save
                            </button>
                          </div>
                        )}
                        {console.log(tier, 'fdsfsdfsdfsfsdfsd')}
                        <div>
                          <button
                            className="reset"
                            onClick={() => {
                              setAddScreen(!addScreen)
                              // setAttributeName('')
                              // setTier([])
                              // setSave(false)
                              // setTierValue(false)
                            }}
                          >
                            cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="d-flex flex-row justify-content-end">
                        {!update && (
                          <div>
                            <button
                              className="save mright"
                              type="submit"
                              disabled={!attributeName}
                              onClick={(e) => {
                                e.preventDefault()
                                setTierValue(true)
                                setSave(true)
                              }}
                            >
                              Save
                            </button>
                          </div>
                        )}
                        <div>
                          <button className="reset" onClick={() => setAddScreen(!addScreen)}>
                            cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </CForm>
                </CCardBody>
              </CCard>
            </CCol>
          </CRow>
        </CForm>
      )}
    </div>
  )
}
