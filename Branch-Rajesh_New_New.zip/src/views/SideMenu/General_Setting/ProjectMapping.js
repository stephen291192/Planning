import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import ReactDOM from 'react-dom'
// import { MultiSelect } from 'react-multi-select-component'
import Multiselect from 'multiselect-react-dropdown'
import { MultiSelect } from 'react-multi-select-component'
import {
  CButton,
  CContainer,
  CModal,
  CModalBody,
  CModalFooter,
  CModalHeader,
  CModalTitle,
  CMultiSelect,
} from '@coreui/react-pro'
import Select from 'react-select'
import { toast } from 'react-toastify'
import axios from 'axios'
import { USERTOKEN } from 'src/constants/localstorage'
import { GlobalContext } from 'src/context'
import { URL } from 'src/services/URL'
import { CSmartTable } from '@coreui/react-pro'
import TableDropdown from 'src/views/forms/TableDropdown/TableDropdown'
import { BsPencil } from 'react-icons/bs'
import { RiDeleteBin6Line,RiDeleteBinFill } from 'react-icons/ri'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
// import { ProjectMappingTable } from '../General_Setting/ProjectMappingTable'
import {
  projectbyProjectmap,
  projectmapdelete,
  ProjectMappingEmployeeDrop,
  ProjectMappingprojectDrop,
  ProjectMappingSava,
  projectmaptable,
} from 'src/services/ApiServices'

export const ProjectMapping = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [addScreen, setAddScreen] = useState(true)
  const [projectId, setProjectId] = useState([])
  const [projectName, setProjectName] = useState([])
  const [projectIdTabel, setProjectIdTabel] = useState('')
  const [projectNameTabel, setProjectNameTabel] = useState([])
  const [tabledelete, setTabledelete] = useState({})
  const [employeeId, setEmployeeId] = useState([])
  const [employeName, setEmployeName] = useState('')
  const [tableShow, setTableShow] = useState(false)
  const [visible, setVisible] = useState(false)
  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [selected, setSelected] = useState([])
  // const [employeeIdDel, setEmployeeIdDel] = useState('')

  useEffect(() => {
    showEmployee(state.companyId)
    setEmployeeId('')
    setProjectId([])
    setTableShow(false)
  }, [state?.companyId])

  // Cancel Button
  const handleCancel = () => {
    setProjectId([])
    setEmployeeId([])
    setTableShow(false)
  }

  // Employee Dropdown GET API
  const showEmployee = async (companyId) => {
    var response

    try {
      response = await ProjectMappingEmployeeDrop(companyId)

      if (response) {
        if (response.success) {
          if (response.employees) {
            const data = response.employees.map((x, i) => {
              return {
                S_no: i + 1,
                employeeId: x._id,
                value: x._id,
                label: `${x.firstName} ${x.lastName}`,
              }
            })
            setEmployeName(data)
            console.log('AA', data)
          }
          // toast.success(response.data.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch {
      // if (error.response) {
      //   if (error.response.data && error.response.data.success == false) {
      //     toast.error(error.response.error)
      //   }
      // } else if (error.request) {
      //   toast.error('No Internet')
      // } else {
      //   toast.error('Something Went Wrong' + error)
      // }
    }
  }

  // Team Based by projects dropdown GET API
  const showProject = async (employeeId) => {
    setProjectName([])
    var response
    try {
      response = await ProjectMappingprojectDrop(employeeId)
      if (response) {
        if (response.success) {
          if (response) {
            console.log('SSS', response)
            const data = response.data.map((x) => {
              return {
                value: x?.projectId?._id,
                label: x?.projectId?.projectName,
              }
            })
            setProjectName(data)
            console.log('SS', data)
          }
          // toast.success(response.data.message)
        } else {
          // toast.error(response.data.error)
        }
      }
    } catch (error) {
      if (error.response) {
        if (error.response && error.response.success == false) {
          toast.error(error.response.data.error)
        }
      } else if (error.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + error)
      }
    }
  }

  // Show All Project Details on Tabel
  const showAllProjectTabel = async (employeeId) => {
    setProjectNameTabel([])
    var response
    try {
      response = await projectmaptable(employeeId)
      console.log(response.data, 'TABEL')
      if (response) {
        if (response.data) {
          const data = response.data.projects.map((x, i) => {
            return {
              S_no: i + 1,
              value: x._id,
              EmpName: `${response.data?.firstName} ${response.data?.lastName}`,
              projectName: x.projectName,
              employeeId: response.data._id,
              projectId: x._id,
            }
          })
          setProjectNameTabel(data)
          // toast.success(response.message)
        } else {
          // toast.error(response.error)
        }
      }
    } catch (e) {
      if (e.response) {
        if (e.response.data && e.response.data.success == false) {
          // toast.error (e.response.data.error)
        }
      } else if (e.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + e)
      }
    }
  }

  // Map button SAVE API
  const saveProjectMapping = async (employeeId) => {
    const proId = projectId.map((x) => x.value)

    const data = {
      projects: proId,
    }
    try {
      const response = await ProjectMappingSava(data, employeeId, state.companyId)
      // const response = res.data
      console.log('SSS', response)
      if (response && response.success === true) {
        setProjectId([])
        toast.success(response.message)
        showAllProjectTabel(employeeId)
        showProject(employeeId)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  // Table
  const columns = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%' , background: '#002663'},
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'EmpName',
      label: 'Employee Name',
      _style: { width: '40%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'projectName',
      label: 'Project',
      _style: { width: '40%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '10%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]

  function openModal() {
    setIsOpen(true)
  }
  function closeModal() {
    setIsOpen(false)
  }

  // Delete Button Delete API
  const onDelete = async (employeeId, projectId, e) => {
    var response
    try {
      response = await projectmapdelete(employeeId, projectId, state.companyId)
      if (response.success) {
        const data = projectNameTabel.filter(
          (item) => item.employeeId !== employeeId && item.projectId !== projectId,
        )
        setProjectNameTabel(data)

        toast.success(response.message)
        showAllProjectTabel(employeeId)
        showProject(employeeId)
        setTableShow(true)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <div>
      <div>
        <CForm>
          <CRow>
            <CCol>
            <div className="panel-heading">
                  <div className="col-xs-6">
                    <h3 className="font_Title">Project Mapping List</h3>
                  </div>
                </div>
              <CCard className="mb-6">
                
                
                <CCardBody>
                  <CForm>
                    <CRow className="">
                      <CRow className="col-sm-3">
                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                          Select Employee <code>*</code>
                        </CFormLabel>
                        <CCol sm={12}>
                          <Select
                            id="ms1"
                            options={employeName}
                            className={'inputfieldso'}
                            value={employeeId}
                            onChange={(e) => {
                              setEmployeeId(e)
                              showProject(e.value)
                              showAllProjectTabel(e.value)
                              setProjectId([])
                              setTableShow(true)
                            }}
                            placeholder="Name of the employee"
                          />
                        </CCol>
                      </CRow>
                      <CRow className="col-sm-3">
                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                          Select Project <code>*</code>
                        </CFormLabel>
                        <CCol sm={12}>
                          <MultiSelect
                            options={projectName}
                            // options={projectName.filter((x) => {
                            //   if (
                            //     !(
                            //       projectNameTabel.filter((item) => item.projectId === x.projectsId)
                            //         .length > 0
                            //     )
                            //   ) {
                            //     return x
                            //   } else {
                            //   }
                            // })}
                            value={projectId}
                            id="ms1"
                            disabled={!employeeId}
                            className={'inputfieldso'}
                            onChange={(e) => {
                              setProjectId(e)
                            }}
                            placeholder="Name of the project"
                          />
                        </CCol>
                      </CRow>
                    </CRow>
                    <br />

                    <div className="d-flex flex-row justify-content-end">
                      <div>
                        <button
                          className="loginBtn1 mright"
                          disabled={!employeeId.value}
                          onClick={(e) => {
                            e.preventDefault()
                            saveProjectMapping(employeeId.value)
                            setTableShow(true)
                            // setEmployeeId([])
                            // setProjectId([])
                          }}
                          type="submit"
                        >
                          Map
                        </button>
                      </div>
                      <div>
                        <button
                          className="reset"
                          onClick={(e) => {
                            handleCancel()
                            e.preventDefault()
                          }}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </CForm>
                  {/* {tableShow && <ProjectMappingTable />} */}
                 
                </CCardBody>
              </CCard>
              {tableShow && (
                    <div>
                      {/* <br />
                      <div className="ItemsPerPageMappage">
                        <span className="pageid">No of Rows</span> &nbsp;
                        <TableDropdown
                          onChange={(value) => {
                            setItemsPerPage(value)
                          }}
                        />
                      </div> */}
                      {/* <div className="TableDownloadmapPage">
                        <button onClick={openModal} className="pdfbtns">
                          <ImFilePdf /> PDF
                        </button>
                       
                      </div> */}
                      
                      <CSmartTable
                        activePage={1}
                        clickableRows
                        columns={columns}
                        columnFilter
                        columnSorter
                        items={projectNameTabel}
                        itemsPerPageSelect
                        itemsPerPageLabel={'No of Rows'}
                        itemsPerPage={5}
                        pagination
                        scopedColumns={{
                          show_details: (item) => {
                            return (
                              <td className="gaponly">
                                <CButton
                                  className="deleteBtn"
                                  onClick={() => {
                                    console.log(item.employeeId, item.projectId, 'HHDSODSH')
                                    setTabledelete({
                                      employID: item.employeeId,
                                      projectId: item.projectId,
                                    })
                                    setVisible(!visible)
                                  }}
                                >
                                   <RiDeleteBinFill
                                  style={{ fontSize: '22px', color: '#ea4335' }}
                                />
                                  {/* <RiDeleteBin6Line
                                    style={{ fontSize: '16px', color: '#fff', display: 'inline' }}
                                  /> */}
                                </CButton>
                              </td>
                            )
                          },
                        }}
                        sorterValue={{ column: 'name', state: 'asc' }}
                        tableProps={{
                          striped: true,
                          hover: true,
                        }}
                      />
                      <br />
                    </div>
                    
                  )}
                  <>
                    <CModal
                      size="sm"
                      alignment="center"
                      visible={visible}
                      onClose={() => setVisible(false)}
                    >
                      <CModalHeader>
                        <div
                          className="times"
                          onClick={() => {
                            setVisible(false)
                          }}
                        >
                          &times;
                        </div>
                        <CModalTitle>
                          <span>
                            <CIcon icon={cilTask} className="me-2" />
                          </span>
                          Confirm
                        </CModalTitle>
                      </CModalHeader>
                      <CModalBody className="loginModelBody">
                        Are you sure do you want to delete a current row.
                      </CModalBody>
                      <CModalFooter>
                        <button className="modelBtnNo" onClick={() => setVisible(false)}>
                          No
                        </button>
                        <button
                          className="modelBtnYes"
                          onClick={() => {
                            onDelete(tabledelete.employID, tabledelete.projectId)
                            // onDelete(item.employeeId, item.projectId)
                            setVisible(false)
                          }}
                        >
                          Yes
                        </button>
                      </CModalFooter>
                    </CModal>
                  </>
            </CCol>
          </CRow>
        </CForm>
      </div>
    </div>
  )
}
