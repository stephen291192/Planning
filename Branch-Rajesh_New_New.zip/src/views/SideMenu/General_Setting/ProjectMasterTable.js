import { toast } from 'react-toastify'
import React, { useContext } from 'react'
import { useState, useEffect } from 'react'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import {
  CSmartTable,
  CButton,
  CContainer,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import { FaEdit } from 'react-icons/fa'
import { RiDeleteBinFill } from 'react-icons/ri'
import { GlobalContext } from 'src/context'
import { getProjectMaster, projectMasterDelete } from 'src/services/ApiServices'

// eslint-disable-next-line react/prop-types
function ProjectMasterTable({ updateProjectmaster }) {
  const { state, dispatch } = useContext(GlobalContext)
  const [visible, setVisible] = useState(false)
  const [project, setProject] = useState([])

  useEffect(() => {
    setProject([])
    showProjectMaster(state.companyId)
  }, [state.companyId])

  const [tableDeleteId, setTableDeleteId] = useState('')
  const [tableDeleteId1, setTableDeleteId1] = useState('')
  const [projectTableName, setprojectTableName] = useState('')

  const onDelete = async (companyId, projectId) => {
    try {
      const res = await projectMasterDelete(companyId, projectId)
      if (res) {
        if (res.success) {
          const data = project.filter((project) => project.projectId !== projectId)
          setProject(data)
          showProjectMaster(state.companyId)
          toast.success(res.message)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const showProjectMaster = async (companyId) => {
    try {
      const response = await getProjectMaster(companyId)
      if (response) {
        console.log(response.data, 'DATA SSS')
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x, i) => {
              return {
                S_no: i + 1,
                projectName: x.projectName,
                abbreviation: x.abbreviation,
                code: x.code,
                projectId: x._id,
                companyId: x.companyId,
              }
            })
            setProject(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const columns = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '8%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'projectName',
      _style: { width: '25%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'abbreviation',
      _style: { width: '25%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'code',
      _style: { width: '25%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '12%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]

  return (
    <CContainer className="filterContainer filterContainer_New">
      <CSmartTable
        activePage={1}
        clickableRows
        columns={columns}
        columnFilter={columns}
        columnSorter
        items={project}
        itemsPerPageSelect
        itemsPerPageLabel={'No of Rows'}
        itemsPerPage={5}
        pagination
        scopedColumns={{
          show_details: (item) => {
            return (
              <td className="gaponly">
                <CButton
                  className="updateBtn"
                  onClick={() => {
                    updateProjectmaster(item)
                  }}
                >
                  <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                </CButton>
                <CButton
                  className="deleteBtn"
                  onClick={() => {
                    setVisible(!visible)
                    setTableDeleteId(state.companyId)
                    setTableDeleteId1(item.projectId)
                    setprojectTableName(item.projectName)
                  }}
                >
                  <RiDeleteBinFill style={{ fontSize: '22px', color: '#ea4335' }} />
                </CButton>
              </td>
            )
          },
        }}
        sorterValue={{ column: 'name', state: 'asc' }}
        tableProps={{
          striped: true,
          hover: true,
          responsive: true,
        }}
      />
      <>
        <CModal size="sm" alignment="center" visible={visible} onClose={() => setVisible(false)}>
          <CModalHeader>
            <div
              className="times"
              onClick={() => {
                setVisible(false)
              }}
            >
              &times;
            </div>
            <CModalTitle>
              <span>
                <CIcon icon={cilTask} className="me-2" />
              </span>
              Confirm
            </CModalTitle>
          </CModalHeader>
          <CModalBody className="loginModelBody"><span>
            Are you sure do you want to delete the <br/>
            Project Name : <b>{projectTableName}</b></span>
          </CModalBody>
          <CModalFooter>
            <button className="modelBtnNo" onClick={() => setVisible(false)}>
              No
            </button>
            <button
              className="modelBtnYes"
              onClick={() => {
                onDelete(tableDeleteId, tableDeleteId1)
                setVisible(false)
              }}
            >
              Yes
            </button>
          </CModalFooter>
        </CModal>
      </>
    </CContainer>
  )
}

export default ProjectMasterTable

// .....................................
