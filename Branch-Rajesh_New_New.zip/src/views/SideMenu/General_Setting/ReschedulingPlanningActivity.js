import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CButton, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import { CSmartTable } from '@coreui/react-pro'
import Select from 'react-select'
import { toast } from 'react-toastify'
import axios from 'axios'
import { GlobalContext } from 'src/context'
import { URL } from 'src/services/URL'
import { ImFilePdf } from 'react-icons/im'
import { FaEdit } from 'react-icons/fa'
import {
  getProjectByEmployeeId,
  getAllIncompletedPlanning,
  ReScheduleProject,getProjectforTaskDescribe
} from 'src/services/ApiServices'
import moment from 'moment'
import { getValue, isNull, logout, TYPES } from 'src/services/utility'
import { useNavigate } from 'react-router-dom'

function ReschedulingPlanningActivity() {
  const { state, dispatch } = useContext(GlobalContext)
  const navigate = useNavigate()
  const projectStatusOptions = [
    { value: 'Planned', label: 'Yet to start' },
    { value: 'InProgress', label: 'InProgress' },
    { value: 'Completed', label: 'Completed' },
    { value: 'Hold', label: 'Hold' },
  ]

  const columns = [
    {
      key: 'S_no',
      label:'S.No',
      _style: { width: '5%' , background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'allProject',
      label: 'Project',
      _style: { width: '10%' , background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'functionAttributes',
      label: 'Functional Variable',
      _style: { width: '15%' , background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'ActionName',
      label: 'Functional Requirement',
      _style: { width: '12%', background: '#002663'  },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'technicalAttributes',
      label: 'Technical Variable',
      _style: { width: '15%' , background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },

    {
      key: 'Duration',
      label: 'Duration (Days)',
      _style: { width: '10%' , background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'Delay',
      label: 'Delay',
      _style: { width: '8%', background: '#002663'  },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'ESD',
      label: 'Est Start Date',
      _style: { width: '8%' , background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'EED',
      label: 'Est End Date',
      _style: { width: '10%', background: '#002663'  },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'ACTIONS',
      label: 'Action',
      _style: { width: '20%' , background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
  ]

  const [projectState, setProjectState] = useState(null)
  const [projectList, setProjectList] = useState([])
  const [RescheduleResponse, setRescheduleResponse] = useState([])
  const [editId, setEditId] = useState('')
  const [selectedProject, setSelectedProject] = useState(null)
  const [table, setTable] = useState([])

  const [employeeId, SetEmployeeId] = useState(state.userId)

  useEffect(() => {
    console.log("Employee ID:", employeeId);
  }, [employeeId]);


  // const {
  //   employeeId: { _id: empId },
  // } = state

    

  const getAllProjectsByEmployeeId = async () => {
   
    setProjectList([])
    setSelectedProject(null)
    setTable([])
   
    try {
      const response = await getProjectforTaskDescribe(state.companyId,employeeId)
      // console.log("12sdfsd",response)
      if (response) {
        const projectArr = getValue(response.data, TYPES.ARRAY, []).map(
          (x, i) => {
            return {
              _id: x._id,
              value: x.projectId._id,
              label: x.projectId.projectName,
              projectId: x._id,
              key: i,
            }
          },
        )
        setProjectList(getValue(projectArr, TYPES.ARRAY, []))
      } else {
        if (response.isAuthorized === false) {
          logout(toast, dispatch, navigate)
        }
      }
    } catch (err) {
      console.error(err)
    }
  }

  const getAllIncompletedPlanningActivities = async (projectId) => {
    setEditId('')
    setTable([])
    const employeeIdData=state.employeeId._id
    try {
      const body = {
        projectId,
        employeeId: employeeIdData,
        status: getValue(projectState.value, TYPES.STRING, ''),
      }
      const response = await getAllIncompletedPlanning(body)

      console.log("dfgkjldfg",response)
      if (response) {
        
        toast.success(response.message)

        const unplannedProjectsArr = getValue(response.data, TYPES.ARRAY, []).map(
          (planning, planningKey) => {
            return {

              S_no: planningKey + 1,
              projectKey: planningKey,
              planningId: planning._id,
              projectId: planning.projectId._id,
              // ActionName:planning.taskDescriptionId?.taskDescription === "" ? "yes":"no",
              allProject: getValue(planning.projectId.projectName, TYPES.STRING, ''),
              
              duration: isNull(planning.duration) ? '' : String(planning.duration),
              
              delay: isNull(planning.delay) ? '' : String(planning.delay),
              
              esd:
                getValue(planning.esd, TYPES.STRING, '') === ''
                  ? ''
                  : moment(getValue(planning.esd, TYPES.STRING, '')).format('YYYY-MM-DD'),
              
               efd:
                getValue(planning.efd.split('T')[0], TYPES.STRING, '') === ''
                  ? ''
                  : moment(getValue(planning.efd.split('T')[0], TYPES.STRING, '')).format(
                      'YYYY-MM-DD',
                    ),

              functionAttributes: getValue(
                planning.functionalVariableDetails,
                TYPES.ARRAY,
                [],
              ).reduce((previous, next, index) => {
                if (index === 1) {
                  return `${getValue(previous.variableName, TYPES.STRING, '')}- ${getValue(
                    next.variableName,
                    TYPES.STRING,
                    '',
                  )}`
                } else {
                  return `${getValue(previous, TYPES.STRING, '')}- ${getValue(
                    next.variableName,
                    TYPES.STRING,
                    '',
                  )}`
                }
              }),

              technicalAttributes:
                planning.technicalVariableDetails !== null
                  ? getValue(planning.technicalVariableDetails, TYPES.ARRAY, []).reduce(
                      (previous, next, index) => {
                        if (index === 1) {
                          return `${getValue(previous.variableName, TYPES.STRING, '')}- ${getValue(
                            next.variableName,
                            TYPES.STRING,
                            '',
                          )}`
                        } else {
                          return `${getValue(previous, TYPES.STRING, '')}- ${getValue(
                            next.variableName,
                            TYPES.STRING,
                            '',
                          )}`
                        }
                      },
                    )
                  : ' - ',

              ActionName: getValue(planning.taskDescriptionId?.taskDescription, TYPES.STRING, ''),
              // ...planning,
            }
          },
        )
        setTable(getValue(unplannedProjectsArr, TYPES.ARRAY, []))
        toast.error(response.error)
      } else {
       
        if (response.error) {
          
        } else {
         
          logout(toast, dispatch, navigate)
        }
      }
    } catch (error) {
     
      console.error(error)
      
    }
  }

  const ScheduleHandler = (data, duration, delay, esd, efd) => {
    const isPreviousDataExists = RescheduleResponse.find(
      (previousData) => previousData.planningId === data.planningId,
    )
    const removePreviousData = RescheduleResponse.filter(
      (previousData) => previousData.planningId !== data.planningId,
    )
    if (isPreviousDataExists) {
      setRescheduleResponse([
        ...removePreviousData,
        {
          ...isPreviousDataExists,
          duration,
          delay,
          esd,
          efd,
        },
      ])
    } else {
      setRescheduleResponse([
        ...RescheduleResponse,
        {
          ...data,
          duration,
          delay,
          esd,
          efd,
        },
      ])
    }
  }

  const UpdateReScheduleProject = async (body) => {
    const employeeIdData=state.employeeId._id
    if (isNull(body.duration) || isNull(body.delay) || isNull(body.esd) || isNull(body.efd)) {
      toast.error(`Please Enter all the fields`)
    } else {
      try {
        const requestBody = {
          projectId: body.projectId,
          employeeId: employeeIdData,
          planningId: getValue(body.planningId, TYPES.STRING, ''),
          duration: body.duration,
          delay: body.delay,
          esd: body.esd,
          efd: body.efd,
        }
        const response = await ReScheduleProject(requestBody)
        if (response) {
          if (response.success && response.isAuthorized) {
            toast.success(response.message)
            setRescheduleResponse([])
            getAllIncompletedPlanningActivities(getValue(selectedProject.value, TYPES.STRING, ''))
          } else {
            if (response.isAuthorized) {
              toast.error(getValue(response.error, TYPES.STRING, 'Something went Wrong'))
            } else {
              logout(toast, dispatch, navigate)
            }
          }
        }
      } catch (err) {
        console.error(err)
      }
    }
  }

  return (
    <div>
      <CForm>
        <CRow>
          <CCol xs={12}>
          <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">Re-Scheduling</h3>
                </div>
              </div>
            <CCard className="mb-6">
              <CCardBody>
                <CRow>
                  <CRow className="col-sm-3">
                    <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                      Reschedule For
                    </CFormLabel>
                    <CCol sm={12}>
                      <Select
                        className={'inputfieldso'}
                        options={getValue(projectStatusOptions, TYPES.ARRAY, [])}
                        value={getValue(projectState, TYPES.OBJECT, null)}
                        onChange={(state) => {
                          setProjectState(getValue(state, TYPES.OBJECT, null))
                          getAllProjectsByEmployeeId()
                        }}
                        placeholder="Select Status"
                      />
                      <span
                        style={{
                          fontWeight: '500',
                          fontSize: '12px',
                          color: 'red',
                        }}
                      ></span>
                    </CCol>
                  </CRow>
                  <CRow className="col-sm-3">
                    <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                      Select Project
                    </CFormLabel>
                    <CCol sm={12}>
                      <Select
                        className={'inputfieldso'}
                        value={getValue(selectedProject, TYPES.OBJECT, null)}
                        options={projectList}
                        onChange={(project) => {
                          setSelectedProject(getValue(project, TYPES.OBJECT, null))
                          getAllIncompletedPlanningActivities(
                            getValue(project.value, TYPES.STRING, ''),
                          )
                        }}
                        placeholder="Select Project"
                      />
                      <span
                        style={{
                          fontWeight: '500',
                          fontSize: '12px',
                          color: 'red',
                        }}
                      ></span>
                    </CCol>
                  </CRow>
                </CRow>
              </CCardBody>
             <br />
            </CCard>
           
            {table.length > 0 && (
                <React.Fragment>
                  <div className="d-flex flex-row justify-content-end mt-3 ">
                  
                    <div>
                      <button
                        className="reset"
                        onClick={(e) => {
                          e.preventDefault()
                          setRescheduleResponse([])
                          setSelectedProject(null)
                          setProjectList([])
                          setProjectState(null)
                          setTable([])
                          setEditId('')
                        }}
                      >
                        Back
                      </button>
                    </div>
                  </div>
                  <CSmartTable
                    activePage={1}
                    clickableRows
                    columns={columns}
                    columnFilter
                    columnSorter
                    items={table}
                    itemsPerPageSelect
                    itemsPerPageLabel={'No of Rows'}
                    itemsPerPage={5}
                    pagination
                    scopedColumns={{
                      Duration: (item) => {
                        return (
                          <td>
                            <CFormInput
                              type="number"
                              placeholder="Days"
                              className="inputfieldgo"
                              disabled={item.planningId !== editId}
                              value={
                                item.planningId !== editId
                                  ? getValue(item.duration, TYPES.STRING, '')
                                  : getValue(
                                      RescheduleResponse.find(
                                        (x) => x.planningId === item.planningId,
                                      )?.duration,
                                      TYPES.STRING,
                                      '',
                                    )
                              }
                              onChange={(e) => {
                                ScheduleHandler(item, e.target.value, '', '', '')
                              }}
                            />
                          </td>
                        )
                      },
                      Delay: (item) => {
                        return (
                          <td>
                            <CFormInput
                              type="number"
                              placeholder="Days"
                              className="inputfieldgo"
                              disabled={item.planningId !== editId}
                              value={
                                item.planningId !== editId
                                  ? getValue(item.delay, TYPES.STRING, '')
                                  : getValue(
                                      RescheduleResponse.find(
                                        (x) => x.planningId === item.planningId,
                                      )?.delay,
                                      TYPES.STRING,
                                      '',
                                    )
                              }
                              onChange={(e) => {
                                ScheduleHandler(
                                  item,
                                  getValue(
                                    RescheduleResponse.find((x) => x.planningId === item.planningId)
                                      ?.duration,
                                    TYPES.STRING,
                                    '',
                                  ),
                                  e.target.value,
                                  '',
                                  '',
                                )
                              }}
                            />
                          </td>
                        )
                      },
                      ESD: (item) => {
                        return (
                          <td>
                            <CFormInput
                              type="Date"
                              min={moment().format('YYYY-MM-DD')}
                              max="9999-01-01"
                              disabled={item.planningId !== editId}
                              className="inputfieldgo"
                              value={
                                item.planningId !== editId
                                  ? getValue(item.esd, TYPES.STRING, '')
                                  : getValue(
                                      RescheduleResponse.find(
                                        (x) => x.planningId === item.planningId,
                                      )?.esd,
                                      TYPES.STRING,
                                      '',
                                    )
                              }
                              onChange={(e) => {
                                ScheduleHandler(
                                  item,
                                  getValue(
                                    RescheduleResponse.find((x) => x.planningId === item.planningId)
                                      ?.duration,
                                    TYPES.STRING,
                                    '',
                                  ),
                                  getValue(
                                    RescheduleResponse.find((x) => x.planningId === item.planningId)
                                      ?.delay,
                                    TYPES.STRING,
                                    '',
                                  ),
                                  e.target.value,
                                  moment(moment(e.target.value).format('YYYY-MM-DD'))
                                    .add(
                                      Number(
                                        RescheduleResponse.find(
                                          (x) => x.planningId === item.planningId,
                                        )?.duration,
                                      ) - 1,
                                      'days',
                                    )
                                    .format('YYYY-MM-DD'),
                                )
                                // setSchedulebtn(true)
                              }}
                            />
                          </td>
                        )
                      },
                      EED: (item) => {
                        return (
                          <td>
                            <CFormInput
                              type="Date"
                              min={moment().format('YYYY-MM-DD')}
                              max="9999-01-01"
                              className="inputfieldgo date"
                              disabled
                              value={
                                item.planningId !== editId
                                  ? getValue(item.efd, TYPES.STRING, '')
                                  : getValue(
                                      RescheduleResponse.find(
                                        (x) => x.planningId === item.planningId,
                                      )?.efd,
                                      TYPES.STRING,
                                      '',
                                    )
                              }
                            />
                          </td>
                        )
                      },
                      ACTIONS: (items) => {
                        return (
                          <td className="gaponly">
                            {items.planningId !== editId ? (
                              <React.Fragment>
                                <CButton
                                  className="updateBtn"
                                  onClick={() => {
                                    // console.log(items, 'GGGGGGGGGGGGGG')
                                    // console.log(items.planningId, 'GGGGGGGGGGGGGG')
                                    setEditId(items.planningId)
                                  }}
                                >
                                  <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                              
                                  {/* <BsPencil
                                    style={{ fontSize: '16px', color: '#fff', display: 'inline' }}
                                  /> */}
                                </CButton>
                              </React.Fragment>
                            ) : (
                              <div className="d-flex flex-row">
                                <button
                                  className="save mright"
                                  onClick={(e) => {
                                    e.preventDefault(e)
                                    UpdateReScheduleProject(
                                      getValue(
                                        RescheduleResponse.find((x) => x.planningId === editId),
                                        TYPES.OBJECT,
                                        {},
                                      ),
                                    )
                                  }}
                                >
                                  Update 
                                </button>
                                <button
                                  className="reset"
                                  onClick={() => {
                                    setEditId('')
                                    setRescheduleResponse([])
                                  }}
                                >
                                  Cancel
                                </button>
                              </div>
                            )}
                          </td>
                        )
                      },
                    }}
                    sorterValue={{ column: 'name', state: 'asc' }}
                    // tableFilter
                    // tableHeadProps={{
                    //   color: 'danger',
                    // }}
                    tableProps={{
                      striped: true,
                      hover: true,
                    }}
                  />
                  
                </React.Fragment>
              )}
              <br />
          </CCol>
        </CRow>
      </CForm>
    </div>
  )
}

export default ReschedulingPlanningActivity
