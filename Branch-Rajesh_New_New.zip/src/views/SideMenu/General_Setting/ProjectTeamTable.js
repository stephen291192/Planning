
import React, { useContext } from 'react'
import { ToastContainer, toast } from 'react-toastify'
import { useState, useEffect } from 'react'
import {
  CSmartTable,
  CButton,
  CCollapse,
  CCardBody,
  CContainer,
  CCol,
  CRow,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react-pro'
import axios from 'axios'
import { FaEdit } from 'react-icons/fa'
import { USERTOKEN } from 'src/constants/localstorage'
import { BsPencil } from 'react-icons/bs'
import { RiDeleteBin6Line,RiDeleteBinFill } from 'react-icons/ri'
import { GlobalContext } from 'src/context'
import { URL } from 'src/services/URL'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3 } from 'react-icons/im'
import { BsPrinter } from 'react-icons/bs'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import ReactToPdf from 'react-to-pdf'
import TableDropdown from 'src/views/forms/TableDropdown/TableDropdown'
import { projectTeamDelete,ProjectTeamAPI} from 'src/services/ApiServices'

// eslint-disable-next-line react/prop-types
export const ProjectTeamTable = ({ updateDepartment,projectId , showAllProject}) => {
  const ref = React.createRef()
  const [teamName, setTeamName] = useState([])
  const [tableData,setTableData] = useState('')  
  const options = {
    orientation: 'landscape',
    unit: 'in',
    // format: [12, 0],
  }
  const { state, dispatch } = useContext(GlobalContext)
  const [visible, setVisible] = useState(false)
  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [tabledelete, setTabledelete] = useState({})

  const [itemsPerPage, setItemsPerPage] = useState('20')
  // const intial_state = () => {
  //   setDesignation([])
  //   setDepartment([])
  // }

    // 6374296154

  useEffect(() => {
    showTeam(projectId)
    
    // intial_state()
    // showDepartmnet()
  }, [projectId, state.companyId])



  const showTeam = async (projectId) => {
    var response
    setTeamName([])
    try {
      response = await ProjectTeamAPI(state.companyId,projectId)
      if (response) {
        console.log("sfdfsfsfgfdg",response)
        const data = response.data.map((x,i) => {
          return {

                S_no: i + 1,
                projectId: x?.projectId?._id,
                projectName: x?.projectId?.projectName,
                departmentName: x?.departmentId?.departmentName,
                departmentId:x?.departmentId?._id,

                reportingToStatus:x.reportingTo === null ? null : x.reportingTo,

                employeeId: x?.userId?._id,
                employeeName: `${x?.userId?.firstName} ${x?.userId?.lastName}`,
                
                reportingToDepartment: x?.reportingToDepartment?.departmentName
                  ? x.reportingToDepartment.departmentName
                  : '-',
                  reportingToDepartmentId:x?.reportingToDepartment?._id
                  ? x.reportingToDepartment._id
                  : '-',
                reportingTo: x?.reportingTo?.firstName
                  ? `${x?.reportingTo?.firstName} ${x?.reportingTo?.lastName}`
                  : '-',
                  reportingToId: x?.reportingTo?._id,
                  userId:x?.userId?._id,
                  teamId:x.teamId,
                  
          }
        })
        setTeamName(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const columns = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'projectName',
      label: 'Project',
      _style: { width: '10%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'departmentName',
      label: 'Department',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'employeeName',
      label: 'Employee Name',
      _style: { width: '20%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'reportingToDepartment',
      label: 'Reporting To Department',
      _style: { width: '20%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'reportingTo',
      label: 'Reporting to Employee',
      _style: { width: '20%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '15%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]

  // const myFunction = () => {
  //   window.open('https://www.google.com/')
  // }

  function openModal() {
    setIsOpen(true)
  }

  function closeModal() {
    setIsOpen(false)
  }

  const onDelete = async ( projectId, userId,e) => {
    var response
    try {
      response = await projectTeamDelete( projectId,userId,)
      if (response.success) {
        toast.success(response.message)
        showTeam(projectId)
        showAllProject()
      } else {
        toast.error(response.error || "Error")
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success === false) {
          toast.error(response.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <CContainer className="filterContainer filterContainer_New" >
      {/* <div className="ItemsPerPage">
        <span className="pageid">No of Rows</span> &nbsp;
        <TableDropdown
          defaultValue={'20'}
          value={itemsPerPage}
          onChange={(value) => {
            setItemsPerPage(value)
          }}
        />
      </div> */}
      {/* <div className="TableDownload">
        <button onClick={openModal} className="pdfbtns">
          <ImFilePdf /> PDF
        </button>
        <span className="tooltiptext">Download</span>
      </div> */}

      {columns.length > 0 ? (
        <CSmartTable
          activePage={1}
          // cleaner
          clickableRows
          columns={columns}
          columnFilter
          columnSorter
          // footer
          items={teamName}
          itemsPerPageSelect
          itemsPerPageLabel={'No of Rows'}
          itemsPerPage={5}
          pagination
          scopedColumns={{
            show_details: (item) => {
              return (

                <td className="gaponly">
                {/* {JSON.stringify(item)}   */}
                <CButton
                    className="updateBtn"
                    onClick={() => {
                      // showParentDepartment()
                      updateDepartment(item)
                    }}
                  >
                    <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                  </CButton>

                  <CButton
                    className="deleteBtn"
                    onClick={() => {
                      // console.log(item, 'HHDSODSH')
                      setTabledelete({
                        userId: item.userId,
                        projectId: item.projectId,
                      })
                      setTableData(item.employeeName)
                      setVisible(!visible)
                    }}
                  >
                     <RiDeleteBinFill
                          style={{ fontSize: '22px', color: '#ea4335' }}
                        />
                  </CButton>
                </td>
              )
            },
          }}
          sorterValue={{ column: 'name', state: 'asc' }}
          // tableFilter
          // tableHeadProps={{
          //   color: 'danger',
          // }}
          tableProps={{
            striped: true,
            hover: true,
          }}
        />
      ) : null}

      {/* Modal for Pdf Downloader */}

      <>
        <CModal size="sm" alignment="center" visible={visible} onClose={() => setVisible(false)}>
          <CModalHeader>
            <div
              className="times"
              onClick={() => {
                setVisible(false)
              }}
            >
              &times;
            </div>
            <CModalTitle>
              <span>
                <CIcon icon={cilTask} className="me-2" />
              </span>
              Confirm
            </CModalTitle>
          </CModalHeader>
          <CModalBody className="">
           <span> Are you sure do you want to delete the <br />
           Employee Name : <b>{tableData}</b> </span>
          </CModalBody>
          <CModalFooter>
            <button className="modelBtnNo" onClick={() => setVisible(false)}>
              No
            </button>
            <button
              className="modelBtnYes"
              onClick={() => {
                onDelete( tabledelete.projectId, tabledelete.userId)
                // onDelete(item.employeeId, item.projectId)
                setVisible(false)
              }}
            >
              Yes
            </button>
          </CModalFooter>
        </CModal>
      </>

      <CModal size="xl" visible={modalIsOpen} onClose={closeModal}>
        <ReactToPdf targetRef={ref} options={options} filename="Report.pdf">
          {({ toPdf }) => (
            <div className="PdfButton">
              <button onClick={toPdf} className="pdfbtnsDwn">
                Download <ImDownload3 size="15" />
              </button>
              {/* <span className="tooltipDownload">Download</span> */}
            </div>
          )}
        </ReactToPdf>
        <div ref={ref}>
          {console.log(state.companyLogo)}
          {/* <div>
              
            </div> */}
          <div className="PdfTableHeader">
            {state?.companyLogo !== '' && (
              <img src={state.companyLogo} alt="" className="LogoPDFPicture" />
            )}
            <h3 className="pdfModelTitle">
              {state.companies.find((x) => x.value == state.companyId)?.label}
            </h3>
            <div></div>
          </div>

          <div className="d-flex flex-row justify-content-around mt-5">
            <div>
              {' '}
              <span className="subhead">User Login:</span>{' '}
              <span className="username">{state.userName}</span>
            </div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div>
              <span className="subhead">Date:</span>
              <span className="username">
                {new Date().toLocaleDateString('en-us', {
                  // weekday: 'short',
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </span>
            </div>
          </div>

          <div className="PdfTable">
            <CSmartTable
              // itemsPerPageSelect
              // activePage={1}
              // cleaner
              clickableRows
              columns={columns.filter((x) => x.label != 'Action')}
              // columnFilter
              // columnSorter

              items={teamName}
              itemsPerPage={Number(itemsPerPage)}
              sorterValue={{ column: 'name', state: 'asc' }}
              tableProps={{
                striped: true,
                hover: true,
              }}
            />
          </div>
        </div>
      </CModal>
    </CContainer>
  )
}

// ProjectTeamTable.defaultProps = {
//   showAllProject : () =>{}
// }