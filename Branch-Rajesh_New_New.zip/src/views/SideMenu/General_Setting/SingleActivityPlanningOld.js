import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import { CSmartTable } from '@coreui/react-pro'
import Select from 'react-select'
import { toast } from 'react-toastify'
import axios from 'axios'
import { GlobalContext } from 'src/context'
import { URL } from 'src/services/URL'
import { ImFilePdf } from 'react-icons/im'
import { planningtableview } from 'src/services/ApiServices'
import TableDropdown from 'src/views/forms/TableDropdown/TableDropdown'
import { USERTOKEN } from 'src/constants/localstorage'
// import Multiselect from 'multiselect-react-dropdown'
import { MultiSelect } from 'react-multi-select-component'
import { number } from 'prop-types'
export const SingleActivityPlanningOld = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [projectId, setProjectId] = useState('')
  const [descriptionId, setDescriptionId] = useState('')
  const [description, setDescription] = useState([])
  const [descriptiontable, setDescriptionTable] = useState([])
  const [projectDrop, setProjectDrop] = useState([])
  const [projectAttrName, setProjectAttrName] = useState([])
  const [attributeId, setattributeId] = useState('')
  const [tiersName, setTiersName] = useState([])
  const [variableNames, setVariableNames] = useState([])
  const [variableNamesId, setVariableNamesId] = useState([])
  const [tiersDropdown, setTiersDropdown] = useState([])
  const [projectAttrNameTech, setProjectAttrNameTech] = useState([])
  const [attributeIdTech, setAttributeIdTech] = useState('')
  const [tiersNameTech, setTiersNameTech] = useState([])
  const [variableNamesTech, setVariableNamesTech] = useState([])
  const [variableNamesIdTech, setVariableNamesIdTech] = useState([])
  const [tiersDropdownTech, setTiersDropdownTech] = useState([])
  const [tableShow, setTableShow] = useState(false)
  const [taskDescription, setTaskDescription] = useState('')
  const [taskDescriptionDrop, setTaskDescriptionDrop] = useState([])
  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [projectError, setProjectError] = useState('')
  const [duration, setDuration] = useState('')
  const [esd, setEsd] = useState('')
  const [efd, setEfd] = useState('')
  const [lastTechAtt, setLastTechAtt] = useState([])
  const [myData, setMydata] = useState([])

  useEffect(() => {
    showAllProject()

    // showTaskDescriptionDrop()
    // tableforPlanning(state.employeeId)
  }, [state?.employeeId._id])
  const [scheduleResponse, setScheduleResponse] = useState([])
  const showTable = (Description) => {
    setScheduleResponse([])
    // const FunctionTirData = projectDrop.map((x) => {
    //   return {
    //     data: x.label,
    //   }
    // })

    // const month = moment([year, monthIndex - 1])
    // const weekNumbers = getWeekNumbers(year, monthIndex - 1)
    // const weekList = weeks(month)
    // console.log('weekNumbers', weekNumbers)
    // console.log('weekList', weekList)
    // weekList.forEach((date) => {
    //   console.log(
    //     'start - ' + date.startDate.format('YYYY-MM-DD'),
    //     '\nend - ' + date.endDate.format('YYYY-MM-DD'),
    //   )
    // })

    const functionalAttr = variableNamesId.reduce((previous, next, index) => {
      console.log(previous.label, next.label, index, 'DDSSFSFDsfds')
      if (index == 1) {
        console.log(previous.label, next.label, index, 'DDSSFSFDsfds')

        return `${previous.label}- ${next.label}`
      } else {
        console.log(previous, next.label, index, 'DDSSFSFDsfds2')

        return `${previous}- ${next.label}`
      }
    })
    const technicalAttr = variableNamesIdTech.reduce((previous, next, index) => {
      console.log(previous.label, next.label, index, 'DDSSFSFDsfds')
      if (index == 1) {
        console.log(previous.label, next.label, index, 'DDSSFSFDsfds')

        return `${previous.label}- ${next.label}`
      } else {
        console.log(previous, next.label, index, 'DDSSFSFDsfds2')

        return `${previous}- ${next.label}`
      }
    })

    const totalData = lastTechAtt.map((x, index) => {
      const FunctionTirData = tiersDropdown.map((x) => {
        return {
          tierId: x.tierId,
        }
      })
      const FunctionVariable = variableNamesId.map((x) => {
        return {
          variableId: x.value,
        }
      })

      const TechTirData = tiersDropdownTech.map((x) => {
        return {
          tierId: x.tierIdTech,
        }
      })
      const TechVariable = variableNamesIdTech.map((x) => {
        return {
          variableId: x.value,
        }
      })

      return {
        S_no: index + 1,
        ActionName: Description,
        AssignBy: `${state.firstName} ${state.lastName}`,
        allProject: projectId.label,
        functionAttributes: `${attributeId.label} - ${functionalAttr}`,
        technicalAttributes: `${attributeIdTech.label} - ${technicalAttr} - ${x.label}`,
        DummyId: x.value,
        employeeId: state.employeeId._id,
        delay: 0,
        projectId: projectId.value,
        taskDescription: Description,

        functionalAttributeId: attributeId.value,
        functionalTierDetails: FunctionTirData,
        functionalVariableDetails: variableNamesId,

        technicalAttributeId: attributeIdTech.value,
        technicalTierDetails: TechTirData,
        technicalVariableDetails: [...TechVariable, { variableId: x.value }],
      }
    })
    setMydata(totalData)
    console.log('DDD', myData)
  }

  const ref = React.createRef()

  const ScheduleHandler = (data, duration, startDate, endDate) => {
    const isAlreadyAvailable = scheduleResponse.find((x) => x.DummyId == data.DummyId)
    const filteredData = scheduleResponse.filter((x) => x.DummyId !== data.DummyId)

    if (isAlreadyAvailable) {
      setScheduleResponse([
        ...filteredData,
        {
          ...isAlreadyAvailable,
          duration: duration,
          delay: 0,
          esd: startDate,
          efd: endDate,
        },
      ])
    } else {
      setScheduleResponse([
        ...filteredData,
        {
          ...data,
          duration: duration,
          delay: 0,
          esd: startDate,
          efd: endDate,
        },
      ])
    }
  }

  const options = {
    orientation: 'landscape',
    unit: 'in',
    // format: [12, 0],
  }

  // Clear Button
  const handleCancel = () => {
    setProjectId('')
    setattributeId('')
    setAttributeIdTech('')
    setTaskDescription('')
    setTiersName([])
    setVariableNamesId([])
    setTiersNameTech([])
    setVariableNamesIdTech([])
    setDescriptionId([])
    setLastTechAtt([])
  }

  function openModal() {
    setIsOpen(true)
  }

  function closeModal() {
    setIsOpen(false)
  }

  // Show All project by on employee dropdown API
  const showAllProject = async () => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      axios
        .get(`${URL}/project/mapping/employee/getall/${state.employeeId._id}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        })
        .then((response) => {
          if (response) {
            const data = response.data.data.projects.map((x) => {
              return {
                value: x._id,
                label: x.projectName,
                projectId: x._id,
              }
            })
            setProjectDrop(data)
          }
        })
    } catch (e) {
      console.log(e)
    }
  }

  // Functional Attribute dropdown API
  const showFunctionalAttribute = async (id) => {
    setProjectAttrName([])
    const token = await localStorage.getItem('USERTOKEN')
    axios
      .get(`${URL}/attributes/${state.companyId}/${id}`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
      })
      .then((response) => {
        if (response) {
          if (response.data.success) {
            if (response.data.attributes) {
              const data = response.data.attributes.map((x, i) => {
                return {
                  value: x._id,
                  label: x.attributeName,
                  tiers: x.tiers,
                  tiersValue: x.tiers.value,
                }
              })
              setProjectAttrName(data)
              // console.log(data, 'aaaa')
            }
            toast.success(response.message)
          } else {
            toast.error(response.error)
          }
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }
  // Function Varibale 1st dropdown
  const FunctiongetFirstDropdown = async (projectId, attributeId, tierId) => {
    const token = await localStorage.getItem('USERTOKEN')
    setVariableNamesId([])
    setVariableNames([])
    setTiersDropdown([])
    try {
      await axios({
        method: 'Get',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
        url: `${URL}/variable/firstparent/${projectId}/${attributeId}/${tierId}`,
      }).then((response) => {
        if (response) {
          console.log(response, 'dfirst')
          if (response.data.success) {
            toast.success(response?.data.message)
            const data = response.data.variables.map((x) => {
              return {
                value: x._id,
                label: x.variableName,
              }
            })
            const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
            setTiersDropdown([
              ...filtrDatas,
              {
                tierId: tierId,
                dropdown: data,
              },
            ])
          } else {
            toast.error(response?.data.error)
          }
        }
      })
    } catch (e) {
      console.log(e)
    }
  }
  // Function Varibale 2nd dropdown
  const FunctionParentDropdown = async (
    projectId,
    attributeId,
    tierId,
    parentTierId,
    parentVariableId,
  ) => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      await axios({
        method: 'Get',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
        url: `${URL}/variable/parent/${projectId}/${attributeId}/${tierId}/${parentTierId}/${parentVariableId}`,
      }).then((response) => {
        if (response) {
          if (response.data.success) {
            // toast.success(response?.data.message)
            const data = response.data.variables.map((x) => {
              return {
                value: x._id,
                label: x.variableName,
              }
            })
            const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
            setTiersDropdown([
              ...filtrDatas,
              {
                tierId: tierId,
                dropdown: data,
              },
            ])
          } else {
            toast.error(response?.data.error)
          }
        }
      })
    } catch (e) {
      console.log(e)
    }
  }

  const showTechnicalAttribute = async () => {
    setProjectAttrNameTech([])
    const token = await localStorage.getItem('USERTOKEN')
    axios
      .get(`${URL}/attribute/technical/getAll`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
      })
      .then((response) => {
        if (response) {
          if (response.data.success) {
            if (response.data.data) {
              const data = response.data.data.map((x, i) => {
                return {
                  value: x._id,
                  label: x.attributeName,
                  tiers: x.tiers,
                  tiersValue: x.tiers.value,
                  techattributeId: x._id,
                }
              })
              setProjectAttrNameTech(data)
              // console.log(data, 'aaaa')
            }
            toast.success(response.message)
          } else {
            toast.error(response.error)
          }
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }

  const TechnicalFirstDropdown = async (attributeIdTech, tierIdTech) => {
    const token = localStorage.getItem('USERTOKEN')
    setVariableNamesIdTech([])
    setVariableNamesTech([])
    setTiersDropdownTech([])
    await axios({
      method: 'Get',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
      url: `${URL}/variables/technical/firstparent/${attributeIdTech}/${tierIdTech}`,
    }).then((response) => {
      if (response) {
        console.log(response, 'dfirst')
        if (response.data.success) {
          toast.success(response?.data.message)

          if (response.data.variables) {
            const data = response.data.variables.map((x, i) => {
              return {
                value: x._id,
                label: x?.variableName,
              }
            })
            const filtrDatasTech = tiersDropdownTech.filter((x) => x.tierIdTech !== tierIdTech)
            setTiersDropdownTech([
              ...filtrDatasTech,
              {
                tierIdTech: tierIdTech,
                dropdown: data,
              },
            ])
          }
        } else {
          toast.error(response?.data.error)
        }
      }
    })
  }

  const TechnicalgetParentDropdown = async (
    attributeIdTech,
    tierIdTech,
    parentTierId,
    parentVariableId,
  ) => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      await axios({
        method: 'Get',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
        url: `${URL}/variable/technical/byparent/${attributeIdTech}/${tierIdTech}/${parentTierId}/${parentVariableId}`,
      }).then((response) => {
        if (response) {
          if (response.data.success) {
            // toast.success(response?.data.message)
            const data = response.data.variables.map((x) => {
              return {
                value: x._id,
                label: x.variableName,
              }
            })
            const filtrDatasTech = tiersDropdownTech.filter((x) => x.tierIdTech !== tierIdTech)
            setTiersDropdownTech([
              ...filtrDatasTech,
              {
                tierIdTech: tierIdTech,
                dropdown: data,
              },
            ])
          } else {
            toast.error(response?.data.error)
          }
        }
      })
    } catch (e) {
      console.log(e)
    }
  }

  // const tableforPlanning = async (employeeId) => {
  //   var response
  //   try {
  //     response = await planningtableview(employeeId)
  //     if (response) {
  //       if (response.success) {
  //         console.log(response.data, 'DSDASDSADASDAS')
  //         const data = response.data.map((x, i) => {
  //           return {
  //             S_no: i + 1,
  //             ActionName: x.taskDescription,
  //             AssignBy: state.firstName,
  //             allProject: x.projectId.projectName,

  //             functionAttributes: `${
  //               x.functionalAttributeId.attributeName
  //             } / ${x?.functionalVariableDetails.map((x) => x.variableName)}`,
  //             technicalAttributes: `${
  //               x.technicalAttributeId.attributeName
  //             } / ${x?.technicalVariableDetails.map((x) => x.variableName)}`,
  //             // functionAttributes: `${x.functionalAttributeId.attributeName}
  //             //   /${x?.functionalVariableDetails[0]?.variableName}
  //             //   /${x?.functionalVariableDetails[1]?.variableName}/${x?.functionalVariableDetails[2]?.variableName}`,
  //             // technicalAttributes: `${x.technicalAttributeId.attributeName}/
  //             //   ${x.technicalVariableDetails[0]?.variableName}/
  //             //   ${x.technicalVariableDetails[1]?.variableName}/
  //             //   ${x.technicalVariableDetails[2]?.variableName}`,
  //             descriptionId: x._id,
  //           }
  //         })
  //         setDescriptionTable(data)
  //       }
  //     }
  //   } catch (e) {}
  // }

  const showTaskDescriptionDrop = async () => {
    const token = await localStorage.getItem('USERTOKEN')
    setTaskDescriptionDrop([])

    axios
      .get(`${URL}/task/description/getAll/${state.employeeId._id}`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
      })
      .then((response) => {
        if (response) {
          if (response.data.success) {
            if (response.data.data) {
              console.log('ZZ', response)
              const data = response.data.data.map((x, i) => {
                return {
                  value: x._id,
                  label: x.taskDescription,

                  // description: x.taskDescription,

                  // typeofInstitution: x.functionalVariableDetails.map((y) => {
                  //   return {
                  //     value: y.variableName,
                  //   }
                  // }),
                  // bookPages: x.technicalVariableDetails,
                  // reportingTo: x.reportingTo?.designationName ? x.reportingTo.designationName : '-',
                  // reportingToId: x.reportingTo?._id ? x.reportingTo._id : undefined,
                }
              })
              setDescription(data)
              console.log('z', data)
            }
            toast.success(response.message)
          } else {
            toast.error(response.error)
          }
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }

  const columns = [
    {
      key: 'S_no',
      label:'S.No',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'ActionName',
      label: 'Action Name',
      _style: { width: '12%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'AssignBy',
      label: 'Assign By',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'allProject',
      label: 'Project',
      _style: { width: '8%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'functionAttributes',
      label: 'Function Attributes',
      _style: { width: '18%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },

    {
      key: 'technicalAttributes',
      label: 'Technical Attributes',
      _style: { width: '18%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'Duration',
      label: 'Duration  (Estimate Days)',
      _style: { width: '12%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'ESD',
      label: 'Estimate Start Date',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'EED',
      label: 'Estimate End Date',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
  ]

  const savePlanning = async (e) => {
    e.preventDefault()
    console.log(scheduleResponse, 'SSOSAOJSA')
    const token = await localStorage.getItem(USERTOKEN)

    // const FunctionTirData = tiersDropdown.map((x) => {
    //   return {
    //     tierId: x.tierId,
    //   }
    // })
    // const FunctionVariable = variableNamesId.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })

    // const TechTirData = tiersDropdownTech.map((x) => {
    //   return {
    //     tierId: x.tierIdTech,
    //   }
    // })
    // const TechVariable = variableNamesIdTech.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })

    // const data =  {
    //         employeeId: state.employeeId,
    //         projectId: projectId.value,

    //         functionalAttributeId: attributeId.value,

    //         functionalTierDetails: FunctionTirData,
    //         functionalVariableDetails: variableNamesId,

    //         technicalAttributeId: attributeIdTech.value,

    //         technicalTierDetails: TechTirData,
    //         technicalVariableDetails: variableNamesIdTech,

    //         taskDescription: taskDescription,

    //         duration,
    //         delay: 0,
    //         esd,
    //         efd,
    //       },

    await axios
      .post(
        `${URL}/employee/planning/task/create`,
        {
          data: scheduleResponse,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        },
      )
      .then((res) => {
        const response = res.data
        console.log(response, 'AAA')
        if (response && response.success === true) {
          toast.success(response.message)
          setProjectId('')
          setattributeId('')
          setAttributeIdTech('')
          setTaskDescription('')
          setTiersName([])
          setVariableNamesId([])
          setTiersNameTech([])
          setVariableNamesIdTech([])
        } else {
          toast.error(response.error)
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }

  return (
    <div>
      <div>
        <CForm>
          <CRow>
            <CCol xs={12}>
              <CCard className="mb-6">
                <div className="panel-heading">
                  <div className="col-xs-6">
                    <h3 className="font_Title">PLANNING AND SCHEDULING</h3>
                  </div>
                </div>
                <CCardBody>
                  <CForm>
                    <CRow className="mb-3">
                      <CFormLabel className="col-sm-2 col-form-label donlabel">
                        All Project <code>*</code>
                      </CFormLabel>
                      <CCol sm={3}>
                        <Select
                          className={'inputfieldso'}
                          options={projectDrop}
                          value={projectId}
                          onChange={(e) => {
                            setProjectId(e)
                            setTableShow(false)
                            showFunctionalAttribute(e.value)
                            showTechnicalAttribute(e.value)
                            setattributeId('')
                            setAttributeIdTech('')
                            setTaskDescription('')
                            setTiersName([])
                            setVariableNamesId([])
                            setTiersNameTech([])
                            setVariableNamesIdTech([])
                          }}
                          placeholder="All Project "
                        />
                        <span
                          style={{
                            fontWeight: '500',
                            fontSize: '12px',
                            color: 'red',
                          }}
                        >
                          {projectError}
                        </span>
                      </CCol>
                    </CRow>
                    <CRow className="mb-3">
                      <CFormLabel className="col-sm-2 col-form-label donlabel">
                        Function Attributes <code>*</code>
                      </CFormLabel>
                      <CCol sm={3}>
                        <Select
                          options={projectAttrName}
                          className="inputfieldso"
                          value={attributeId}
                          isDisabled={!projectId}
                          onChange={(e) => {
                            setattributeId(e)
                            setTiersName([])
                            setVariableNamesId([])
                            setTiersName(
                              e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers,
                            )
                            if (
                              (e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers).length >
                              0
                            ) {
                              FunctiongetFirstDropdown(projectId.value, e.value, e.tiers[0]._id)
                            }
                          }}
                          placeholder="Function Attribute"
                        />
                      </CCol>
                      <CCol sm={6} className="flex_row">
                        {tiersName.map((x, i) => (
                          <div key={i}>
                            <CRow className="mb-3">
                              <CFormLabel
                                id="Text"
                                className="col-sm-9 col-form-label donlabel "
                                key={i}
                              >
                                {x.value} <code>*</code>
                              </CFormLabel>
                              <CCol sm={10}>
                                <CForm>
                                  <Select
                                    options={
                                      tiersDropdown.find((tier) => tier.tierId === x._id)?.dropdown
                                        ? tiersDropdown.find((tier) => tier.tierId === x._id)
                                            ?.dropdown
                                        : []
                                    }
                                    value={variableNamesId.find((varName) => varName.index === i)}
                                    className="inputfieldso "
                                    onChange={(e) => {
                                      const filterData = variableNamesId.filter(
                                        (n) => n.index !== i,
                                      )
                                      setVariableNamesId([
                                        ...filterData,
                                        {
                                          ...e,
                                          index: i,
                                          tierId: x._id,
                                          variableId: e.value,
                                        },
                                      ])
                                      if (tiersName.length === i + 1) {
                                      } else {
                                        FunctionParentDropdown(
                                          projectId.value,
                                          attributeId.value,
                                          tiersName[i + 1]._id,
                                          x._id,
                                          e.value,
                                        )
                                      }
                                    }}
                                    // placeholder="Select Variable Name"
                                  />
                                </CForm>
                              </CCol>
                            </CRow>
                          </div>
                        ))}
                      </CCol>
                    </CRow>

                    <CRow className="mb-3">
                      <CFormLabel className="col-sm-2 col-form-label donlabel">
                        Technical Attributes <code>*</code>
                      </CFormLabel>
                      <CCol sm={3}>
                        <Select
                          options={projectAttrNameTech}
                          className="inputfieldso"
                          value={attributeIdTech}
                          isDisabled={
                            !projectId ||
                            !attributeId ||
                            !variableNamesId.find((varName) => varName.index)
                          }
                          onChange={(e) => {
                            setAttributeIdTech(e)
                            setTiersNameTech([])
                            setVariableNamesIdTech([])

                            setTiersNameTech(
                              e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers,
                            )
                            if (
                              (e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers).length >
                              0
                            ) {
                              TechnicalFirstDropdown(e.value, e.tiers[0]._id)
                            }
                          }}
                          placeholder="Technical Attributes"
                        />
                      </CCol>
                      <CCol sm={6} className="flex_row">
                        {tiersNameTech &&
                          tiersNameTech.map((x, i) => (
                            <div key={i}>
                              <CRow className="mb-3">
                                <CFormLabel
                                  id="Text"
                                  className="col-sm-9 col-form-label donlabel"
                                  key={i}
                                >
                                  {x.value} <code>*</code>
                                </CFormLabel>
                                {/* Tiers DropDown Starts */}
                                <CCol sm={10}>
                                  <CForm>
                                    {i == tiersNameTech.length - 1 ? (
                                      <>
                                        <MultiSelect
                                          className={'inputfieldso'}
                                          // options={projectName}
                                          // value={projectId}
                                          // value={variableNamesIdTech.find(
                                          //   (varName) => varName.index === i,
                                          // )}

                                          value={lastTechAtt}
                                          options={
                                            tiersDropdownTech.find(
                                              (tier) => tier.tierIdTech === x._id,
                                            )?.dropdown
                                              ? tiersDropdownTech.find(
                                                  (tier) => tier.tierIdTech === x._id,
                                                )?.dropdown
                                              : []
                                          }
                                          displayValue="key"
                                          // isObject={false}
                                          // onKeyPressFn={function noRefCheck() {}}
                                          // onRemove={function noRefCheck() {}}
                                          // onSearch={function noRefCheck() {}}
                                          // onSelect={function noRefCheck() {}}
                                          // onChange={(e) => {
                                          //   setProjectId(e)
                                          //   setTableShow(true)
                                          //   showAllProjectTabel(e.value)
                                          // }}

                                          onChange={(e) => {
                                            console.log('MULTI', e)
                                            setLastTechAtt(e)
                                            showTaskDescriptionDrop()
                                            setDescriptionId('')
                                            setTableShow(false)
                                            // const filterData = variableNamesIdTech.filter(
                                            //   (n) => n.index !== i,
                                            // )
                                            // setVariableNamesIdTech([
                                            //   ...filterData,
                                            //   {
                                            //     ...e,
                                            //     index: i,
                                            //     tierIdTech: x._id,
                                            //     variableId: e.value,
                                            //   },
                                            // ])
                                            // if (tiersNameTech.length === i + 1) {
                                            // } else {
                                            //   TechnicalgetParentDropdown(
                                            //     attributeIdTech.value,
                                            //     tiersNameTech[i + 1]._id,
                                            //     x._id,
                                            //     e.value,
                                            //   )
                                            // }
                                          }}
                                        />
                                      </>
                                    ) : (
                                      <Select
                                        options={
                                          tiersDropdownTech.find(
                                            (tier) => tier.tierIdTech === x._id,
                                          )?.dropdown
                                            ? tiersDropdownTech.find(
                                                (tier) => tier.tierIdTech === x._id,
                                              )?.dropdown
                                            : []
                                        }
                                        value={variableNamesIdTech.find(
                                          (varName) => varName.index === i,
                                        )}
                                        className="inputfieldso"
                                        onChange={(e) => {
                                          const filterData = variableNamesIdTech.filter(
                                            (n) => n.index !== i,
                                          )
                                          setVariableNamesIdTech([
                                            ...filterData,
                                            {
                                              ...e,
                                              index: i,
                                              tierIdTech: x._id,
                                              variableId: e.value,
                                            },
                                          ])
                                          if (tiersNameTech.length === i + 1) {
                                          } else {
                                            TechnicalgetParentDropdown(
                                              attributeIdTech.value,
                                              tiersNameTech[i + 1]._id,
                                              x._id,
                                              e.value,
                                            )
                                          }
                                        }}
                                      />
                                    )}
                                  </CForm>
                                </CCol>
                              </CRow>
                            </div>
                          ))}
                      </CCol>
                    </CRow>

                    <CRow className="mb-3">
                      <CFormLabel className="col-sm-2 col-form-label donlabel">
                        Description <code>*</code>
                      </CFormLabel>
                      <CCol sm={3}>
                        <Select
                          className={'inputfieldso'}
                          isDisabled={
                            !projectId ||
                            !attributeId ||
                            !attributeIdTech ||
                            !variableNamesIdTech.find((varName) => varName.index)
                          }
                          options={description}
                          value={descriptionId}
                          onChange={(e) => {
                            setDescriptionId(e)
                            setTableShow(true)
                            showTable(e.label)
                            // tableforPlanning(state.employeeId)
                          }}
                          placeholder="Description "
                        />
                      </CCol>
                    </CRow>
                  </CForm>
                </CCardBody>
                {tableShow && (
                  <div className="TabelOver">
                    <br />
                    <div className="ItemsPerPageMappage">
                      <span className="pageid">No of Rows</span> &nbsp;
                      <TableDropdown
                        onChange={(value) => {
                          setItemsPerPage(value)
                        }}
                      />
                    </div>
                    <div className="TableDownloadmapPage">
                      <button onClick={openModal} className="pdfbtns">
                        <ImFilePdf /> PDF
                      </button>
                      {/* <span className="tooltiptext">Download</span> */}
                    </div>
                    <br /> <br />
                    <CSmartTable
                      activePage={1}
                      clickableRows
                      columns={columns}
                      columnFilter
                      columnSorter
                      items={myData}
                      // items={descriptiontable
                      //   .filter((x) => x.descriptionId === descriptionId?.value)
                      //   .map((z, index) => ({ ...z, S_no: index + 1 }))}
                      // itemsPerPage={Number(itemsPerPage)}
                      pagination
                      scopedColumns={{
                        Duration: (item) => {
                          return (
                            <td>
                              <CFormInput
                                type="number"
                                placeholder="Duration"
                                className="inputfieldgo"
                                value={
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                  0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                        .duration
                                    : ''
                                }
                                onChange={(e) => {
                                  ScheduleHandler(
                                    item,
                                    e.target.value,
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                      : '',
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId).efd
                                      : '',
                                  )
                                }}
                              />
                            </td>
                          )
                        },
                        ESD: (item) => {
                          return (
                            <td>
                              <CFormInput
                                type="Date"
                                min="1899-01-01"
                                max="9999-01-01"
                                className="inputfieldgo"
                                value={
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                  0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                    : ''
                                }
                                onChange={(e) => {
                                  // setEsd(e.target.value)
                                  ScheduleHandler(
                                    item,
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                          .duration
                                      : '',
                                    e.target.value,
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId).efd
                                      : '',
                                  )
                                }}
                              />
                            </td>
                          )
                        },
                        EED: (item) => {
                          return (
                            <td>
                              <CFormInput
                                type="Date"
                                min="1899-01-01"
                                max="9999-01-01"
                                className="inputfieldgo"
                                value={
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                  0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId).efd
                                    : ''
                                }
                                onChange={(e) => {
                                  // setEfd(e.target.value)
                                  ScheduleHandler(
                                    item,
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                          .duration
                                      : '',
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                      : '',
                                    e.target.value,
                                  )
                                }}
                              />
                            </td>
                          )
                        },
                      }}
                      sorterValue={{ column: 'name', state: 'asc' }}
                      // tableFilter
                      // tableHeadProps={{
                      //   color: 'danger',
                      // }}
                      tableProps={{
                        striped: true,
                        hover: true,
                      }}
                    />
                    <br />
                    <div className="d-flex flex-row justify-content-end">
                      <div>
                        <button
                          className="loginBtn1 mright"
                          type="submit"
                          // disabled={
                          //   !projectId ||
                          //   !attributeId ||
                          //   !attributeIdTech ||
                          //   !tiersDropdownTech ||
                          //   !descriptionId
                          // }
                          onClick={(e) => {
                            savePlanning(e)
                            handleCancel()
                            setTableShow(false)
                          }}
                        >
                          Schedule
                        </button>
                      </div>

                      <div>
                        <button
                          style={{ marginRight: '15px' }}
                          className="reset"
                          onClick={() => {
                            handleCancel()
                            setTableShow(false)
                          }}
                        >
                          clear
                        </button>
                      </div>
                    </div>
                    <br />
                  </div>
                )}
              </CCard>
            </CCol>
          </CRow>
        </CForm>
      </div>
    </div>
  )
}
