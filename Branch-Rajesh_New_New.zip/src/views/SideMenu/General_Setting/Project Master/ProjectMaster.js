import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import { toast } from 'react-toastify'
import { GlobalContext } from 'src/context'
import ProjectMasterTable from '../ProjectMasterTable'
import { addProject, getCompanyByUserType, updateProject } from 'src/services/ApiServices'

export const ProjectMaster = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [addScreen, setAddScreen] = useState(true)
  const [update, setUpdate] = useState(false)
  const [projectName, setProjectName] = useState('')
  const [projectNameCode, setProjectNameCode] = useState('')
  const [projectNameAbb, setProjectNameAbb] = useState('')

  const [projectId, setProjectId] = useState('')
  const [proError, setProError] = useState('')
  const [proErrorCode, setProErrorCode] = useState('')
  const [proErrorAbb, setProErrorAbb] = useState('')
  const [company, setCompany] = useState([])
  const [companyId, setCompanyId] = useState('')

  // console.log(state, 'state valuesssssssssssssssss')

  const clearFunc = () => {
    setProjectNameCode('')
    setProjectName('')
    setProErrorAbb('')
    setProError('')
    setProErrorCode('')
    setProjectNameAbb('')
  }
  const validateproject = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 3) {
      setProError('Project List Name should be 3 letters')
    } else {
      setProError()
    }
  }

  const validateprojectCode = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 2) {
      setProErrorCode('Project Code should be 2 letters')
    } else {
      setProErrorCode()
    }
  }

  const validateprojectAbb = (e) => {
    const phone = e.target.value.trim()
    if (phone.length < 3) {
      setProErrorAbb('Project Abbreviation should be 3 letters')
    } else {
      setProErrorAbb()
    }
  }

  const updateProjectmaster = (data) => {
    setAddScreen(!addScreen)
    setUpdate(true)
    console.log(data, 'boss')
    setProjectName(data.projectName)
    setProjectNameAbb(data.abbreviation)
    setProjectNameCode(data.code)
    setCompany(data?.companyId?.companyName)
    setCompanyId({
      value: data?.companyId?.companyId,
      label: data?.companyId?.companyName,
    })
    setProjectId({
      value: data.projectId,
      label: data.projectName,
    })
  }

  const saveProjectmaster = async (companyId) => {
    const data = {
      projectName: projectName,
      abbreviation: projectNameAbb,
      code: projectNameCode,
    }
    try {
      const response = await addProject(data, companyId)
      if (response) {
        if (response.success) {
          toast.success(response.message)
          setProjectName('')
          setCompanyId('')
          setAddScreen(!addScreen)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
          setAddScreen(!addScreen)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const saveProjectmasterupdate = async (companyId, projectId) => {
    const data = {
      projectName: projectName,
      abbreviation: projectNameAbb,
      code: projectNameCode,
    }
    try {
      const response = await updateProject(data, companyId, projectId)
      if (response) {
        if (response.success) {
          toast.success(response.message)
          setProjectName('')
          setAddScreen(!addScreen)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
          setAddScreen(!addScreen)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  return (
    <div>
      {addScreen ? (
        <div>
          <div className="d-flex align-items-center justify-content-between">
            <div className="font_Title pt-2 pb-0">Project List</div>
            <div>
              <button
                className="loginBtn mright loginBtn_New"
                onClick={() => {
                  setAddScreen(!addScreen)
                  setUpdate(false)
                  setProjectName('')
                  setCompanyId('')
                  setProjectNameAbb('')
                  setProjectNameCode('')
                }}
              >
                Add New
              </button>
            </div>
          </div>
          <CRow>
            <CCol xs={12}>
              <ProjectMasterTable updateProjectmaster={updateProjectmaster} />
            </CCol>
          </CRow>
        </div>
      ) : (
        <div>
          <CForm>
            <CRow>
              <CCol xs={12}>
                <div className="panel-heading">
                  <div className="col-xs-6">
                    {update ? (
                      <h3 className="font_Title">Update Project</h3>
                    ) : (
                      <h3 className="font_Title">Creating Project</h3>
                    )}
                  </div>
                </div>
                <CCard className="mb-6">
                  <CCardBody>
                    <CForm>
                      <CRow className="mb-3">
                        <>
                          <CCol sm={3}>
                            {update ? (
                              <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                                Update Project <code>*</code>
                              </CFormLabel>
                            ) : (
                              <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                                Add New Project <code>*</code>
                              </CFormLabel>
                            )}
                            <CFormInput
                              type="text"
                              value={projectName}
                              onChange={(e) => {
                                setProjectName(e.target.value)
                                validateproject(e)
                              }}
                              className="inputfieldgo"
                              placeholder="Enter a New Project"
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {proError}
                            </span>
                          </CCol>
                          <CCol sm={3}>
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Abbreviation <code>*</code>
                            </CFormLabel>
                            <CFormInput
                              type="text"
                              value={projectNameAbb}
                              onChange={(e) => {
                                const inputValue = e.target.value.slice(0, 3).toUpperCase() // Limit input to 3 characters

                                setProjectNameAbb(inputValue)
                                validateprojectAbb(e)
                              }}
                              className="inputfieldgo"
                              placeholder="Enter a Abbreviation Code"
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {proErrorAbb}
                            </span>
                          </CCol>
                          <CCol sm={3}>
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Code <code>*</code>
                            </CFormLabel>
                            <CFormInput
                              type="text"
                              value={projectNameCode}
                              onChange={(e) => {
                                const inputValue = e.target.value.slice(0, 2).toUpperCase() // Limit input to 2 characters
                                setProjectNameCode(inputValue)
                                validateprojectCode(e)
                              }}
                              className="inputfieldgo"
                              placeholder="Enter a Project code"
                            />
                            <span
                              style={{
                                fontWeight: '500',
                                fontSize: '12px',
                                color: 'red',
                              }}
                            >
                              {proErrorCode}
                            </span>
                          </CCol>

                          {/* <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Select Company 01<code>*</code>
                          </CFormLabel>
                          <CCol sm={12}>
                            <Select
                              options={company}
                              className="inputfieldso"
                              value={companyId}
                              isDisabled={update}
                              onChange={(e) => {
                                setCompanyId(e)
                              }}
                              placeholder="Name of a company"
                            />
                          </CCol> */}
                        </>
                      </CRow>

                      <div className="d-flex flex-row justify-content-end">
                        {update ? (
                          <div>
                            <button
                              className="loginBtn mright"
                              type="submit"
                              onClick={(e) => {
                                saveProjectmasterupdate(state.companyId, projectId.value)
                                e.preventDefault()
                              }}
                            >
                              Update
                            </button>
                          </div>
                        ) : (
                          <div>
                            <button
                              className="save mright"
                              onClick={(e) => {
                                saveProjectmaster(state.companyId)
                                e.preventDefault()
                              }}
                              type="submit"
                              disabled={!projectName || proError}
                            >
                              save
                            </button>
                          </div>
                        )}
                        {update ? (
                          <></>
                        ) : (
                          <div>
                            <button className="clear mright" onClick={() => clearFunc()}>
                              Clear
                            </button>
                          </div>
                        )}
                        <div>
                          <button className="reset" onClick={() => setAddScreen(!addScreen)}>
                            cancel
                          </button>
                        </div>
                      </div>
                    </CForm>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
          </CForm>
        </div>
      )}
    </div>
  )
}
