import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import { CSmartTable } from '@coreui/react-pro'
import Select from 'react-select'
import { toast } from 'react-toastify'
import axios from 'axios'
import { GlobalContext } from 'src/context'
import { URL } from 'src/services/URL'
import { ImFilePdf } from 'react-icons/im'
import {
  descriptiondashboard,
  planningtableview,
  TaskDescriptionAllProject,
  SelectEmployeeByProject,
  TaskDescriptionFunctionattr,
} from 'src/services/ApiServices'
import TableDropdown from 'src/views/forms/TableDropdown/TableDropdown'
import { USERTOKEN } from 'src/constants/localstorage'
// import Multiselect from 'multiselect-react-dropdown'
import { MultiSelect } from 'react-multi-select-component'
import { number } from 'prop-types'
import moment from 'moment'
import { getValue, TYPES } from 'src/services/utility'

export const OtherUserActivityPlanning = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [projectId, setProjectId] = useState('')
  const [descriptionId, setDescriptionId] = useState('')
  const [description, setDescription] = useState([])
  const [descriptiontable, setDescriptionTable] = useState([])
  const [projectDrop, setProjectDrop] = useState([])
  const [projectAttrName, setProjectAttrName] = useState([])
  const [attributeId, setattributeId] = useState('')
  const [tiersName, setTiersName] = useState([])
  const [variableNames, setVariableNames] = useState([])
  const [variableNamesId, setVariableNamesId] = useState([])
  const [tiersDropdown, setTiersDropdown] = useState([])
  const [projectAttrNameTech, setProjectAttrNameTech] = useState([])
  const [attributeIdTech, setAttributeIdTech] = useState('')
  const [tiersNameTech, setTiersNameTech] = useState([])
  const [variableNamesTech, setVariableNamesTech] = useState([])
  const [variableNamesIdTech, setVariableNamesIdTech] = useState([])
  const [tiersDropdownTech, setTiersDropdownTech] = useState([])
  const [tableShow, setTableShow] = useState(false)
  const [taskDescription, setTaskDescription] = useState('')
  const [taskDescriptionDrop, setTaskDescriptionDrop] = useState([])
  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [projectError, setProjectError] = useState('')
  const [duration, setDuration] = useState('')
  const [esd, setEsd] = useState('')
  const [efd, setEfd] = useState('')
  const [lastTechAtt, setLastTechAtt] = useState([])
  const [myData, setMydata] = useState([])
  const [TaskDescdropselect, setTaskDescdropselect] = React.useState(false)
  const [techBtnEnable, settechBtnEnable] = useState(false)
  const [EnableAddDatabtn, setEnableAddDatabtn] = useState(true)

  useEffect(() => {
    showAllProject(state.employeeId._id)

    // showTaskDescriptionDrop()
    // tableforPlanning(state.employeeId)
  }, [state?.employeeId])

  const [schedulebtn, setSchedulebtn] = useState(false)
  const [scheduleResponse, setScheduleResponse] = useState([])

  const showTable = (Description, DescriptionId) => {
    console.log(Description, 'SHOW TABLE')
    setScheduleResponse([])
    // const FunctionTirData = projectDrop.map((x) => {
    //   return {
    //     data: x.label,
    //   }
    // })

    // const month = moment([year, monthIndex - 1])
    // const weekNumbers = getWeekNumbers(year, monthIndex - 1)
    // const weekList = weeks(month)
    // console.log('weekNumbers', weekNumbers)
    // console.log('weekList', weekList)
    // weekList.forEach((date) => {
    //   console.log(
    //     'start - ' + date.startDate.format('YYYY-MM-DD'),
    //     '\nend - ' + date.endDate.format('YYYY-MM-DD'),
    //   )
    // })
    console.log(variableNamesId, 'SDOKSDSDKSDP', getValue(variableNamesId, TYPES.ARRAY, []))
    const functionalAttr =
      getValue(variableNamesId, TYPES.ARRAY, []).length > 0
        ? getValue(variableNamesId, TYPES.ARRAY, []).length === 1
          ? getValue(variableNamesId, TYPES.ARRAY, [])[0].label
          : getValue(variableNamesId, TYPES.ARRAY, []).reduce((previous, next, index) => {
              console.log('REDUCE', previous, next, index)
              if (index == 1) {
                return `${previous.label} - ${next.label}`
              } else {
                return `${previous} - ${next.label}`
              }
            })
        : ''
    const technicalAttr =
      getValue(variableNamesIdTech, TYPES.ARRAY, []).length > 0
        ? getValue(variableNamesIdTech, TYPES.ARRAY, []).length === 1
          ? getValue(variableNamesIdTech, TYPES.ARRAY, [])[0].label
          : getValue(variableNamesIdTech, TYPES.ARRAY, []).reduce((previous, next, index) => {
              if (index == 1) {
                return `${previous.label} - ${next.label}`
              } else {
                return `${previous} - ${next.label}`
              }
            })
        : ''

    console.log(
      getValue(variableNamesIdTech, TYPES.ARRAY, []),
      technicalAttr,
      'ASOJSAJSA',
      variableNamesIdTech,
    )
    // alert(techBtnEnable)
    if (techBtnEnable === true) {
      // alert('enable')
      const totalData =
        lastTechAtt &&
        lastTechAtt.map((x, index) => {
          const FunctionTirData = tiersDropdown.map((x) => {
            return {
              tierId: x.tierId,
            }
          })
          const FunctionVariable =
            variableNamesId &&
            variableNamesId.map((x) => {
              return {
                variableId: x.value,
              }
            })

          const TechTirData =
            tiersDropdownTech &&
            tiersDropdownTech.map((x) => {
              return {
                tierId: x.tierIdTech,
              }
            })
          const TechVariable =
            variableNamesIdTech &&
            variableNamesIdTech.map((x) => {
              return {
                variableId: x.value,
              }
            })

          var dDesc = document.createElement('div')
          dDesc.innerHTML = Description

          return {
            S_no: myData.length + 1,
            ActionName: dDesc.innerText,
            AssignBy: `${state.firstName} ${state.lastName}`,
            allProject: projectId.label,
            functionAttributes: `${functionalAttr}`,
            technicalAttributes: `${technicalAttr === '' ? '' : `${technicalAttr}`} - ${x?.label}`,

            DummyId: myData.length + 1,
            employeeId: state.employeeId._id,
            delay: 0,
            projectId: projectId.value,
            taskDescription: Description,
            descriptionId: DescriptionId,
            functionalAttributeId: attributeId.value,
            functionalTierDetails: FunctionTirData,
            functionalVariableDetails: FunctionVariable,
            singleTechVariableId: x.value,
            technicalAttributeId: attributeIdTech.value,
            technicalTierDetails: TechTirData,
            technicalVariableDetails: [...TechVariable, { variableId: x.value }],
            isTechnical: 'true',
          }
        })

      setMydata([...myData, ...totalData])
      // setDescriptionId(null)
      setLastTechAtt([])
      console.log('DDD', totalData)
      console.log('DDD', [...myData, ...totalData])
    } else {
      // alert('disable')
      const FunctionTirData = tiersDropdown.map((x) => {
        return {
          tierId: x.tierId,
        }
      })
      const FunctionVariable =
        variableNamesId &&
        variableNamesId.map((x) => {
          return {
            variableId: x.value,
          }
        })

      var dDesc = document.createElement('div')
      dDesc.innerHTML = Description

      const totalData = [
        {
          S_no: myData.length + 1,
          ActionName: dDesc.innerText,
          AssignBy: `${state.firstName} ${state.lastName}`,
          allProject: projectId.label,
          functionAttributes: `${functionalAttr}`,
          technicalAttributes: ' - ',

          DummyId: myData.length + 1,
          employeeId: state.employeeId._id,
          delay: 0,
          projectId: projectId.value,
          taskDescription: Description,
          descriptionId: DescriptionId,
          functionalAttributeId: attributeId.value,
          functionalTierDetails: FunctionTirData,
          functionalVariableDetails: FunctionVariable,
          singleTechVariableId: '',
          technicalAttributeId: '',
          technicalTierDetails: [],
          technicalVariableDetails: [],
          isTechnical: 'false',
        },
      ]

      console.log('DDD', myData)
      console.log('DDD', totalData)
      setMydata([...myData, ...totalData])
      // setDescriptionId(null)
      setLastTechAtt([])
      console.log('DDD', totalData)
      console.log('DDD', [...myData, ...totalData])
    }
    setEnableAddDatabtn(true)
  }

  const ref = React.createRef()

  const ScheduleHandler = (data, duration, startDate, endDate) => {
    console.log(data, duration, startDate, endDate, 'JSOJSDOJ')
    const isAlreadyAvailable = scheduleResponse.find((x) => x.DummyId == data.DummyId)
    const filteredData = scheduleResponse.filter((x) => x.DummyId !== data.DummyId)

    if (isAlreadyAvailable) {
      setScheduleResponse([
        ...filteredData,
        {
          ...isAlreadyAvailable,
          duration: duration,
          delay: 0,
          esd: startDate,
          efd: endDate,
        },
      ])
    } else {
      setScheduleResponse([
        ...filteredData,
        {
          ...data,
          duration: duration,
          delay: 0,
          esd: startDate,
          efd: endDate,
        },
      ])
    }
  }

  const options = {
    orientation: 'landscape',
    unit: 'in',
    // format: [12, 0],
  }

  // Clear Button
  const handleCancel = () => {
    setProjectId('')
    setattributeId('')
    setAttributeIdTech('')
    setTaskDescription('')
    setTiersName([])
    setVariableNamesId([])
    setTiersNameTech([])
    setVariableNamesIdTech([])
    setDescriptionId([])
    setLastTechAtt([])
    // setMydata([])
    setTaskDescdropselect(false)
    settechBtnEnable(false)
  }

  const handleOverallCancel = () => {
    // setProjectId('')
    // setattributeId('')
    // setAttributeIdTech('')
    // setTaskDescription('')
    // setTiersName([])
    // setVariableNamesId([])
    // setTiersNameTech([])
    // setVariableNamesIdTech([])
    // setDescriptionId([])
    // setLastTechAtt([])
    setTableShow(false)
    setMydata([])
    setEnableAddDatabtn(true)
    // setTaskDescdropselect(false)
    // settechBtnEnable(false)
  }

  function openModal() {
    setIsOpen(true)
  }

  function closeModal() {
    setIsOpen(false)
  }

  // Show All project by on employee dropdown API
  const showAllProject = async (employeeId) => {
    var response
    try {
      response = await TaskDescriptionAllProject(employeeId)
      // axios
      //   .get(`${URL}/project/mapping/employee/getall/${state.employeeId}`, {
      //     headers: {
      //       'Content-Type': 'application/json',
      //       Authorization: token,
      //     },
      //   })

      if (response) {
        console.log('S', response)
        const data = response.data.projects.map((x) => {
          return {
            value: x._id,
            label: x.projectName,
            projectId: x._id,
          }
        })
        setProjectDrop(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  //   SelectEmployeeByProject

  const showEmployeebyTeamproject = async (projectId) => {
    var response
    try {
      response = await SelectEmployeeByProject(projectId)
      if (response) {
        if (response.success) {
          console.log(response, 'IIIIIIIIIIIIIIIII')
          //   if (response.attributes) {
          //     const data = response.attributes.map((x, i) => {
          //       return {
          //         value: x._id,
          //         label: x.attributeName,
          //         tiers: x.tiers,
          //         tiersValue: x.tiers.value,
          //       }
          //     })
          //     setProjectAttrName(data)
          //     // console.log(data, 'aaaa')
          //   }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  // Functional Attribute dropdown API
  const showFunctionalAttribute = async (id) => {
    setProjectAttrName([])
    // const token = await localStorage.getItem('USERTOKEN')
    // axios
    //   .get(`${URL}/attributes/${id}`, {
    //     headers: {
    //       'Content-Type': 'application/json',
    //       Authorization: token,
    //     },
    //   })
    var response
    try {
      response = await TaskDescriptionFunctionattr(id)
      if (response) {
        if (response.success) {
          if (response.attributes) {
            const data = response.attributes.map((x, i) => {
              return {
                value: x._id,
                label: x.attributeName,
                tiers: x.tiers,
                tiersValue: x.tiers.value,
              }
            })
            setProjectAttrName(data)
            // console.log(data, 'aaaa')
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }
  // Function Varibale 1st dropdown
  const FunctiongetFirstDropdown = async (projectId, attributeId, tierId) => {
    const token = await localStorage.getItem('USERTOKEN')
    setVariableNamesId([])
    setVariableNames([])
    setTiersDropdown([])
    try {
      await axios({
        method: 'Get',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
        url: `${URL}/variable/firstparent/${projectId}/${attributeId}/${tierId}`,
      }).then((response) => {
        if (response) {
          console.log(response, 'dfirst')
          if (response.data.success) {
            // toast.success(response?.data.message)
            const data = response.data.variables.map((x) => {
              return {
                value: x._id,
                label: x.variableName,
              }
            })
            const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
            setTiersDropdown([
              ...filtrDatas,
              {
                tierId: tierId,
                dropdown: data,
              },
            ])
          } else {
            toast.error(response?.data.error)
          }
        }
      })
    } catch (e) {
      console.log(e)
    }
  }
  // Function Varibale 2nd dropdown
  const FunctionParentDropdown = async (
    projectId,
    attributeId,
    tierId,
    parentTierId,
    parentVariableId,
  ) => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      await axios({
        method: 'Get',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
        url: `${URL}/variable/parent/${projectId}/${attributeId}/${tierId}/${parentTierId}/${parentVariableId}`,
      }).then((response) => {
        if (response) {
          if (response.data.success) {
            // toast.success(response?.data.message)
            const data = response.data.variables.map((x) => {
              return {
                value: x._id,
                label: x.variableName,
              }
            })
            const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
            setTiersDropdown([
              ...filtrDatas,
              {
                tierId: tierId,
                dropdown: data,
              },
            ])
          } else {
            toast.error(response?.data.error)
          }
        }
      })
    } catch (e) {
      console.log(e)
    }
  }

  const showTechnicalAttribute = async () => {
    setProjectAttrNameTech([])
    const token = await localStorage.getItem('USERTOKEN')
    axios
      .get(`${URL}/attribute/technical/getAll`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
      })
      .then((response) => {
        if (response) {
          if (response.data.success) {
            if (response.data.data) {
              const data = response.data.data.map((x, i) => {
                return {
                  value: x._id,
                  label: x.attributeName,
                  tiers: x.tiers,
                  tiersValue: x.tiers.value,
                  techattributeId: x._id,
                }
              })
              setProjectAttrNameTech(data)
              // console.log(data, 'aaaa')
            }
            // toast.success(response.message)
          } else {
            toast.error(response.error)
          }
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }

  const TechnicalFirstDropdown = async (attributeIdTech, tierIdTech) => {
    const token = localStorage.getItem('USERTOKEN')
    setVariableNamesIdTech([])
    setVariableNamesTech([])
    setTiersDropdownTech([])
    await axios({
      method: 'Get',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
      url: `${URL}/variables/technical/firstparent/${attributeIdTech}/${tierIdTech}`,
    }).then((response) => {
      if (response) {
        console.log(response, 'dfirst')
        if (response.data.success) {
          // toast.success(response?.data.message)

          if (response.data.variables) {
            const data = response.data.variables.map((x, i) => {
              return {
                value: x._id,
                label: x?.variableName,
              }
            })
            const filtrDatasTech = tiersDropdownTech.filter((x) => x.tierIdTech !== tierIdTech)
            setTiersDropdownTech([
              ...filtrDatasTech,
              {
                tierIdTech: tierIdTech,
                dropdown: data,
              },
            ])
          }
        } else {
          toast.error(response?.data.error)
        }
      }
    })
  }

  const TechnicalgetParentDropdown = async (
    attributeIdTech,
    tierIdTech,
    parentTierId,
    parentVariableId,
  ) => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      await axios({
        method: 'Get',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,
        },
        url: `${URL}/variable/technical/byparent/${attributeIdTech}/${tierIdTech}/${parentTierId}/${parentVariableId}`,
      }).then((response) => {
        if (response) {
          if (response.data.success) {
            // toast.success(response?.data.message)
            const data = response.data.variables.map((x) => {
              return {
                value: x._id,
                label: x.variableName,
              }
            })
            const filtrDatasTech = tiersDropdownTech.filter((x) => x.tierIdTech !== tierIdTech)
            setTiersDropdownTech([
              ...filtrDatasTech,
              {
                tierIdTech: tierIdTech,
                dropdown: data,
              },
            ])
          } else {
            toast.error(response?.data.error)
          }
        }
      })
    } catch (e) {
      console.log(e)
    }
  }

  const showTaskDescriptionDrop = async (employeeId, projectId, Technical_Variable) => {
    const FunctionTirData = tiersDropdown.map((x) => {
      return {
        tierId: x.tierId,
      }
    })
    // const TechTirData = tiersDropdownTech.map((x) => {
    //   return {
    //     tierId: x.tierIdTech,
    //   }
    // })

    const FunctionVariable = variableNamesId.map((x) => {
      return {
        variableId: x.value,
      }
    })

    // const TechVariable = variableNamesIdTech.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })
    const data = {
      functionalAttributeId: attributeId.value,
      // technicalAttributeId: attributeIdTech.value,
      functionalTierDetails: FunctionTirData,
      functionalVariableDetails: [...FunctionVariable, ...Technical_Variable],
      // technicalTierDetails: TechTirData,
      // technicalVariableDetails: [...TechVariable, ...Technical_Variable],
    }
    const response = await descriptiondashboard(data, employeeId, projectId)
    if (response) {
      if (response.success) {
        console.log(response, 'jaiko')
        const data = response.data.map((x) => {
          var d = document.createElement('div')
          d.innerHTML = x?.taskDescription

          return {
            value: x._id,
            label: d.innerText,
            HTMLValue: x?.taskDescription,
          }
        })
        setDescription(data)
      } else {
        toast.error(response.error)
      }
    }
  }
  const columns = [
    {
      key: 'S_no',
      label:'S.No',
      _style: { width: '5%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'allProject',
      label: 'Project',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'functionAttributes',
      label: 'Functional Attributes',
      _style: { width: '15%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'technicalAttributes',
      label: 'Technical Attributes',
      _style: { width: '15%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'ActionName',
      label: 'Task Description',
      _style: { width: '12%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'Duration',
      label: 'Days',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },

    {
      key: 'ESD',
      label: 'Est Start Date',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'EED',
      label: 'Est End Date',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'AssignBy',
      label: 'Assigned by',
      _style: { width: '10%' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
  ]

  const savePlanning = async (e) => {
    console.log(scheduleResponse, 'SSOSAOJSA')
    const token = await localStorage.getItem(USERTOKEN)

    // const FunctionTirData = tiersDropdown.map((x) => {
    //   return {
    //     tierId: x.tierId,
    //   }
    // })
    // const FunctionVariable = variableNamesId.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })

    // const TechTirData = tiersDropdownTech.map((x) => {
    //   return {
    //     tierId: x.tierIdTech,
    //   }
    // })
    // const TechVariable = variableNamesIdTech.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })

    // const data =  {
    //         employeeId: state.employeeId,
    //         projectId: projectId.value,

    //         functionalAttributeId: attributeId.value,

    //         functionalTierDetails: FunctionTirData,
    //         functionalVariableDetails: variableNamesId,

    //         technicalAttributeId: attributeIdTech.value,

    //         technicalTierDetails: TechTirData,
    //         technicalVariableDetails: variableNamesIdTech,

    //         taskDescription: taskDescription,

    //         duration,
    //         delay: 0,
    //         esd,
    //         efd,
    //       },

    await axios
      .post(
        `${URL}/employee/planning/task/create`,
        {
          data: scheduleResponse,
        },
        // {
        //   data: scheduleResponse.map((x) => ({
        //     ...x,
        //     S_no: undefined,
        //   })),
        // },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        },
      )
      .then((res) => {
        const response = res.data
        console.log(response, 'AAA')
        if (response && response.success === true) {
          toast.success(response.message)
          setProjectId('')
          setattributeId('')
          setAttributeIdTech('')
          setTaskDescription('')
          setTiersName([])
          setVariableNamesId([])
          setTiersNameTech([])
          setVariableNamesIdTech([])
          setMydata([])
          handleCancel()
          setTableShow(false)
        } else {
          toast.error(response.error)
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }

  const onChangeCheckbox = async (e) => {
    settechBtnEnable(e)
    if (e === true) {
      setEnableAddDatabtn(true)
    } else {
      setAttributeIdTech('')
      setTiersNameTech([])
      setVariableNamesIdTech([])
      setTiersDropdownTech([])
      setEnableAddDatabtn(false)
    }
  }

  return (
    <div>
      <div>
        <CForm>
          <CRow>
            <CCol xs={12}>
              <CCard className="mb-6">
                <div className="panel-heading">
                  <div className="col-xs-6">
                    <h3 className="font_Title">TEAM PLANNING AND SCHEDULING </h3>
                  </div>
                </div>
                <CCardBody>
                  <CForm>
                    <CRow className="mb-3">
                      <CRow className="col-sm-3">
                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                          Select Project <code>*</code>
                        </CFormLabel>
                        <CCol sm={12}>
                          <Select
                            className={'inputfieldso'}
                            options={projectDrop}
                            value={projectId}
                            onChange={(e) => {
                              setProjectId(e)
                              setTableShow(false)
                              showFunctionalAttribute(e.value)
                              showEmployeebyTeamproject(e.value)
                              setEnableAddDatabtn(true)
                              setattributeId('')
                              setAttributeIdTech('')
                              setTaskDescription('')
                              setTiersName([])
                              setVariableNamesId([])
                              setTiersNameTech([])
                              setVariableNamesIdTech([])
                            }}
                            placeholder="Select Project"
                          />
                          <span
                            style={{
                              fontWeight: '500',
                              fontSize: '12px',
                              color: 'red',
                            }}
                          >
                            {projectError}
                          </span>
                        </CCol>
                      </CRow>
                      <CRow className="col-sm-3">
                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                          Select Functional Attribute <code>*</code>
                        </CFormLabel>
                        <CCol sm={12}>
                          <Select
                            options={projectAttrName}
                            className="inputfieldso"
                            value={attributeId}
                            // isDisabled={!projectId}
                            onChange={(e) => {
                              setattributeId(e)
                              setEnableAddDatabtn(true)
                              setTiersName(
                                e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers,
                              )
                              if (
                                (e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers)
                                  .length > 0
                              ) {
                                FunctiongetFirstDropdown(projectId.value, e.value, e.tiers[0]._id)
                              }
                            }}
                            placeholder="Select Attribute"
                          />
                        </CCol>
                      </CRow>
                    </CRow>

                    <CRow className="mb-3">
                      {tiersName.map((x, i) => (
                        <CRow className="col-sm-3" key={i}>
                          <CFormLabel
                            className="col-sm-12 col-form-label donlabel text-align-left"
                            key={i}
                          >
                            {x.value} <code>*</code>
                          </CFormLabel>
                          <CCol sm={12}>
                            <CForm>
                              <Select
                                placeholder={`Select ${x.value}`}
                                options={
                                  tiersDropdown.find((tier) => tier.tierId === x._id)?.dropdown
                                    ? tiersDropdown.find((tier) => tier.tierId === x._id)?.dropdown
                                    : []
                                }
                                value={
                                  variableNamesId.filter((varName) => varName.index === i)?.length >
                                  0
                                    ? variableNamesId.find((varName) => varName.index === i)
                                    : null
                                }
                                className="inputfieldso "
                                onChange={(e) => {
                                  const filterData = variableNamesId.filter(
                                    (n) => n.index !== i && !(n.index > i),
                                  )
                                  setVariableNamesId([
                                    ...filterData,
                                    {
                                      ...e,
                                      index: i,
                                      tierId: x._id,
                                      variableId: e.value,
                                    },
                                  ])
                                  if (tiersName.length === i + 1) {
                                    showTechnicalAttribute(e.value)

                                    showTaskDescriptionDrop(
                                      state.employeeId._id,
                                      projectId.value,
                                      [
                                        {
                                          variableId: e.value,
                                        },
                                      ],
                                      // TechVariable,
                                    )
                                    setTaskDescdropselect(true)
                                    setEnableAddDatabtn(true)
                                    setDescriptionId('')
                                  } else {
                                    FunctionParentDropdown(
                                      projectId.value,
                                      attributeId.value,
                                      tiersName[i + 1]._id,
                                      x._id,
                                      e.value,
                                    )
                                    setTaskDescdropselect(false)
                                    setEnableAddDatabtn(true)
                                    setDescriptionId('')
                                  }
                                }}
                              />
                            </CForm>
                          </CCol>
                        </CRow>
                      ))}
                    </CRow>

                    {TaskDescdropselect && (
                      <>
                        <CRow className="mb-3">
                          <CRow className="col-sm-11">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Task Description <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <Select
                                className={'inputfieldso'}
                                // options={description.filter((tdsc) => {
                                //   if (
                                //     myData.filter((ms) => ms.descriptionId === tdsc.value).length >
                                //     0
                                //   ) {
                                //   } else {
                                //     return tdsc
                                //   }
                                // })}
                                options={description}
                                value={descriptionId}
                                onChange={(e) => {
                                  setDescriptionId(e)
                                  setAttributeIdTech('')
                                  setTiersNameTech([])
                                  setVariableNamesIdTech([])
                                  setTiersDropdownTech([])
                                  settechBtnEnable(false)
                                  setEnableAddDatabtn(false)
                                  // setTableShow(true)
                                  // showTable(e.label)
                                  // tableforPlanning(state.employeeId)
                                }}
                                placeholder="Select Description"
                              />
                            </CCol>
                          </CRow>
                        </CRow>

                        <CRow className="mb-3">
                          <CRow className="col-sm-12">
                            <CCol sm={12}>
                              Do you need technical attributes ? &nbsp;&nbsp;
                              <input
                                type="checkbox"
                                className="inputfieldgo"
                                disabled={!descriptionId}
                                checked={techBtnEnable}
                                onChange={(e) => {
                                  // alert(e.target.checked)
                                  onChangeCheckbox(e.target.checked)
                                  // settechBtnEnable(e.target.checked)
                                }}
                                // placeholder="Department Code"
                                // required
                              />
                            </CCol>
                          </CRow>
                        </CRow>

                        {techBtnEnable && (
                          <>
                            <CRow className="mb-3">
                              <CRow className="col-sm-3">
                                <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                                  Select Technical Attribute <code>*</code>
                                </CFormLabel>
                                <CCol sm={12}>
                                  <Select
                                    options={projectAttrNameTech}
                                    className="inputfieldso"
                                    value={attributeIdTech}
                                    isDisabled={!projectId || !attributeId || attributeIdTech}
                                    onChange={(e) => {
                                      setAttributeIdTech(e)
                                      setTiersNameTech([])
                                      setVariableNamesIdTech([])

                                      setTiersNameTech(
                                        e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers,
                                      )
                                      if (
                                        (e?.tiers === undefined || e?.tiers === null
                                          ? []
                                          : e?.tiers
                                        ).length > 0
                                      ) {
                                        TechnicalFirstDropdown(e.value, e.tiers[0]._id)
                                      }
                                    }}
                                    placeholder="Select Attribute"
                                  />
                                </CCol>
                              </CRow>
                            </CRow>

                            <CRow className="mb-3">
                              {tiersNameTech &&
                                tiersNameTech.map((x, i) => (
                                  <CRow className="col-sm-3" key={i}>
                                    <CFormLabel
                                      className="col-sm-12 col-form-label donlabel text-align-left"
                                      key={i}
                                    >
                                      {x.value} <code>*</code>
                                    </CFormLabel>
                                    {/* Tiers DropDown Starts */}
                                    <CCol sm={12}>
                                      <CForm>
                                        {i == tiersNameTech.length - 1 ? (
                                          <>
                                            <Select
                                              placeholder={`Select ${x.value}`}
                                              className={'inputfieldso'}
                                              value={lastTechAtt.length > 0 ? lastTechAtt[0] : null}
                                              options={(tiersDropdownTech.find(
                                                (tier) => tier.tierIdTech === x._id,
                                              )?.dropdown
                                                ? tiersDropdownTech.find(
                                                    (tier) => tier.tierIdTech === x._id,
                                                  )?.dropdown
                                                : []
                                              ).filter(
                                                (x) =>
                                                  myData.filter(
                                                    (data) =>
                                                      data.singleTechVariableId === x.value &&
                                                      data.descriptionId === descriptionId.value,
                                                  ).length === 0,
                                              )}
                                              displayValue="key"
                                              onChange={(e) => {
                                                console.log('MULTI', e)
                                                setLastTechAtt([e])
                                                setEnableAddDatabtn(false)
                                                // const TechVariable = e.map((x) => {
                                                //   return {
                                                //     variableId: x.value,
                                                //   }
                                                // })
                                                // showTaskDescriptionDrop(
                                                //   state.employeeId._id,
                                                //   projectId.value,
                                                //   [
                                                //     {
                                                //       variableId: e.value,
                                                //     },
                                                //   ],
                                                //   // TechVariable,
                                                // )
                                                // setDescriptionId('')
                                                // const filterData = variableNamesIdTech.filter(
                                                //   (n) => n.index !== i,
                                                // )
                                                // setVariableNamesIdTech([
                                                //   ...filterData,
                                                //   {
                                                //     ...e,
                                                //     index: i,
                                                //     tierIdTech: x._id,
                                                //     variableId: e.value,
                                                //   },
                                                // ])
                                                // if (tiersNameTech.length === i + 1) {
                                                // } else {
                                                //   TechnicalgetParentDropdown(
                                                //     attributeIdTech.value,
                                                //     tiersNameTech[i + 1]._id,
                                                //     x._id,
                                                //     e.value,
                                                //   )
                                                // }
                                              }}
                                            />
                                          </>
                                        ) : (
                                          <Select
                                            placeholder={`Select ${x.value}`}
                                            options={
                                              tiersDropdownTech.find(
                                                (tier) => tier.tierIdTech === x._id,
                                              )?.dropdown
                                                ? tiersDropdownTech.find(
                                                    (tier) => tier.tierIdTech === x._id,
                                                  )?.dropdown
                                                : []
                                            }
                                            value={
                                              variableNamesIdTech.filter(
                                                (varName) => varName.index === i,
                                              )?.length > 0
                                                ? variableNamesIdTech.find(
                                                    (varName) => varName.index === i,
                                                  )
                                                : null
                                            }
                                            className="inputfieldso"
                                            onChange={(e) => {
                                              const filterData = variableNamesIdTech.filter(
                                                (n) => n.index !== i && !(n.index > i),
                                              )
                                              setLastTechAtt([])
                                              setEnableAddDatabtn(true)
                                              setVariableNamesIdTech([
                                                ...filterData,
                                                {
                                                  ...e,
                                                  index: i,
                                                  tierIdTech: x._id,
                                                  variableId: e.value,
                                                },
                                              ])
                                              if (tiersNameTech.length === i + 1) {
                                              } else {
                                                TechnicalgetParentDropdown(
                                                  attributeIdTech.value,
                                                  tiersNameTech[i + 1]._id,
                                                  x._id,
                                                  e.value,
                                                )
                                              }
                                            }}
                                          />
                                        )}
                                      </CForm>
                                    </CCol>
                                  </CRow>
                                ))}
                            </CRow>
                          </>
                        )}
                      </>
                    )}

                    <CRow>
                      <CCol className="d-flex flex-row justify-content-end">
                        <button
                          disabled={EnableAddDatabtn}
                          className="loginBtn1 mright"
                          onClick={(e) => {
                            e.preventDefault()
                            setTableShow(true)
                            showTable(descriptionId.HTMLValue, descriptionId.value)
                          }}
                        >
                          Add
                        </button>
                        <button
                          className="reset"
                          onClick={(e) => {
                            e.preventDefault()
                            handleCancel()
                          }}
                        >
                          Clear
                        </button>
                      </CCol>
                    </CRow>
                  </CForm>
                </CCardBody>
                {tableShow && (
                  <div className="TabelOver">
                    <br />
                    <div className="ItemsPerPageMappage">
                      <span className="pageid">No of Rows</span> &nbsp;
                      <TableDropdown
                        onChange={(value) => {
                          setItemsPerPage(value)
                        }}
                      />
                    </div>
                    {/* <div className="TableDownloadmapPage">
                      <button onClick={openModal} className="pdfbtns">
                        <ImFilePdf /> PDF
                      </button>
                    </div> */}
                    <br /> <br />
                    <CSmartTable
                      activePage={1}
                      clickableRows
                      columns={columns}
                      columnFilter
                      columnSorter
                      items={myData}
                      pagination
                      scopedColumns={{
                        Duration: (item) => {
                          return (
                            <td>
                              <CFormInput
                                type="number"
                                placeholder="Days"
                                className="inputfieldgo"
                                value={
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                  0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                        .duration
                                    : ''
                                }
                                onChange={(e) => {
                                  ScheduleHandler(
                                    item,
                                    e.target.value,
                                    '',
                                    '',
                                    // scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                    //   .length > 0
                                    //   ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                    //   : '',
                                    // scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                    //   .length > 0
                                    //   ? scheduleResponse.find((x) => x.DummyId == item.DummyId).efd
                                    //   : '',
                                  )
                                }}
                              />
                            </td>
                          )
                        },
                        ESD: (item) => {
                          return (
                            <td>
                              <CFormInput
                                type="Date"
                                min={moment().format('YYYY-MM-DD')}
                                // max="9999-01-01"
                                className="inputfieldgo"
                                value={
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                  0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                    : ''
                                }
                                onChange={(e) => {
                                  // setEsd(e.target.value).utc().toISOString()
                                  // .toISOString()
                                  // const date = e.target.value
                                  // now.toUTCsString()

                                  ScheduleHandler(
                                    item,
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                          .duration
                                      : '',
                                    e.target.value,
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                          ?.duration
                                        ? moment(moment(e.target.value).format('YYYY-MM-DD'))
                                            .add(
                                              Number(
                                                scheduleResponse.find(
                                                  (x) => x.DummyId == item.DummyId,
                                                )?.duration,
                                              ) - 1,
                                              'days',
                                            )
                                            .format('YYYY-MM-DD')
                                        : ''
                                      : '',
                                  )
                                  setSchedulebtn(true)
                                }}
                              />
                            </td>
                          )
                        },
                        EED: (item) => {
                          return (
                            <td>
                              <CFormInput
                                type="Date"
                                min={moment().format('YYYY-MM-DD')}
                                // max="9999-01-01"
                                className="inputfieldgo date"
                                value={
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                  0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId).efd
                                    : ''
                                }
                                onChange={(e) => {
                                  // setEfd(e.target.value)
                                  ScheduleHandler(
                                    item,
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                          .duration
                                      : '',
                                    scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                      .length > 0
                                      ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                      : '',
                                    e.target.value,
                                  )
                                }}
                                disabled={!efd}
                              />
                            </td>
                          )
                        },
                      }}
                      sorterValue={{ column: 'name', state: 'asc' }}
                      // tableFilter
                      // tableHeadProps={{
                      //   color: 'danger',
                      // }}
                      tableProps={{
                        striped: true,
                        hover: true,
                      }}
                    />
                    <br />
                    <div className="d-flex flex-row justify-content-end">
                      {schedulebtn && (
                        <div>
                          <button
                            className="loginBtn1 mright"
                            type="submit"
                            onClick={(e) => {
                              e.preventDefault()
                              savePlanning(e)
                            }}
                          >
                            Schedule
                          </button>
                        </div>
                      )}

                      <div>
                        <button
                          style={{ marginRight: '15px' }}
                          className="reset"
                          onClick={(e) => {
                            e.preventDefault()
                            handleOverallCancel()
                            setTableShow(false)
                          }}
                        >
                          clear
                        </button>
                      </div>
                    </div>
                    <br />
                  </div>
                )}
              </CCard>
            </CCol>
          </CRow>
        </CForm>
      </div>
    </div>
  )
}
