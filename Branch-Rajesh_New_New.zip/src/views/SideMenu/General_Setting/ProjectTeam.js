import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import {
  CButton,
  CContainer,
  CModal,
  CModalBody,
  CModalFooter,
  CModalHeader,
  CModalTitle,
} from '@coreui/react-pro'
import Select from 'react-select'
import { toast } from 'react-toastify'
import axios from 'axios'
import { USERTOKEN } from 'src/constants/localstorage'
import { GlobalContext } from 'src/context'
import plus from 'src/assets/images/add-button.png'
import { URL } from 'src/services/URL'
import { CSmartTable } from '@coreui/react-pro'
import TableDropdown from 'src/views/forms/TableDropdown/TableDropdown'
import { BsPencil } from 'react-icons/bs'
import { RiDeleteBin6Line,RiDeleteBinFill } from 'react-icons/ri'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { ImFilePdf, ImCloudDownload, ImDownload2, ImDownload3, ImPrinter } from 'react-icons/im'
import { ProjectTeamTable } from './ProjectTeamTable'
import {
  projectdropdown,getProjectforTaskDescribe,UpdateProjectTeamAPI,getalldepartment,getalluser,TeamSaveAPI,showAllEmployeeWithoutProjectAPI
} from 'src/services/ApiServices'

// eslint-disable-next-line react/prop-types
export const ProjectTeam = () => {
  const [role, setRole] = useState([])
  const [roleName, setRoleName] = useState('')
  
  const { state, dispatch } = useContext(GlobalContext)
  const [addScreen, setAddScreen] = useState(true)
  const [update, setupdate] = useState(false)
  const [tierValue, setTierValue] = useState(false)
  const [save, setSave] = useState(false)
  const [attributeName, setAttributeName] = useState('')
  const [tier, setTier] = useState([])
  const [tiers, setTiers] = useState('')

  const [projectDrop, setProjectDrop] = useState([])
  const [projectId, setProjectId] = useState('')
  
  const [projectDropProject, setProjectDropProject] = useState([])
  const [projectIdt, setProjectIdt] = useState('')

  const[tableData,setTableData] = useState('')
  const [table, setTable] = useState(false)

  const [tablead, setTablead] = useState(false)
  const [showReport, setShowReport] = useState(false)
  
  const [projectName, setProjectName] = useState('')

  const [companyId, setCompanyId] = useState('')
  const [employeName, setEmployeName] = useState([])
  const [employeeId, setEmployeeId] = useState('')
  const [employeeIdReport, setEmployeeIdReport] = useState('')
  const [checkbox, setCheckbox] = useState(false)
  const [departmentName, setDepartmentName] = useState([])
  const [RepdepartmentName, setRepdepartmentName] = useState([])
  const [companyName, setcompanyName] = useState([])
  const [departmentId, setDepartmentId] = useState('')
  const [departmentIdReport, setDepartmentIdReport] = useState('')
  const [companyIdReport, setcompanyIdReport] = useState('')
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [myData, setMyData] = useState([])
  const [visible, setVisible] = useState(false)

  const [reportingToStatus, setReportingToStatus] = useState(false)
  const [reportingToDepartment, setReportingToDepartment] = useState('')
  const [reportingTo, setReportingTo] = useState('')
  const [tableValue, setTableValue] = useState('')
  const [AddreportingTo, setAddreportingTo] = useState(false)
  const [TeamAdminExists, setTeamAdminExists] = useState(false)
  const [alreadyTeamData, setalreadyTeamData] = useState([])

  const [tableDeleteId, setTableDeleteId] = useState('')
  const [teamIdData, setTeamIdData] = useState('')


  useEffect(() => {
   
    showAllProject()
  }, [])


  const ClearAllFun=()=>{
    setTablead(false)
    setMyData([])
    // setProjectId('')
    // setShowReport(false);
    // setRoleName('');
  }
  
  const onShowEmployeeData = () => {
    // e.preventDefault()

    setMyData([
      ...myData,
      {
        S_no: myData.length + 1,
        companyId: state.companyId,

        projectName: projectId.label,
        projectId: projectId.value,

        Department: departmentId?.label == undefined ? '' : departmentId?.label,
        departmentId: departmentId.value,

        Employee: employeeId.label,
        employeeId: employeeId.employeeId,

        
        ReportingEmployee: roleName?.label == undefined ? '-' : roleName?.label,
        reportingTo: roleName.value,

        reportingToStatus,

        reportingToDepartment: departmentIdReport.value,
        ReportingDepartment:
          departmentIdReport?.label == undefined ? '-' : departmentIdReport?.label,
      
        userId:employeeId.value,
        
        teamId: teamIdData,
        // reportingTo:employeeId.value
     },
    ])

    setTablead(true)
    setDepartmentId('')
    setEmployeeId('')
    setDepartmentIdReport('')
    setEmployeeIdReport('')
    setcompanyIdReport('')
    setCheckbox(false)
    setReportingToStatus(false)

    // const data = myData.map((x, i) => {
    //   return {
    //     S_no: i + 1,
    //     value: x._id,
    //   }
    // })
    // setTableValue(data)
    // console.log('QQQ', data)
    // console.log('AAAA', myData)
  }
  const removeElement = (index) => {
    const value = myData.filter((i) => i.S_no !== index);
  
    setMyData(value.map((x, index) => ({ ...x, S_no: index + 1 })));
  
    // Show a toast message when an element is removed
    toast.success('Team member removed successfully');
  };

  const columns = [
    {
      key: 'S_no',
      label:'S.No',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'projectName',
      label: 'project Name',
      _style: { width: '12%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'Department',
      label: 'Department',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'Employee',
      label: 'Employee Name',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'ReportingDepartment',
      label: 'Reporting To Department',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'ReportingEmployee',
      label: 'Reporting to Employee',
      _style: { width: '20%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: false,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '10%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]
  
  const updateDepartment = (data) => {

    console.log(data, 'datadatadatadatadatadata')
    setTeamIdData(data.teamId)
    setTable(false)
    setAddScreen(!addScreen)
    setupdate(true) 

    showProject()
    showDepartment()
    showAllEmployeeWithoutProject(projectId,departmentId)

    setProjectId({
      value: data.projectId,
      label: data.projectName,
    })

    setDepartmentId({
      value: data.departmentId,
      label: data.departmentName,
    })

    setEmployeeId({
      value: data.employeeId,
      label: data.employeeName,
    })

    setDepartmentIdReport({
      value: data.reportingToDepartmentId,
      label: data.reportingToDepartment === "-" ? "Select" : data.reportingToDepartment,
    })

    setRoleName({
      value: data.reportingToId,
      label: data.reportingTo === "-" ? "Select " : data.reportingTo,
    })
    // setCheck(true)
    // setCheck(true)
    if( data.reportingToStatus === null){
      setReportingToStatus(false)
      setShowReport(false) 
      setCheckbox(false) 
    }
    else{
      setReportingToStatus(true)
      setShowReport(true) 
      setCheckbox(true) 
    }

    // setReportingToStatus( data.reportingToStatus === null ? 
    //   : setShowReport(true) && setCheckbox(true) )
  
    }

  const showProject = async () => {

    setProjectDrop([])
    // var response
    try {
      const response = await projectdropdown(state.companyId)
      
      console.log(response, 'lpopop')
      if (response) {
        if (response) {
          if (response) {
            const data = response.data.map((x) => {
              return {
                value: x._id,
                label: x.projectName,
              }
            })
            setProjectDrop(data)
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const showAllProject = async () => {
    setProjectDropProject([])
    setProjectIdt('')
    setTable(false)
    var response
    try {
      response = await getProjectforTaskDescribe(state.companyId, state.userId)
      if (response) {
        console.log('S', response)
        const data = response.data.map((x) => {
          return {
            value: x.projectId._id,
            label: x.projectId.projectName,
            projectId: x.projectId._id,
          }
        })
        setProjectDropProject(data)
      }
      toast.error(response.error)
    } catch (e) {
      console.log(e)
      toast.error(response.error)
    }
  }

  const AlreadyProjectAllocatedData = async (projectId) => {
    const token = await localStorage.getItem('USERTOKEN')
    try {
      axios
        .get(`${URL}/teams/getAll/${projectId}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        })
        .then((response) => {
          if (response) {
            setalreadyTeamData(response.data)
          } else {
            setalreadyTeamData([])
          }
        })
        .catch((e) => {
          setalreadyTeamData({ data: [] })
        })
    } catch (e) {
      console.log(e)
      setalreadyTeamData([])
    }
  }

  const EnableReportingFunc = async (checkbox) => {
    // alert(checkbox)
    if (checkbox === true) {
      // setTeamAdminExists(false)
      setEmployeeIdReport('')
      setDepartmentIdReport('')
      setcompanyIdReport('')
      if (
        alreadyTeamData.data.length > 1 &&
        alreadyTeamData.data.filter((item) => item.reportingTo === null).length > 0
      ) {
        
        setAddreportingTo(false)
        setTeamAdminExists(true)
      } else if (
        myData.length > 0 &&
        myData.filter((item) => item.reportingToId === undefined, projectId === projectId.value)
          .length > 0
      ) {
        setAddreportingTo(false)
        setTeamAdminExists(true)
        // alert('new false')
      } else {
        
        setAddreportingTo(false)
        setTeamAdminExists(false)
      }
    } else {
      setTeamAdminExists(true)
    }
  }

  const showAllCompanies = async () => {
    // alert()
    const token = await localStorage.getItem('USERTOKEN')
    try {
      axios
        .get(`${URL}/companies`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        })
        .then((response) => {
          if (response) {
            if (response.data.success) {
              if (response.data.companies) {
                const value = response.data.companies.map((x, i) => {
                  return {
                    value: x._id,
                    label: x.companyName,
                  }
                })
                // console.log(value, 'PPPPPPPPPPPPPPPPPPPPPPPPPP')
                setcompanyName(value)
              }
            } else {
              setcompanyName([])
            }
          } else {
            setcompanyName([])
          }
        })
    } catch (e) {
      console.log(e)
    }
  }

  const showDepartment = async () => {
    var response
    setDepartmentName([])
    try {
      response = await getalldepartment()
      if (response) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: x?.departmentName,
          }
        })
        setDepartmentName(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const showReportingDepartment = async () => {
    var response
    setRepdepartmentName([])
    try {
      response = await getalldepartment()
      if (response) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: x.departmentName,
          }
        })
        setRepdepartmentName(data)
      }
    } catch (e) {
      console.log(e)
    }
  }
  
  const showAllEmployeeWithoutProject = async (projectId,departmentId) => {
    var response
    setEmployeName([])
    try {
      response = await showAllEmployeeWithoutProjectAPI(projectId,departmentId)
      console.log("dfgge",response)
      if (response) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: `${x.firstName} ${x.lastName}`,
            employeeId:x.employeeId,
          

          }
        })
        setEmployeName(data)
      }
    } catch (e) {
      console.log(e)
      toast.error(response.error)
    }
  }
  
  const showEmployeebaseDepartment = async (projectId,departmentId) => {
    var response
    setEmployeName([])
    try {
      response = await showAllEmployeeWithoutProjectAPI(projectId,departmentId)
      console.log("dfgge",response)
      if (response) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: `${x.firstName} ${x.lastName}`,
            employeeId:x.employeeId,
          

          }
        })
        setEmployeName(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  
  const ReportingToEmployee = async () => {
    var response
    setRole([])
    try {
      response = await getalluser(state.companyId)

      if (response) {
        if (response.success) {
          if (response.data) {
            
            const data = response.data.map((x, i) => {
              return {
                // S_no: i + 1,
                // Name: `${x.firstName} ${x.lastName}`,
                // Email: x.email,
                //role: x.roleId.roleName,
                // role: `${x.roleId?.roleName ? x.roleId?.roleName : "-"}`,
                // isActive: x.active,
                // Status: x?.active ?? 'true' ? 'Active' : 'InActive',
                userId: x._id,
                // DummyId: x.value,
                // userName: x.username,
                label: `${x.firstName} ${x.lastName}`,
                value:x._id,
              }
            })
            setRole(data)
            
          }
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const UpdateProjectTeam = async () => {
    const body = {data:myData}
    const projectId = myData[0].projectId; 
    const teamId = teamIdData;
    // console.log("teamIdDatateamIdData",teamIdData)
    try {
      const response = await UpdateProjectTeamAPI(body,state.companyId,projectId,teamId)
      if (response && response.success === true) {
        toast.success(response.message)
        // setCompanyId('')
        // setProjectId('')
        // setDepartmentId('')
        // setEmployeeId('')
        // setReportingToStatus('')
        // setReportingToDepartment('')
        // setReportingTo('')
        // setAddScreen(!addScreen)
        // setTable(false)
        // setProjectIdt('')
        setTablead(false)
        
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }
  const saveProjectTeam = async () => {
    // const  data = myData
    const body = {data:myData}

    const projectId=myData[0].projectId
    const departmentId = myData[0].departmentId
    console.log("mydatajsdfsdf",body,projectId,departmentId);
    try {
      const response = await TeamSaveAPI(body,state.companyId,projectId,departmentId)
      if (response && response.success === true) {
        toast.success(response.message)
        setCompanyId('')
        setProjectId('')
        setDepartmentId('')
        setEmployeeId('')
        setReportingToStatus('')
        setReportingToDepartment('')
        setReportingTo('')
        setAddScreen(!addScreen)
        setTable(false)
        setProjectIdt('')
        showAllProject()
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }


  const saveProjectTeamold = async () => {
    const token = await localStorage.getItem(USERTOKEN)
    await axios
      .post(
        `${URL}/teams/create`,
        {
          data: myData,
        },
        // data: [
        //   {
        //     companyId: state.companyId,
        //     projectId: myData[0].projectId.value,
        //     departmentId: myData[0].departmentId.value,
        //     employeeId: myData[0].employeeId.value,
        //     reportingToStatus,
        //     reportingToDepartmentId: myData[0].departmentIdReport.value,
        //     reportingToId: myData[0].employeeIdReport.value,
        //   },
        // ],
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        },
      )
      .then((res) => {
        const response = res.data
        console.log('SAVE', response)
        if (response && response.success === true) {
          toast.success(response.message)
          setCompanyId('')
          setProjectId('')
          setDepartmentId('')
          setEmployeeId('')
          setReportingToStatus('')
          setReportingToDepartment('')
          setReportingTo('')
          setAddScreen(!addScreen)
          setTable(false)
          setProjectIdt('')
          // setNewData(!newData)
        } else {
          toast.error(response.error)
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success === false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }

  return (
    <div>
      {addScreen ? (
        <div>
          <div className="d-flex align-items-center justify-content-between">
            <div className="font_Title pt-2 pb-0">Project Team Member List </div>
            <div>
              <button
                className="loginBtn mright loginBtn_New"
                onClick={() => {
                  setAddScreen(!addScreen)
                  setTiers('')
                  setTier([])
                  setTierValue(false)
                  setSave(false)
                  setProjectId('')
                  // setCheck(false)
                  setAttributeName('')
                  showProject()
                }}
              >
                Add New
              </button>
            </div>
          </div>
          <CRow>
            <CCol xs={12}>
              <CCard className="mb-6">
                {/* <div className="panel-heading">
                  <div className="col-xs-6">
                    <h3 className="font_Title">Project Team Member List</h3>
                  </div>
                </div> */}
                <CCardBody>
                  {/* <button
                    className="loginBtn mright"
                    onClick={() => {
                      setAddScreen(!addScreen)
                      setTiers('')
                      setTier([])
                      setTierValue(false)
                      setSave(false)
                      setProjectId('')
                      setAttributeName('')
                    }}
                  >
                    ADD
                  </button> */}
                  
                  <CRow className="mb-3">
                    <CRow className="col-sm-3">
                      <CFormLabel className="col-sm-12 donlabel text-align-left">
                        Select Project <code >*</code>
                      </CFormLabel>
                      <CCol sm={12}>
                        <Select
                          className={'inputfieldso'}
                          options={projectDropProject}
                          value={projectIdt}
                          onChange={(e) => {
                            setProjectIdt(e)
                            setTable(true)
                          }}
                          placeholder="Name of a Project"
                        />
                      </CCol>
                    </CRow>
                  </CRow>
                  
                  
                </CCardBody>
              </CCard>
             
              {table && <ProjectTeamTable 

              updateDepartment={updateDepartment}
              projectId={projectIdt.value} 
              showAllProject={showAllProject}
              
              />}
                
            </CCol>
          </CRow>
        </div>
      ) : (
        <div>
          <CForm>
            <CRow>
              <CCol xs={12}>
                 {/* <div className="panel-heading">
                    <div className="col-xs-6">
                      <h3 className="font_Title">Project Team Creation</h3>
                    </div>
                  </div> */}
                  <span className="employeeHeader">
                    {update ? (
                      <h3 className="font_Title">Update Project Team Creation </h3>
                    ) : (
                      <h3 className="font_Title">Project Team Creation</h3>
                    )}
               </span>
                <CCard className="mb-6">
                  
                  <CCardBody>
                    <CForm>
                    <CRow className="mb-3"> 
                        <CRow className="col-sm-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Select Project<code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                            <Select
                              className={'inputfieldso'}
                              // isClearable
                              options={projectDrop}
                              isDisabled={projectId}
                              value={projectId}
                              onChange={(e) => {
                                showDepartment(e.value)
                                setProjectId(e)
                                AlreadyProjectAllocatedData(e.value)
                              }}
                              placeholder="Name of a Project"
                            />
                            </CCol>
                            
                            
                        </CRow>
                        <CRow className="col-sm-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Select Department <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                            <Select
                              options={departmentName}
                              isClearable
                              className="inputfieldso"
                              isDisabled={!projectId}
                              value={departmentId}
                              onChange={(e) => {
                                // Make sure projectId exists before using it
                                if (projectId) {
                                  // Get the selected departmentId from 'e'
                                  let selectedDepartmentId = e ? e.value : null;
                                  // Call the function with the correct parameters
                                  showAllEmployeeWithoutProject(projectId.value, selectedDepartmentId);
                                  // Set the state variables
                                  setDepartmentId(e);
                                  setEmployeeId('');
                                  setEmployeeIdReport('');
                                  setDepartmentIdReport('');
                                  setcompanyIdReport('');
                                  setRoleName('');
                                }
                              }}
                              placeholder="Name of the Department"
                            />
                            </CCol>
                            
                            
                        </CRow>
                        <CRow className="col-sm-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Select Employee <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              {/* {JSON.stringify(employeeId)} */}
                                    <Select
                                    options={employeName.filter((x) => {
                                      if (
                                        myData.filter((y) => y.employeeId === x.employeeId).length > 0
                                      ) {
                                      } else {
                                        return x
                                      }
                                    })}
                                    isDisabled={!projectId || !departmentId}
                                    isClearable
                                    className={'inputfieldso'}
                                    value={employeeId}
                                    onChange={(e) => {
                                      setEmployeeId(e)
                                      setEmployeeIdReport('')
                                      setDepartmentIdReport('')
                                      setcompanyIdReport('')
                                      showAllCompanies()
                                      
                                    }}
                                    placeholder="Name of the Employee"
                                  />
                            </CCol>
                            
                            
                        </CRow>
                    </CRow>
                    <CRow className="mb-3">
                        
                        <CFormLabel className="col-sm-2 col-form-label donlabelLeft">
                          Reporting To
                          {/* {JSON.stringify(checkbox)} */}
                        </CFormLabel>
                        <CCol sm={6}>
                          <input
                            className="inputcheckNew"
                            type="checkbox"
                            checked={checkbox}
                            disabled={!projectId || !departmentId || !employeeId || AddreportingTo}
                            value={reportingToStatus}                            
                            onChange={() => {
                              // if(checkbox){
                              //   setShowReport(true);
                                
                              // }
                              // else{
                              //   setShowReport(false);
                              // }
                              // alert(checkbox)
                              setReportingToStatus(!checkbox)
                              setCheckbox(!checkbox)
                              // showDepartment()
                              setShowReport(true);
                              // EnableReportingFunc(checkbox)
                              showReportingDepartment()
                            }}
                          />
                        </CCol>
                      </CRow>
                    {showReport && (
                    <CRow className="mb-3"> 
                        {/* <CRow className="col-sm-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Reporting To Company <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                                <Select
                                options={companyName}
                                isDisabled={!checkbox}
                                className="inputfieldso nodrope"
                                value={companyIdReport}
                                onChange={(e) => {
                                  setcompanyIdReport(e)
                                  showReportingDepartment(e.value)
                                }}
                              />
                            </CCol>
                            
                            
                        </CRow> */}
                        <CRow className="col-sm-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Reporting To Department <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                                    <Select
                                    options={RepdepartmentName}
                                    //   isDisabled={
                                    //     employeeId == null
                                    //       ? false
                                    //       : employeeId?.hasReportingto
                                    //       ? !employeeId?.hasReportingto
                                    //       : true
                                    //   }
                                    isDisabled={!checkbox}
                                    className="inputfieldso nodrope"
                                    value={departmentIdReport}
                                    onChange={(e) => {
                                      showEmployeebaseDepartment(e.value)
                                      setDepartmentIdReport(e)
                                      setEmployeeIdReport('')
                                      ReportingToEmployee()
                                    }}
                                  />
                            </CCol>
                            
                            
                        </CRow>
                        <CRow className="col-sm-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                            Reporting To Employee <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              
                              {/* {JSON.stringify(roleName)} */}

                                  <Select
                                  
                                  options={role.filter((x) => x.userId !== employeeId?.value)}
                                  
                                  
                                  className={'inputfieldso nodrope'}
                                  isDisabled={!checkbox}
                                  // options={role}

                                  value={roleName}
                                  onChange={(e) => {
                                    setRoleName(e);
                                    // setEmployeeIdReport(e)
                                    setTeamAdminExists(false)
                                  }}
                                  placeholder="Select Employee"
                                />
                            </CCol>
                            
                            
                        </CRow>
                    </CRow>
                     )}
                    

                      <div className="d-flex flex-row justify-content-end">
                        {!TeamAdminExists ? (
                          <div>
                            <button
                              className="loginBtn1 mright"
                              onClick={(e) => {
                                e.preventDefault()
                                onShowEmployeeData()
                                setRoleName('');
                              }}
                              type="submit"
                              disabled={!projectId || !departmentId || !employeeId}
                            >
                              Add
                            </button>
                          </div>
                        ) : (
                          <div>
                            <button
                              className="loginBtn1 mright"
                              onClick={(e) => {
                                e.preventDefault()
                                onShowEmployeeData()
                              }}
                              type="submit"
                              disabled={
                                !projectId ||
                                !departmentId ||
                                !employeeId ||
                                !departmentIdReport ||
                                !employeeIdReport
                              }
                            >
                              Add 
                            </button>
                          </div>
                        )}
                        <div>
                          <button
                            className="clear"
                            onClick={(e) => {
                              e.preventDefault()
                              setProjectId('')
                              setDepartmentId('')
                              setEmployeeId('')
                              setEmployeeIdReport('')
                              setcompanyIdReport('')
                              setDepartmentIdReport('')
                              setCheckbox('')
                              setShowReport(false)
                              setRoleName('')
                              setupdate(false) 
                              //setTablead(false)
                            }}
                          >
                            Clear
                          </button>
                          <button
                            style={{ margin: '0px 10px' }}
                            className="reset"
                            onClick={() => {
                              setAddScreen(!addScreen)
                              setMyData([])
                              setTablead(false)
                              setShowReport(false);
                              setRoleName('');
                              setupdate(false) 
                            }}
                          >
                            cancel
                          </button>
                        </div>
                      </div>
                    </CForm>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
          </CForm>
        </div>
      )}
      {tablead && (
        // Start
        <div>
          <CCard className="mb-6">
            {/* <div className="ItemsPerPage">
              <span className="pageid">No of Rows</span> &nbsp;
              <TableDropdown
                onChange={(value) => {
                  setItemsPerPage(value)
                }}
              />
            </div> */}
            {/* <div className="TableDownload">
              <button className="pdfbtns">
                <ImFilePdf /> PDF
              </button>
              <span className="tooltiptext">Download</span>
            </div> */}
            
            
          </CCard>
          <br />
          <span className="employeeHeader ">
              <h3 className="font_Title">Add New Team Members</h3>
            </span>
            
            <CSmartTable
              activePage={1}
              // cleaner
              clickableRows
              columns={columns}
              columnFilter
              columnSorter
              // itemsPerPageSelect
              items={myData}
              itemsPerPageSelect
              itemsPerPageLabel={'No of Rows'}
              itemsPerPage={5}
              pagination
              scopedColumns={{
                status: (item) => (
                  <td>{/* <CBadge color={getBadge(item.status)}>{item.status}</CBadge> */}</td>
                ),
                show_details: (item) => {
                  return (
                    <td className="py-2 gaponly">
                      {/* {console.log(item, 'SD')} */}
                      {/* <CButton
                        className="updateBtn"
                        onClick={() => {
                          // updateBusType(item)
                        }}
                      >
                        <BsPencil style={{ fontSize: '16px', color: '#fff', display: 'inline' }} />
                      </CButton> */}
                      <button
                        className="deleteBtn"
                        onClick={() => {
                          setVisible(!visible)
                          setTableDeleteId(item.S_no)
                          setTableData(item.Employee)
                        }}
                      >
                        <RiDeleteBinFill
                                  style={{ fontSize: '22px', color: '#ea4335' }}
                                />
                      </button>
                     
                    </td>
                  )
                },
              }}
              sorterValue={{ column: 'name', state: 'asc' }}
              tableProps={{
                striped: true,
                hover: true,
                responsive: true,
              }}
            />
            <div
              className="d-flex flex-row justify-content-end mt-3"
              style={{ marginRight: '1rem' }}
            >{update ? (
              <>
              
                  <div>
                    <button
                      className="loginBtn mright"
                      type="submit"
                      onClick={(e) => {
                        e.preventDefault()
                        // UpdateProjectTeam(departmentId.value)
                        UpdateProjectTeam()
                      }}
                    >
                      Update
                    </button>
                  </div>
                  <div>
                  <button
                    className="reset"
                    onClick={() => {
                      setAddScreen(!addScreen)
                      setMyData([])
                      setTablead(false)
                      setShowReport(false);
                      setRoleName('');
                      setupdate(false) 
                    }}
                  >
                    cancel
                  </button>
                </div>
             </>
                ) : (
              <>
                  <div>
                    <button
                      className="save mright"
                      type="submit"
                      onClick={() => {
                        {
                          saveProjectTeam()
                          setTablead(false)
                          setAddScreen(!addScreen)
                          setMyData([])
                        }
                      }}
                    >
                      save
                    </button>
                  </div>
                  <div>
                    <button
                      className="clear mright"
                      type="submit"
                      onClick={() => {                    
                          ClearAllFun()
                        }}
                    >
                      Clear
                    </button>
                  </div>
                  <div>
                    <button
                      className="reset"
                      onClick={() => {
                        setAddScreen(!addScreen)
                        setMyData([])
                        setTablead(false)
                        setShowReport(false);
                        setRoleName('');
                      }}
                    >
                      cancel
                    </button>
                  </div>
              </>
              )}
            </div>
            <>
                        <CModal
                          size="sm"
                          alignment="center"
                          visible={visible}
                          onClose={() => setVisible(false)}
                        >
                          <CModalHeader>
                            <div
                              className="times"
                              onClick={() => {
                                setVisible(false)
                              }}
                            >
                              &times;
                            </div>
                            <CModalTitle>
                              <span>
                                <CIcon icon={cilTask} className="me-2" />
                              </span>
                              Confirm
                            </CModalTitle>
                          </CModalHeader>
                          <CModalBody className="">
                            <span> Are you sure do you want to delete the <br />
                            Employee Name : <b>{tableData} </b> </span>
                          </CModalBody>
                          <CModalFooter>
                            <button className="modelBtnNo" onClick={() => setVisible(false)}>
                              No
                            </button>
                            <div>
                              {/* {myData.map((index) => ( */}
                              <div>
                                <button
                                  className="modelBtnYes"
                                  onClick={() => {
                                    removeElement(tableDeleteId)
                                    setVisible(false)
                                  }}
                                >
                                  Yes
                                </button>
                              </div>
                              {/* ))} */}
                              <div>
                                {/* <button
                                  className="modelBtnYes"
                                  onClick={() => {
                                    setMyData([])
                                    setVisible(false)
                                  }}
                                >
                                  Yes
                                </button> */}
                              </div>
                            </div>
                          </CModalFooter>
                        </CModal>
                      </>
                      <br />
        </div>
      )}
    </div>
  )
}