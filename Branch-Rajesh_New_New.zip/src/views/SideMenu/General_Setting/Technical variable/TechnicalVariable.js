import React, { useEffect, useState, useContext } from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import Select from 'react-select'
import { CSmartTable } from '@coreui/react-pro'
import { toast } from 'react-toastify'
import axios from 'axios'
import { GlobalContext } from 'src/context'
import { BsPencil } from 'react-icons/bs'
import { FaEdit } from 'react-icons/fa'
import { RiDeleteBin6Line, RiDeleteBinFill } from 'react-icons/ri'
import {
  addtechVariableForTiers,
  GETALLTECHVARIABLE,
  updatetechnicalVariableForTiers,
  TechnicalVariableDelete,
  technicalattributeGet,
  technicalvariablefirstParentGet,
  technicalvariabletechnicalParentGet,
} from 'src/services/ApiServices'
import { CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter } from '@coreui/react-pro'
import { cilTask } from '@coreui/icons'
import CIcon from '@coreui/icons-react'

export const TechnicalVariable = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [addScreen, setAddScreen] = useState(false)
  const [tableShow, settableShow] = useState(false)
  const [projectAttrName, setProjectAttrName] = useState([])
  const [projectAttrNameTab, setProjectAttrNameTab] = useState([])
  const [attributeId, setattributeId] = useState('')
  const [attributeIdTab, setattributeIdTab] = useState('')
  const [variableName, setVariableName] = useState('')
  const [variable, setVariable] = useState([])
  const [tiersName, setTiersName] = useState([])
  const [update, setUpdate] = useState({ update: false, _id: undefined })
  const [input, setInput] = useState({ display: false, index: undefined })
  const [variableNames, setVariableNames] = useState([])
  const [variableNamesId, setVariableNamesId] = useState([])
  const [visible, setVisible] = useState(false)
  const [tiersDropdown, setTiersDropdown] = useState([])
  const [tabledelete, setTabledelete] = useState({})
  const [tableData1,setTableData1] = useState('')
  useEffect(() => {
    // showAttributeTab()
    showAttribute()
  }, [])

  const [country, setCountry] = useState([])
  const initialTableStructure = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'tiers',
      _style: { width: '35%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'variableName',
      _style: { width: '35%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'show_details',
      label: 'Action',
      _style: { width: '10%', background: '#002663' },
      filter: false,
      sorter: false,
      _props: { color: '#fff', className: 'fw-semibold' },
    },
  ]

  const [tableStructure, setTablestructure] = useState(initialTableStructure)

  const GetMaximumArrayLength = (attribute) => {
    let LargestTierLength = []
    for (let i = 0; i < attribute.length; i++) {
      if (attribute[i].tierId.length > LargestTierLength.length) {
        LargestTierLength = attribute[i].tierId
      }
    }
    return LargestTierLength.length
  }

  const ReStructureTableWithTiers = (length) => {
    let NewStructure = []
    for (let i = 0; i < length; i++) {
      NewStructure.push({
        key: `Tier_${i + 1}`,
        label: `Tier ${i + 1}`,
        _style: { width: '10%' },
        filter: true,
        sorter: true,
        _props: { color: '#fff', className: 'fw-semibold' },
      })
    }
    setTablestructure([...initialTableStructure, ...NewStructure])
  }

  const showCountry = async (attributeId) => {
    var response
    try {
      response = await GETALLTECHVARIABLE(attributeId)
      console.log(response, 'sadaa')
      if (response) {
        if (response.success) {
          if (response) {
            const length = GetMaximumArrayLength(response.data)
            ReStructureTableWithTiers(length)
            const data = response.data.map((x, i) => {
              let tiersResponseStructure = {}

              for (let loop_for_Tiers = 0; loop_for_Tiers < length; loop_for_Tiers++) {
                tiersResponseStructure[`Tier_${loop_for_Tiers + 1}_id`] =
                  x.tierId[loop_for_Tiers]?._id ?? ''
                tiersResponseStructure[`Tier_${loop_for_Tiers + 1}`] =
                  x.tierId[loop_for_Tiers]?.title ?? '-'
              }
              console.log(
                {
                  S_no: i + 1,
                  variableName: x.variableName,
                },
                'FOKDODKODKKDFKD',
              )
              return {
                S_no: i + 1,
                variableName: x?.variableName,
                tiers: x?.tierId?.value,
                companyId: x.companyId,
                attributeId: x._id,
                data: x,
                ...tiersResponseStructure,
              }
            })
            setCountry(data)
          }
        } else {
          setCountry([])
          // toast.error(response.error)
        }
      }
    } catch (e) {
      console.log(e)
    }
  }

  const [table, setTable] = useState(false)
  const [tableData, setTableData] = useState({})
  const initialColumn = {
    key: 'S_no',
    label: 'S.No',
    _style: { width: '5%', background: '#002663' },
    _props: { color: '#fff', className: 'fw-semibold' },
    filter: false,
    sorter: false,
  }
  const [columns, setColumns] = useState([initialColumn])

  const VariableUpdate = (data) => {
    setUpdate({
      update: true,
      _id: data.value,
    })
    setVariableName(data.tiername)
    setInput({
      display: true,
      index: data.indexID,
    })
  }

  const showAttribute = async () => {
    try {
      const response = await technicalattributeGet()
      if (response) {
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x, i) => {
              return {
                value: x._id,
                label: x.attributeName,
                tiers: x.tiers,
                tiersValue: x.tiers.value,
              }
            })
            setProjectAttrName(data)
            setTableData([])
            // console.log(data, 'aaaa')
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }

  const getFirstVariableParentDropdown = async (attributeId, tierId) => {
    setVariableNamesId([])
    setVariableNames([])
    setTiersDropdown([])
    try {
      const response = await technicalvariablefirstParentGet(attributeId, tierId)
      if (response) {
        console.log(response, 'dfirst')
        if (response.success) {
          // toast.success(response?.data.message)

          if (response.variables) {
            const data = response.variables.map((x, i) => {
              return {
                value: x._id,
                label: x?.variableName,
              }
            })
            const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
            setTiersDropdown([
              ...filtrDatas,
              {
                tierId: tierId,
                dropdown: data,
              },
            ])
          }
        } else {
          toast.error(response?.data.error)
        }
      }
    } catch (e) {
      console.log(e)
    }
  }

  const getVariableParentDropdown = async (attributeId, tierId, parentTierId, parentVariableId) => {
    const token = await localStorage.getItem('USERTOKEN')
    const alreadyfiltrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
    setTiersDropdown(alreadyfiltrDatas)
    try {
      const response = await technicalvariabletechnicalParentGet(
        attributeId,
        tierId,
        parentTierId,
        parentVariableId,
      )
      if (response) {
        if (response.success) {
          // toast.success(response?.data.message)
          const data = response.variables.map((x) => {
            return {
              value: x._id,
              label: x.variableName,
            }
          })
          const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
          setTiersDropdown([
            ...filtrDatas,
            {
              tierId: tierId,
              dropdown: data,
            },
          ])
        } else {
          toast.error(response?.data.error)
        }
      }
    } catch (e) {
      console.log(e)
    }
  }

  const saveVariable = async (tierId, index, updateID) => {
    if (!update.update) {
      if (index === 0) {
        const data = {
          attributeId: attributeId.value,
          tierId: tierId,
          variableName: variableName,
        }

        const response = await addtechVariableForTiers(data)
        if (response) {
          if (response?.success) {
            setInput({ display: false })
            setVariableName('')
            toast.success(response?.message)
            getFirstVariableParentDropdown(attributeId.value, tierId)
          }
        }
      } else {
        const getParent = variableNamesId.find((x) => x.index == index - 1)
        const data = {
          attributeId: attributeId.value,
          tierId: tierId,
          variableName: variableName,
          parentTierId: getParent.tierId,
          parentVariableId: getParent.variableId,
        }
        const response = await addtechVariableForTiers(data)
        if (response) {
          if (response?.success) {
            setInput({ display: false })
            setVariableName('')
            toast.success(response?.message)
            getVariableParentDropdown(
              attributeId.value,
              tierId,
              getParent.tierId,
              getParent.variableId,
            )
          }
        }
      }
    } else {
      
      console.log(tierId, variableName, 'UPDTAEBKNDSKLM')
      if (index === 0) {
        const data = {
          variableName: variableName,
        }

        const response = await updatetechnicalVariableForTiers(data, updateID)
        if (response) {
          if (response?.success) {
            setInput({ display: false })
            setVariableName('')
            // toast.success(response?.message)
            setUpdate({ update: false })
            setTable(false)
            setVariableNamesId(variableNamesId.filter((filData) => filData.index !== index))
            getFirstVariableParentDropdown(attributeId.value, tierId)
          } else {
            toast.error(response?.error)
          }
        }
      } else {
        const getParent = variableNamesId.find((x) => x.index == index - 1)
        const data = {
          variableName: variableName,
        }
        const response = await updatetechnicalVariableForTiers(data, updateID)
        if (response) {
          if (response?.success) {
            setInput({ display: false })
            setVariableName('')
            // toast.success(response?.message)
            setUpdate({ update: false })
            setTable(false)
            getVariableParentDropdown(
              attributeId.value,
              tierId,
              getParent.tierId,
              getParent.variableId,
            )
            setVariableNamesId(variableNamesId.filter((filData) => filData.index !== index))
          } else {
            toast.error(response?.error)
          }
        }
      }
    }
    // setVariableName(obj)
  }

  const deleteTechnicalVariable = async () => {
    try {
      const response = await TechnicalVariableDelete(tabledelete.variableId, tabledelete.tierId);
      if (response.success) {
        toast.success(response.message);
  
        // Call a function to remove the deleted variable from the dropdown options
        deleteVariableFromDropdown(tabledelete.variableId, tabledelete.tierId);
  
        // Other actions...
  
      } else {
        toast.error(response.error);
      }
    } catch (err) {
      console.error(err);
    }
  }

  const deleteVariableFromDropdown = (variableId, tierId) => {
    // Assuming tiersDropdown is a state variable
    setTiersDropdown((prevTiersDropdown) => {
      // Filter out the deleted variable based on variableId and tierId
      const updatedDropdown = prevTiersDropdown.map((tier) => {
        if (tier.tierId === tierId) {
          // Filter out the variable with the specified variableId
          tier.dropdown = tier.dropdown.filter((variable) => variable.value !== variableId);
        }
        return tier;
      });
  
      return updatedDropdown;
    });
  };
  

  return (
    <div>
      {
        !addScreen ? (
          <div>
            <CForm>
              <CRow>
                <CCol xs={12}>
                  <div className="panel-heading">
                    <div className="col-xs-6">
                      {update.update ? (
                        <h3 className="font_Title">Update Technical Variable </h3>
                      ) : (
                        <h3 className="font_Title">Create Technical Variable</h3>
                      )}
                    </div>
                  </div>
                  <CCard className="mb-6">
                    <CCardBody>
                      <CForm>
                        <CRow className="mb-3">
                          <CRow className="col-sm-3">
                            <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                              Select Tech. Attribute Name <code>*</code>
                            </CFormLabel>
                            <CCol sm={12}>
                              <Select
                                options={projectAttrName}
                                className="inputfieldso"
                                value={attributeId}
                                onChange={(e) => {
                                  setattributeId(e)
                                  setTiersName(
                                    e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers,
                                  )
                                  if (
                                    (e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers)
                                      .length > 0
                                  ) {
                                    getFirstVariableParentDropdown(e.value, e.tiers[0]._id)
                                  }
                                }}
                                placeholder="Name of a Attribute"
                              />
                            </CCol>
                          </CRow>
                        </CRow>
                        {tiersName.map((x, i) => (
                          <div key={i}>
                            <CRow className="mb-3">
                              <CCol sm={2}></CCol>
                              <CFormLabel className="col-sm-2 donlabel" key={i}>
                                {x.value}
                              </CFormLabel>
                              {input.display && input?.index !== undefined && input?.index === i ? (
                                <CCol sm={4}>
                                  <CForm>
                                    <CFormInput
                                      type="text"
                                      className="inputfieldgo"
                                      placeholder="Variable Name"
                                      onChange={(e) => setVariableName(e.target.value)}
                                      value={variableName}
                                    />
                                  </CForm>
                                </CCol>
                              ) : (
                                // Tiers DropDown Starts
                                <CCol sm={4}>
                                  <CForm>
                                    <Select
                                      options={
                                        tiersDropdown.find((tier) => tier.tierId === x._id)
                                          ?.dropdown
                                          ? tiersDropdown.find((tier) => tier.tierId === x._id)
                                              ?.dropdown
                                          : []
                                      }
                                      value={
                                        variableNamesId?.filter((varName) => varName.index === i)
                                          ?.length > 0
                                          ? variableNamesId.find((varName) => varName.index === i)
                                          : null
                                      }
                                      className="inputfieldso"
                                      onChange={(e) => {
                                        setTable(true)
                                        setColumns([
                                          initialColumn,
                                          {
                                            key: 'tiername',
                                            label: `${x.value}`,
                                            _style: { width: '18%', background: '#002663' },
                                            _props: { color: '#fff', className: 'fw-semibold' },
                                            filter: true,
                                            sorter: true,
                                          },
                                          {
                                            key: 'show_details',
                                            label: 'Action',
                                            _style: { width: '10%', background: '#002663' },
                                            filter: false,
                                            sorter: false,
                                            _props: { color: '#fff', className: 'fw-semibold' },
                                          },
                                        ])
                                        const indexID = i
                                        setTableData(
                                          tiersDropdown
                                            .find((tier) => tier.tierId === x._id)
                                            ?.dropdown.map((y, i) => {
                                              return {
                                                S_no: i + 1,
                                                tiername: y.label,
                                                tierId: x._id,
                                                indexID: indexID,
                                                ...y,
                                              }
                                            }),
                                        )

                                        const filterData = variableNamesId.filter(
                                          (n) => n.index !== i && !(n.index > i),
                                        )
                                        if (i === 0) {
                                          setVariableNamesId([
                                            {
                                              ...e,
                                              index: i,
                                              tierId: x._id,
                                              variableId: e.value,
                                            },
                                          ])
                                        } else {
                                          setVariableNamesId([
                                            ...filterData,
                                            {
                                              ...e,
                                              index: i,
                                              tierId: x._id,
                                              variableId: e.value,
                                            },
                                          ])
                                        }

                                        if (tiersName.length === i + 1) {
                                        } else {
                                          getVariableParentDropdown(
                                            attributeId.value,
                                            tiersName[i + 1]._id,
                                            x._id,
                                            e.value,
                                          )
                                        }
                                      }}
                                      placeholder="Select Variable Name"
                                    />
                                  </CForm>
                                </CCol>
                                // Tiers DropDown Ends
                              )}
                              {
                                <React.Fragment>
                                  {(input?.index != i || input?.index === undefined) &&
                                  (i === 0
                                    ? true
                                    : variableNamesId.find(
                                        (varName) => varName.index === i - 1,
                                      )) ? (
                                    <CCol sm={4}>
                                      <CButton
                                        className="pdfbtns"
                                        onClick={() => {
                                          setInput({
                                            display: true,
                                            index: i,
                                          })
                                          setUpdate({ update: false })
                                          setVariableName('')
                                        }}
                                      >
                                        Add
                                      </CButton>
                                    </CCol>
                                  ) : (
                                    <React.Fragment>
                                      {input?.index === i && (
                                        <CCol sm={4}>
                                          {!update.update ? (
                                            <button
                                              className="save mright"
                                              onClick={(e) => {
                                                saveVariable(x._id, i);
                                                e.preventDefault()
                                              }}
                                            >
                                              Save
                                            </button>
                                          ) : (
                                            <button
                                              className="save mright"
                                              onClick={(e) => {
                                                saveVariable(x._id, i, update._id)
                                                e.preventDefault()
                                              }}
                                            >
                                              Update
                                            </button>
                                          )}
                                          <button
                                            className="reset"
                                            onClick={() => {
                                              setInput({ display: false, index: undefined })
                                              setUpdate({
                                                update: false,
                                                _id: undefined,
                                              })
                                            }}
                                          >
                                            Cancel
                                          </button>
                                        </CCol>
                                      )}
                                    </React.Fragment>
                                  )}
                                </React.Fragment>
                              }
                            </CRow>
                          </div>
                        ))}
                        <div className="d-flex flex-row justify-content-end">
                          <div>
                            <button
                              className="reset"
                              onClick={() => {
                                setUpdate(false)
                                setattributeId('')
                                setTable(false)
                                setTiersName([])
                                // showAttributeTab()
                                setattributeIdTab('')
                                showAttribute()
                              }}
                            >
                              cancel
                            </button>
                          </div>
                        </div>
                      </CForm>
                    </CCardBody>
                  </CCard>
                  <br />
                  {table && (
                    <div>
                      <CSmartTable
                        activePage={1}
                        clickableRows
                        columns={columns}
                        columnFilter
                        columnSorter
                        items={tableData}
                        scopedColumns={{
                          show_details: (item) => {
                            return (
                              <td>
                                {/* {JSON.stringify(item)}
                                <hr />
                                {JSON.stringify(tiersDropdown)} */}
                                <CButton className="updateBtn" onClick={() => VariableUpdate(item)}>
                                  <FaEdit style={{ fontSize: '20px', color: '#002663' }} />
                                </CButton>

                                <CButton
                                  className="deleteBtn"
                                  onClick={() => {
                                    // console.log(item, 'gsfgfdghsfdagfftfgdhkgdkjgdsfgdshjghjsfjhf')
                                    // setTabledelete({
                                    //   tierId: item.data.tierId._id,
                                    //   variableId: item.data._id,
                                    // })
                                    setTabledelete({
                                      variableId: item.value,
                                      tierId: item.tierId,
                                    })
                                    setTableData1(item.label)
                                    setVisible(!visible)
                                  }}
                                >
                                  <RiDeleteBinFill style={{ fontSize: '22px', color: '#ea4335' }} />
                                </CButton>
                              </td>
                            )
                          },
                        }}
                        sorterValue={{ column: 'name', state: 'asc' }}
                        tableProps={{
                          striped: true,
                          hover: true,
                        }}
                      />
                      <>
                        <CModal
                          size="sm"
                          alignment="center"
                          visible={visible}
                          onClose={() => setVisible(false)}
                        >
                          <CModalHeader>
                            <div
                              className="times"
                              onClick={() => {
                                setVisible(false)
                              }}
                            >
                              &times;
                            </div>
                            <CModalTitle>
                              <span>
                                <CIcon icon={cilTask} className="me-2" />
                              </span>
                              Confirm
                            </CModalTitle>
                          </CModalHeader>
                          <CModalBody className=""><span>
                            Are you sure do you want to delete <br />
                            Variable Name : <b>{tableData1}</b></span>
                          </CModalBody>
                          <CModalFooter>
                            <button className="modelBtnNo" onClick={() => setVisible(false)}>
                              No
                            </button>
                            <button
                              className="modelBtnYes"
                              onClick={() => {
                                // onDelete(tabledelete.tierId, tabledelete.variableId)
                                // deleteTechnicalVariable(tabledelete.variableId, tabledelete.tierId)
                                deleteTechnicalVariable()
                                setVisible(false)
                              }}
                            >
                              Yes
                            </button>
                          </CModalFooter>
                        </CModal>
                      </>
                    </div>
                  )}
                </CCol>
              </CRow>
            </CForm>
          </div>
        ) : null
        // <div>
        //   <div className="d-flex align-items-center justify-content-between">
        //     <div className="font_Title pt-2 pb-0">Technical Variable Master</div>
        //     <div>
        //       <button
        //         className="loginBtn mright loginBtn_New"
        //         onClick={() => {
        //           setAddScreen(!addScreen)
        //           setUpdate(false)
        //         }}
        //       >
        //         Add New
        //       </button>
        //     </div>
        //   </div>
        //   <CRow>
        //     <CCol xs={12}>
        //       <CCard className="mb-6">
        //         {/* <span className="employeeHeader">
        //           <h3 className="font_Title">TECHNICAL Variable Master</h3>
        //         </span> */}
        //         <CCardBody>
        //           {/* <button
        //             className="loginBtn mright"
        //             onClick={() => {
        //               setAddScreen(!addScreen)
        //               setUpdate(false)
        //             }}
        //           >
        //             ADD
        //           </button>
        //           <br /> */}
        //           <CRow className="mb-3 ">
        //             <CRow className="col-sm-3">
        //               <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
        //                 Select Tech. Attribute Name
        //               </CFormLabel>
        //               <CCol sm={12}>
        //                 <Select
        //                   options={projectAttrNameTab}
        //                   className="inputfieldso"
        //                   value={attributeIdTab}
        //                   onChange={(e) => {
        //                     setattributeIdTab(e)
        //                     settableShow(true)
        //                     showCountry(e.value)
        //                   }}
        //                   placeholder="Name of a Attribute"
        //                 />
        //               </CCol>
        //             </CRow>
        //           </CRow>

        //         </CCardBody>
        //       </CCard>
        //       <br />
        //       {tableShow && (
        //             <CSmartTable
        //               activePage={1}
        //               // cleaner
        //               clickableRows
        //               columns={tableStructure}
        //               columnFilter
        //               columnSorter
        //               // footer
        //               items={country}
        //               itemsPerPageSelect
        //               itemsPerPageLabel={'No of Rows'}
        //               itemsPerPage={5}
        //               pagination
        //               sorterValue={{ column: 'name', state: 'asc' }}

        //               scopedColumns={{
        //                 show_details: (item) => {
        //                   return (
        //                     <td className="gaponly">
        //                       <CButton
        //                         className="deleteBtn"
        //                         onClick={() => {
        //                           // console.log(item, 'gsfgfdghsfdagfftfgdhkgdkjgdsfgdshjghjsfjhf')
        //                           setTabledelete({
        //                             tierId: item.data.tierId._id,
        //                             variableId: item.data._id,
        //                           })
        //                           setVisible(!visible)
        //                         }}
        //                       >
        //                          <RiDeleteBinFill
        //                           style={{ fontSize: '22px', color: '#ea4335' }}
        //                         />
        //                       </CButton>
        //                     </td>
        //                   )
        //                 },
        //               }}
        //               tableProps={{
        //                 striped: true,
        //                 hover: true,
        //               }}
        //             />
        //           )}
        //           <>
        //             <CModal
        //               size="sm"
        //               alignment="center"
        //               visible={visible}
        //               onClose={() => setVisible(false)}
        //             >
        //               <CModalHeader>
        //                 <div
        //                   className="times"
        //                   onClick={() => {
        //                     setVisible(false)
        //                   }}
        //                 >
        //                   &times;
        //                 </div>
        //                 <CModalTitle>
        //                   <span>
        //                     <CIcon icon={cilTask} className="me-2" />
        //                   </span>
        //                   Confirm
        //                 </CModalTitle>
        //               </CModalHeader>
        //               <CModalBody className="loginModelBody">
        //                 Are you sure do you want to delete a current row.
        //               </CModalBody>
        //               <CModalFooter>
        //                 <button className="modelBtnNo" onClick={() => setVisible(false)}>
        //                   No
        //                 </button>
        //                 <button
        //                   className="modelBtnYes"
        //                   onClick={() => {
        //                     // onDelete(tabledelete.tierId, tabledelete.variableId)
        //                     deleteTechnicalVariable(tabledelete.variableId, tabledelete.tierId)
        //                     setVisible(false)
        //                   }}
        //                 >
        //                   Yes
        //                 </button>
        //               </CModalFooter>
        //             </CModal>
        //           </>
        //     </CCol>
        //   </CRow>
        // </div>
      }
    </div>
  )
}
