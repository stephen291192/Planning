import React, { useEffect, useState, useContext } from 'react'
import { CCard, CCardBody,CFormTextarea, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import { CSmartTable } from '@coreui/react-pro'
import Select from 'react-select'
import { toast } from 'react-toastify'
import axios from 'axios'
import { GlobalContext } from 'src/context'
import { URL } from 'src/services/URL'
import { ImFilePdf } from 'react-icons/im'
import {
  descriptiondashboard,
  GetActivity,
  getFirstVariableParentDropdownAPI,
  getProjectforTaskDescribe,
  getProjectMaster,
  getVariableParentDropdownAPI,
  planningtableview,
  showFuncAttrAPI,
  TaskDescriptionAllProject,
  TaskDescriptionFunctionattr,
  technicalAttributeBymappedemp,
  TechnicalVariableDropAPI,
  technicalattributePostAPINew,TaskDescriptionSave
} from 'src/services/ApiServices'
import TableDropdown from 'src/views/forms/TableDropdown/TableDropdown'
import { USERTOKEN } from 'src/constants/localstorage'
// import Multiselect from 'multiselect-react-dropdown'
import { BsFillPlusCircleFill } from 'react-icons/bs'
import { MultiSelect } from 'react-multi-select-component'
import { number } from 'prop-types'
import moment from 'moment'
import { getValue, TYPES } from 'src/services/utility'
import momentBusinessDays from 'moment-business-days'

momentBusinessDays.updateLocale('us', {
  workingWeekdays: [1, 2, 3, 4, 5, 6],
})

export const SingleActivityPlanningNew = () => {
  const { state, dispatch } = useContext(GlobalContext)
  const [projectId, setProjectId] = useState('')
  const [descriptionId, setDescriptionId] = useState('')
  const [description, setDescription] = useState([])
  const [descriptiontable, setDescriptionTable] = useState([])
  const [projectDrop, setProjectDrop] = useState([])
  const [projectAttrName, setProjectAttrName] = useState([])
  const [attributeId, setattributeId] = useState('')
  const [tiersName, setTiersName] = useState([])
  const [variableNames, setVariableNames] = useState([])
  const [variableNamesId, setVariableNamesId] = useState([])
  const [tiersDropdown, setTiersDropdown] = useState([])
  
  const [plannedActivityWork, setPlannedActivityWork] = useState([])
  const [plannedActivityWorkId, setPlannedActivityWorkId] = useState('')
  const [projectAttrNameTech, setProjectAttrNameTech] = useState([])
  const [attributeIdTech, setAttributeIdTech] = useState('')
  const [tiersNameTech, setTiersNameTech] = useState([])
  const [variableNamesTech, setVariableNamesTech] = useState([])
  const [variableNamesIdTech, setVariableNamesIdTech] = useState([])
  const [tiersDropdownTech, setTiersDropdownTech] = useState([])
  const [tableShow, setTableShow] = useState(false)
  const [taskDescription, setTaskDescription] = useState('')
  const [taskDescriptionDrop, setTaskDescriptionDrop] = useState([])
  const [modalIsOpen, setIsOpen] = React.useState(false)
  const [itemsPerPage, setItemsPerPage] = useState('20')
  const [projectError, setProjectError] = useState('')
  const [duration, setDuration] = useState('')
  const [esd, setEsd] = useState('')
  const [efd, setEfd] = useState('')
  const [lastTechAtt, setLastTechAtt] = useState([])

  const [myData, setMydata] = useState([])
  const [TaskDescdropselect, setTaskDescdropselect] = React.useState(false)
  const [techBtnEnable, settechBtnEnable] = useState(false)
  const [techBtnEnableActivity, settechBtnEnableActivity] = useState(false)
  
  const [EnableAddDatabtn, setEnableAddDatabtn] = useState(true)
  const [addBtn,setAddBtn] = useState(false)

  useEffect(() => {
    showAllProject(state.companyId, state.userId)
  }, [state?.employeeId])

  const showActivityWork = async () => {
    var response
    setPlannedActivityWork([])
    try {
      response = await GetActivity()
      if (response) {
        const data = response.data.map((x) => {
          return {
            value: x._id,
            label: x?.activityName,
          }
        })
        setPlannedActivityWork(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const [schedulebtn, setSchedulebtn] = useState(false)
  const [scheduleResponse, setScheduleResponse] = useState([])

  const showTable = (Description, DescriptionId) => {
   
    setScheduleResponse([])
    console.log(variableNamesId, 'SDOKSDSDKSDP', getValue(variableNamesId, TYPES.ARRAY, []))
    const functionalAttr =
      getValue(variableNamesId, TYPES.ARRAY, []).length > 0
        ? getValue(variableNamesId, TYPES.ARRAY, []).length === 1
          ? getValue(variableNamesId, TYPES.ARRAY, [])[0].label
          : getValue(variableNamesId, TYPES.ARRAY, []).reduce((previous, next, index) => {
              console.log('REDUCE', previous, next, index)
              if (index == 1) {
                return `${previous.label} - ${next.label}`
              } else {
                return `${previous} - ${next.label}`
              }
            })
        : ''
    const technicalAttr =
      getValue(variableNamesIdTech, TYPES.ARRAY, []).length > 0
        ? getValue(variableNamesIdTech, TYPES.ARRAY, []).length === 1
          ? getValue(variableNamesIdTech, TYPES.ARRAY, [])[0].label
          : getValue(variableNamesIdTech, TYPES.ARRAY, []).reduce((previous, next, index) => {
              if (index == 1) {
                return `${previous.label} - ${next.label}`
              } else {
                return `${previous} - ${next.label}`
              }
            })
        : ''

    console.log(
      getValue(variableNamesIdTech, TYPES.ARRAY, []),
      technicalAttr,
      'ASOJSAJSA',
      variableNamesIdTech,
    )
   
    if (techBtnEnable === true) {
    
      const totalData =
        lastTechAtt &&
        lastTechAtt.map((x, index) => {
          const FunctionTirData = tiersDropdown.map((x) => {
            return {
              tierId: x.tierId,
            }
          })
          const FunctionVariable =
            variableNamesId &&
            variableNamesId.map((x) => {
              return {
                variableId: x.value,
              }
            })

          const TechTirData =
            tiersDropdownTech &&
            tiersDropdownTech.map((x) => {
              return {
                tierId: x.tierIdTech,
              }
            })
          const TechVariable =
            variableNamesIdTech &&
            variableNamesIdTech.map((x) => {
              return {
                variableId: x.value,
              }
            })

          var dDesc = document.createElement('div')
          dDesc.innerHTML = Description

          // console.log(technicalAttr, 'SSSSSSSSSSSSSSSSS')

          return {
            S_no: myData.length + 1,
            ActionName: dDesc.innerText,
            AssignBy: `${state.firstName} ${state.lastName}`,
            allProject: projectId.label,
            functionAttributes: `${functionalAttr}`,
            technicalAttributes: `${technicalAttr === '' ? '' : `${technicalAttr} - `}${x?.label}`,

            DummyId: myData.length + 1,
            employeeId: state.employeeId._id,
            delay: 0,
            projectId: projectId.value,
            // employeeId: state.employeeId,
            companyId: state.companyId,
            activityWorkId: plannedActivityWorkId.value,
            taskDescription: dDesc.innerText,
            taskDescriptionId: DescriptionId,
            functionalAttributeId: attributeId.value,
            functionalTierDetails: FunctionTirData,
            functionalVariableDetails: FunctionVariable,
            singleTechVariableId: x.value,
            technicalAttributeId: attributeIdTech.value,
            technicalTierDetails: TechTirData,
            technicalVariableDetails: [...TechVariable, { variableId: x.value }],
            isTechnical: 'true',
          }
        })

      setMydata([...myData, ...totalData])
     
      setLastTechAtt([])
      console.log('11231', totalData)
      console.log('DDD', [...myData, ...totalData])
    } else {
      
      const FunctionTirData = tiersDropdown.map((x) => {
        return {
          tierId: x.tierId,
        }
      })
      const FunctionVariable =
        variableNamesId &&
        variableNamesId.map((x) => {
          return {
            variableId: x.value,
          }
        })

      var dDesc = document.createElement('div')
      dDesc.innerHTML = Description

      const totalData = [
        {
          S_no: myData.length + 1,
          ActionName: dDesc.innerText,
          AssignBy: `${state.firstName} ${state.lastName}`,
          allProject: projectId.label,
          functionAttributes: `${functionalAttr}`,
          technicalAttributes: ' - ',

          DummyId: myData.length + 1,
          employeeId: state.employeeId._id,
          delay: 0,
          projectId: projectId.value,
          taskDescription: Description,
          descriptionId: DescriptionId,
          functionalAttributeId: attributeId.value,
          functionalTierDetails: FunctionTirData,
          functionalVariableDetails: FunctionVariable,
          singleTechVariableId: '',
          technicalAttributeId: '',
          technicalTierDetails: [],
          technicalVariableDetails: [],
          isTechnical: 'false',
        },
      ]

      console.log('DDD', myData)
      console.log('DDD1231312', totalData)
      setMydata([...myData, ...totalData])
     
      setLastTechAtt([])
      console.log('DDD', totalData)
      console.log('DDD', [...myData, ...totalData])
    }
    setEnableAddDatabtn(true)
  }

  const ref = React.createRef()

  const ScheduleHandler = (data, duration, startDate, endDate) => {
    console.log(data, duration, startDate, endDate, 'JSOJSDOJ')

    const isAlreadyAvailable = scheduleResponse.find((x) => x.DummyId == data.DummyId)
    const filteredData = scheduleResponse.filter((x) => x.DummyId !== data.DummyId)

    if (isAlreadyAvailable) {

      setScheduleResponse([
        ...filteredData,
        {
          ...isAlreadyAvailable,
          duration: duration,
          delay: 0,
          esd: startDate,
          efd: endDate,
        },
      ])

    } else {
      setScheduleResponse([
        ...filteredData,
        {
          ...data,
          duration: duration,
          delay: 0,
          esd: startDate,
          efd: endDate,
        },
      ])
    }
  }

  const options = {
    orientation: 'landscape',
    unit: 'in',
    // format: [12, 0],
  }

  // Clear Button
  const handleCancel = () => {
    setProjectId('')
    setattributeId('')
    setAttributeIdTech('')
    setTaskDescription('')
    setTiersName([])
    setVariableNamesId([])
    setTiersNameTech([])
    setVariableNamesIdTech([])
    setDescriptionId('')
    setLastTechAtt([])
    // setMydata([])
    setTaskDescdropselect(false)
    settechBtnEnable(false)
    setAddBtn(false)
  }

  const handleOverallCancel = () => {
    // setProjectId('')
    // setattributeId('')
    // setAttributeIdTech('')
    // setTaskDescription('')
    // setTiersName([])
    // setVariableNamesId([])
    // setTiersNameTech([])
    // setVariableNamesIdTech([])
    // setDescriptionId([])
    // setLastTechAtt([])
    setTableShow(false)
    setMydata([])
    setEnableAddDatabtn(true)
    setAddBtn(false)
    // setTaskDescdropselect(false)
    // settechBtnEnable(false)
  }

  function openModal() {
    setIsOpen(true)
  }

  function closeModal() {
    setIsOpen(false)
  }

  // Show All project by on employee dropdown API
  
  const showAllProject = async (companyId, userId) => {
    var response
    try {
      response = await getProjectforTaskDescribe(companyId, userId)
    

      if (response) {
        console.log('S', response)
        const data = response.data.map((x) => {
          return {
            value: x.projectId._id,
            label: x.projectId.projectName,
            projectId: x.projectId._id,
          }
        })
        setProjectDrop(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  // Functional Attribute dropdown API
  const showFunctionalAttribute = async (id) => {
    setProjectAttrName([])
    // const token = await localStorage.getItem('USERTOKEN')
    // axios
    //   .get(`${URL}/attributes/${id}`, {
    //     headers: {
    //       'Content-Type': 'application/json',
    //       Authorization: token,
    //     },
    //   })
    var response
    try {
      response = await showFuncAttrAPI(state.companyId, id)
      if (response) {
        if (response.success) {
          if (response.data) {
            const data = response.data.map((x, i) => {
              return {
                value: x._id,
                label: x.attributeName,
                tiers: x.tiers,
                tiersValue: x.tiers.value,
              }
            })
            setProjectAttrName(data)
            // console.log(data, 'aaaa')
          }
          // toast.success(response.message)
        } else {
          toast.error(response.error)
        }
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }
  // Function Varibale 1st dropdown
  const FunctiongetFirstDropdown = async (companyId, projectId, attributeId, tierId) => {
    setVariableNamesId([])
    setVariableNames([])
    setTiersDropdown([])
    try {
      const response = await getFirstVariableParentDropdownAPI(
        companyId,
        projectId,
        attributeId,
        tierId,
      )
      if (response) {
        // console.log(response, 'dfirst')
        if (response.success) {
          // toast.success(response?.data.message)
          const data = response.variables.map((x) => {
            return {
              value: x._id,
              label: x.variableName,
            }
          })
          const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
          setTiersDropdown([
            ...filtrDatas,
            {
              tierId: tierId,
              dropdown: data,
            },
          ])
        } else {
          toast.error(response?.data.error)
        }
      }
    } catch (e) {
      console.log(e)
    }
  }
  // Function Varibale 2nd dropdown
  const FunctionParentDropdown = async (
    companyId,
    projectId,
    attributeId,
    tierId,
    parentTierId,
    parentVariableId,
  ) => {
    const alreadyfiltrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
    setTiersDropdown(alreadyfiltrDatas)
    try {
      const response = await getVariableParentDropdownAPI(
        companyId,
        projectId,
        attributeId,
        tierId,
        parentTierId,
        parentVariableId,
      )
      if (response) {
        if (response.success) {
          // toast.success(response?.data.message)
          const data = response.variables.map((x) => {
            return {
              value: x._id,
              label: x.variableName,
            }
          })
          const filtrDatas = tiersDropdown.filter((x) => x.tierId !== tierId)
          setTiersDropdown([
            ...filtrDatas,
            {
              tierId: tierId,
              dropdown: data,
            },
          ])
        } else {
          toast.error(response?.data.error)
        }
      }
    } catch (e) {
      console.log(e)
    }
  }

  const showTechnicalAttribute = async (employeeId) => {
    setProjectAttrNameTech([])
    var response
    try {
      response = await TechnicalVariableDropAPI(employeeId)
      // alert()
      if (response.success) {
        console.log('sfjkljsfdkfjksfd', response)
        const data = response.data.map((x, i) => {
          return {
            value: x.technicalAttributeId._id,
            label: x.technicalAttributeId.attributeName,
            // label: `${x.technicalAttributeId === null} `
            //   ? '-'
            //   : `${x.technicalAttributeId.attributeName}`,
            tiers: x.technicalAttributeId.tiers,
            tiersValue: x.technicalAttributeId.tiers.value,
            techattributeId: x.technicalAttributeId._id,
          }
        })
        setProjectAttrNameTech(data)
      }
    } catch (e) {
      console.log(e)
    }
  }

  const TechnicalFirstDropdown = async (attributeIdTech, tierIdTech) => {
    const token = localStorage.getItem('USERTOKEN')
    setVariableNamesIdTech([])
    setVariableNamesTech([])
    setTiersDropdownTech([])
    await axios({
      method: 'Get',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
      url: `${URL}/variables/technical/firstparent/${attributeIdTech}/${tierIdTech}`,
    }).then((response) => {
      if (response) {
        console.log(response, 'dfirst')
        if (response.data.success) {
          // toast.success(response?.data.message)

          if (response.data.variables) {
            const data = response.data.variables.map((x, i) => {
              return {
                value: x._id,
                label: x?.variableName,
              }
            })
            const filtrDatasTech = tiersDropdownTech.filter((x) => x.tierIdTech !== tierIdTech)
            setTiersDropdownTech([
              ...filtrDatasTech,
              {
                tierIdTech: tierIdTech,
                dropdown: data,
              },
            ])
          }
        } else {
          toast.error(response?.data.error)
        }
      }
    })
  }

  const TechnicalgetParentDropdown = async (
    attributeIdTech,
    tierIdTech,
    parentTierId,
    parentVariableId,
    indexValue,
    technicalLength
  ) => {

    let body;
    
    console.log(indexValue,"technical selected values length");
    console.log(technicalLength - 1,"technical selected values length");
    
    const lastElement = variableNamesId[variableNamesId.length - 1]
    const lastVariableId = lastElement.variableId

    if(indexValue === technicalLength - 1){

    body = {
     
      lastFunctionalVariableId: lastVariableId,
      taskDescriptionId: descriptionId.value,
      activityWorkId: plannedActivityWorkId.value,
    }

    }
    
    // const FunctionVariable =
    //   variableNamesId &&
    //   variableNamesId.map((x) => {
    //     return {
    //       variableId: x.value,
    //     }
    //   })

    const alreadyTTfiltrDatasTech = tiersDropdownTech.filter((x) => x.tierIdTech !== tierIdTech)

    setTiersDropdownTech(alreadyTTfiltrDatasTech)
    var response
    try {
      response = await technicalattributePostAPINew(
        body,
        attributeIdTech,
        tierIdTech,
        parentTierId,
        parentVariableId,
      )
      if (response) {
        console.log('fdgfdgfdg', response)
        const data = response.variables.map((x) => {
          return {
            value: x._id,
            label: x.variableName,
          }
        })
        const filtrDatasTech = tiersDropdownTech.filter((x) => x.tierIdTech !== tierIdTech)
        setTiersDropdownTech([
          ...filtrDatasTech,
          {
            tierIdTech: tierIdTech,
            dropdown: data,
          },
        ])
      } else {
        toast.error(response?.error)
      }
      // }
      // })
    } catch (e) {
      console.log(e)
      toast.error(response?.error)
    }
  }

  const showTaskDescriptionDrop = async (projectId) => {
    setDescription([])

    const projectIdData = projectId

    // console.log('asdlkjklasd', projectIdData)
    const FunctionTirData = tiersDropdown.map((x) => {
      return {
        tierId: x.tierId,
      }
    })
    // const TechTirData = tiersDropdownTech.map((x) => {
    //   return {
    //     tierId: x.tierIdTech,
    //   }
    // })

    const FunctionVariable = variableNamesId.map((x) => {
      return {
        variableId: x.value,
      }
    })

    // const TechVariable = variableNamesIdTech.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })
    const data = {
      functionalAttributeId: attributeId.value,
      // technicalAttributeId: attributeIdTech.value,
      functionalTierDetails: FunctionTirData,
      functionalVariableDetails: [...FunctionVariable],
      // technicalTierDetails: TechTirData,
      // technicalVariableDetails: [...TechVariable, ...Technical_Variable],
    }
    const response = await descriptiondashboard(data, state?.employeeId?._id, projectIdData)
    if (response) {
      if (response.success) {
        console.log(response, 'jaiko')
        const data = response.data.map((x) => {
          var d = document.createElement('div')
          d.innerHTML = x?.taskDescription

          return {
            value: x._id,
            label: d.innerText,
            HTMLValue: x?.taskDescription,
          }
        })
        setDescription(data)
      } else {
        setDescription([])
        toast.error(response.error)
      }
    }
  }

  const columns = [
    {
      key: 'S_no',
      label: 'S.No',
      _style: { width: '5%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
    {
      key: 'allProject',
      label: 'Project',
      _style: { width: '10%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'functionAttributes',
      label: 'Functional Variable',
      _style: { width: '18%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'ActionName',
      label: 'Functional Requirement',
      _style: { width: '20%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'technicalAttributes',
      label: 'Technical Variable',
      _style: { width: '18%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },

    {
      key: 'Duration',
      label: 'Days',
      _style: { width: '7%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },

    {
      key: 'ESD',
      label: 'Est Start Date',
      _style: { width: '8%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'EED',
      label: 'Est End Date',
      _style: { width: '8%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: true,
      sorter: true,
    },
    {
      key: 'AssignBy',
      label: 'Assigned by',
      _style: { width: '15%', background: '#002663' },
      _props: { color: '#fff', className: 'fw-semibold' },
      filter: false,
      sorter: false,
    },
  ]
  const saveTaskDescriptionSave = async (e) => {
    e.preventDefault()

    const FunctionTirData = tiersDropdown.map((x) => {
      return {
        tierId: x.tierId,
      }
    })
    const TechTirData = tiersDropdownTech.map((x) => {
      return {
        tierId: x.tierIdTech,
      }
    })

    const FunctionVariable = variableNamesId.map((x) => {
      return {
        variableId: x.value,
      }
    })

    const TechVariable = variableNamesIdTech.map((x) => {
      return {
        variableId: x.value,
      }
    })

    const data = {
      
      companyId: state.companyId,
      employeeId: state?.employeeId?._id,
      projectId: projectId.value,
      functionalAttributeId: attributeId.value,
      functionalTierDetails: FunctionTirData,
      functionalVariableDetails: FunctionVariable,
      taskDescription: taskDescription,

    }
   
    var response
    try {
      
      response = await TaskDescriptionSave(data)
      if (response && response.success === true) {
        toast.success(response.message)
        setTaskDescription('')
        // setDesError('')
        // showTaskDescription(state.employeeId, projectId.value)
        showTaskDescriptionDrop(projectId.value)
      } else {
        toast.error(response.error)
      }
    } catch (err) {
      if (err.response) {
        if (err.response.data && err.response.data.success == false) {
          toast.error(err.response.data.error)
        }
      } else if (err.request) {
        toast.error('No Internet')
      } else {
        toast.error('Something Went Wrong' + err)
      }
    }
  }


  const savePlanning = async (e) => {
    console.log(scheduleResponse, 'SSOSAOJSA')
    const token = await localStorage.getItem(USERTOKEN)

    // const FunctionTirData = tiersDropdown.map((x) => {
    //   return {
    //     tierId: x.tierId,
    //   }
    // })
    // const FunctionVariable = variableNamesId.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })

    // const TechTirData = tiersDropdownTech.map((x) => {
    //   return {
    //     tierId: x.tierIdTech,
    //   }
    // })
    // const TechVariable = variableNamesIdTech.map((x) => {
    //   return {
    //     variableId: x.value,
    //   }
    // })

    // const data =  {
    //         employeeId: state.employeeId,
    //         projectId: projectId.value,

    //         functionalAttributeId: attributeId.value,

    //         functionalTierDetails: FunctionTirData,
    //         functionalVariableDetails: variableNamesId,

    //         technicalAttributeId: attributeIdTech.value,

    //         technicalTierDetails: TechTirData,
    //         technicalVariableDetails: variableNamesIdTech,

    //         taskDescription: taskDescription,

    //         duration,
    //         delay: 0,
    //         esd,
    //         efd,
    //       },

    await axios
      .post(
        `${URL}/employee/planning/task/create`,
        {
          data: scheduleResponse,
        },
        // {
        //   data: scheduleResponse.map((x) => ({
        //     ...x,
        //     S_no: undefined,
        //   })),
        // },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: token,
          },
        },
      )
      .then((res) => {
        const response = res.data
        console.log(response, 'AAA')
        if (response && response.success === true) {
          toast.success(response.message)
          setProjectId('')
          setattributeId('')
          setAttributeIdTech('')
          setTaskDescription('')
          setTiersName([])
          setVariableNamesId([])
          setTiersNameTech([])
          setVariableNamesIdTech([])
          setMydata([])
          handleCancel()
          setTableShow(false)
        } else {
          toast.error(response.error)
        }
      })
      .catch((err) => {
        if (err.response) {
          if (err.response.data && err.response.data.success == false) {
            toast.error(err.response.data.error)
          }
        } else if (err.request) {
          toast.error('No Internet')
        } else {
          toast.error('Something Went Wrong' + err)
        }
      })
  }

  const onChangeCheckbox = async (e) => {
    settechBtnEnableActivity(e)
    if (e === true) {
      setEnableAddDatabtn(true)
    } else {
      setAttributeIdTech('')
      setTiersNameTech([])
      setVariableNamesIdTech([])
      setTiersDropdownTech([])
      setEnableAddDatabtn(false)
    }
  }

  return (
    <div>
      <div>
        <CForm>
          <CRow>
            <CCol xs={12}>
              <div className="panel-heading">
                <div className="col-xs-6">
                  <h3 className="font_Title">Self Planning and Scheduling </h3>
                </div>
              </div>
              <CCard className="mb-6">
                <CCardBody>
                  <CForm>
                    <CRow className="mb-3">
                      <CRow className="col-sm-3">
                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                          Select Project <code>*</code>
                        </CFormLabel>
                        {/* {JSON.stringify(projectId)} */}
                        <CCol sm={12}>
                          <Select
                            className={'inputfieldso'}
                            options={projectDrop}
                            value={projectId}
                            onChange={(e) => {
                              setProjectId(e)
                              setTableShow(false)
                              showFunctionalAttribute(e.value)
                              setEnableAddDatabtn(true)
                              setattributeId('')
                              setAttributeIdTech('')
                              setTaskDescription('')
                              setTiersName([])
                              setVariableNamesId([])
                              setTiersNameTech([])
                              setVariableNamesIdTech([])
                            }}
                            placeholder="Select Project"
                          />
                          <span
                            style={{
                              fontWeight: '500',
                              fontSize: '12px',
                              color: 'red',
                            }}
                          >
                            {projectError}
                          </span>
                        </CCol>
                      </CRow>
                      <CRow className="col-sm-3">
                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                          Select Functional Variable <code>*</code>
                        </CFormLabel>
                        <CCol sm={12}>
                          <Select
                            options={projectAttrName}
                            className="inputfieldso"
                            value={attributeId}
                            // isDisabled={!projectId}
                            onChange={(e) => {
                              setattributeId(e)
                              setEnableAddDatabtn(true)
                              setTiersName(
                                e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers,
                              )
                              if (
                                (e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers)
                                  .length > 0
                              ) {
                                FunctiongetFirstDropdown(
                                  state.companyId,
                                  projectId.value,
                                  e.value,
                                  e.tiers[0]._id,
                                )
                              }
                            }}
                            placeholder="Select Variable"
                          />
                        </CCol>
                      </CRow>
                    </CRow>

                    <CRow className="mb-3">
                      {tiersName.map((x, i) => (
                        <CRow className="col-sm-3" key={i}>
                          <CFormLabel
                            className="col-sm-12 col-form-label donlabel text-align-left"
                            key={i}
                          >
                            {x.value} <code>*</code>
                          </CFormLabel>
                          <CCol sm={12}>
                            <CForm>
                              <Select
                                placeholder={`Select ${x.value}`}
                                options={
                                  tiersDropdown.find((tier) => tier.tierId === x._id)?.dropdown
                                    ? tiersDropdown.find((tier) => tier.tierId === x._id)?.dropdown
                                    : []
                                }
                                value={
                                  variableNamesId.filter((varName) => varName.index === i)?.length >
                                  0
                                    ? variableNamesId.find((varName) => varName.index === i)
                                    : null
                                }
                                className="inputfieldso "
                                onChange={(e) => {
                                  const filterData = variableNamesId.filter(
                                    (n) => n.index !== i && !(n.index > i),
                                  )
                                  setVariableNamesId([
                                    ...filterData,
                                    {
                                      ...e,
                                      index: i,
                                      tierId: x._id,
                                      variableId: e.value,
                                    },
                                  ])
                                  if (tiersName.length === i + 1) {
                                    showTaskDescriptionDrop(
                                      projectId.value,
                                      [
                                        {
                                          variableId: e.value,
                                        },
                                      ],
                                      // TechVariable,
                                    )
                                    setTaskDescdropselect(true)
                                    setEnableAddDatabtn(true)
                                    setDescriptionId('')
                                    setPlannedActivityWorkId('')
                                    settechBtnEnableActivity(false)
                                  } else {
                                    FunctionParentDropdown(
                                      state.companyId,
                                      projectId.value,
                                      attributeId.value,
                                      tiersName[i + 1]._id,
                                      x._id,
                                      e.value,
                                    )
                                    setTaskDescdropselect(false)
                                    setEnableAddDatabtn(true)
                                    setDescriptionId('')
                                    setPlannedActivityWorkId('')
                                    settechBtnEnableActivity(false)
                                  }
                                }}
                              />
                            </CForm>
                          </CCol>
                        </CRow>
                      ))}
                    </CRow>

                    {TaskDescdropselect && (
                      <>
                        <CRow className="mb-3">
                          <CRow className="col-sm-11">
                            {addBtn ? ( <>
                                <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                                Create Functional Requirement <code>*</code>
                                </CFormLabel>
                              <CCol sm={6}>
                              <CFormTextarea
                                   type="text"
                                   value={taskDescription}
                                  className="inputfieldgo textarea"
                                  onChange={(e) => {
                                    setTaskDescription(e.target.value)
                                   
                                  }}
                                  placeholder="Create Functional Requirement"
                                  />
                                                          
                              </CCol>
                              <CCol className='d-flex flex-row justify-content-start align-items-end'>
                              <button
                                    className="save mright"
                                    
                                    onClick={(e) => {
                                      if (taskDescription.trim() !== '') {
                                        setAddBtn(false);
                                        saveTaskDescriptionSave(e);
                                        
                                      }
                                    }}
                                    disabled={taskDescription.trim() === ''}
                                  >
                                    Create
                                  </button>
                                           <button
                                            className="reset "
                                            onClick={() => {
                                              setAddBtn(false)
                                              // setDescription([])
                                              setDescriptionId('')      
                                              }}
                                                    >
                                              Cancel
                                            </button>
                                  </CCol>

                            </>
                              ) 
                              :
                               (<>
                                <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                                  Functional Requirement <code>*</code>                            
                                </CFormLabel>
                                {/* {JSON.stringify(descriptionId)} */}
                                  <CCol sm={6}>
                                    <Select
                                      className={'inputfieldso'}
                                    
                                      options={description}
                                      value={descriptionId}
                                      onChange={(e) => {
                                        setDescriptionId(e)
                                        setAttributeIdTech('')
                                        setTiersNameTech([])
                                        setVariableNamesIdTech([])
                                        setTiersDropdownTech([])
                                        settechBtnEnable(true)
                                        setEnableAddDatabtn(false)
                                        showActivityWork()
                                        showTechnicalAttribute(state.employeeId._id)
                                        // settechBtnEnableActivity(true)
                                        // settechBtnEnable(true)
                                      }}
                                      placeholder="Select Description"
                                    />
                                  
                                  </CCol>
                                  <CCol>
                                 {/* 01 */}
                                  <BsFillPlusCircleFill
                                              
                                              onClick={(e) => {
                                                setAddBtn(true)
                                                settechBtnEnable(false)
                                                settechBtnEnableActivity(false)
                                                setTaskDescription('')
                                              }} 

                                              style={{
                                               width: '25px',
                                               height: '25px',
                                               display: 'inline',
                                               marginTop: '7px',
                                               cursor: 'pointer',
                                              }}

                                  /> 
                                  
                                  </CCol>

                               </> )}

                                  
                            
                          </CRow>
                        </CRow>

                       
                        {techBtnEnable && (
                          <>
                            <CRow className="mb-3">
                              <CRow className="col-sm-3">
                                <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                                  Select Technical Variable <code>*</code>
                                </CFormLabel>
                                <CCol sm={12}>

                                {/* {console.log(attributeIdTech?.tiers?.length,"Technical tiers")} */}
                                
                                  <Select
                                    options={projectAttrNameTech}
                                    className="inputfieldso"
                                    value={attributeIdTech}
                                    onChange={(e) => {
                                      setAttributeIdTech(e)
                                      setPlannedActivityWorkId('')
                                      setTiersNameTech([])
                                      setVariableNamesIdTech([])
                                      settechBtnEnable(true)
                                      settechBtnEnableActivity(true)
                                      setTiersNameTech(
                                        e?.tiers === undefined || e?.tiers === null ? [] : e?.tiers,
                                      )
                                      if (
                                        (e?.tiers === undefined || e?.tiers === null
                                          ? []
                                          : e?.tiers
                                        ).length > 0
                                      ) {
                                        TechnicalFirstDropdown(e.value, e.tiers[0]._id)
                                      }
                                    }}
                                    placeholder="Select variable "
                                  />
                                </CCol>
                              </CRow>
                            </CRow>

                            <CRow className="mb-3">

                             {techBtnEnableActivity && (
                                  <>
                                    <>
                                      <CRow className="col-sm-3">
                                        <CFormLabel className="col-sm-12 col-form-label donlabel text-align-left">
                                          Select Category of Activity <code>*</code>
                                        </CFormLabel>
                                        <CCol sm={12}>
                                          <Select
                                            options={plannedActivityWork}
                                            className="inputfieldso"
                                            value={plannedActivityWorkId}
                                            onChange={(e) => {
                                              setPlannedActivityWorkId(e)
                                              settechBtnEnable(true)
                                              setVariableNamesIdTech([])
                                              // showTechnicalAttribute(state.employeeId)
                                            }}
                                            isDisabled={!projectId || !attributeId || !attributeIdTech}
                                            placeholder="Select variable"
                                          />
                                        </CCol>
                                      </CRow>
                                    </>
                                  </>
                              )}
                              {/* {JSON.stringify(myData)} */}
                              {tiersNameTech &&
                                tiersNameTech.map((x, i) => (
                                  <CRow className="col-sm-3" key={i}>
                                    <CFormLabel
                                      className="col-sm-12 col-form-label donlabel text-align-left"
                                      key={i}
                                    >
                                      {x.value} <code>*</code>
                                    </CFormLabel>
                                    
                                    {/* Tiers DropDown Starts */}
                                    <CCol sm={12}>
                                      <CForm>
                                        {i == tiersNameTech.length - 1 ? (
                                          <>
                                            {/* {
                                              JSON.stringify(lastTechAtt)
                                            }
                                            <hr />
                                                {JSON.stringify(tiersDropdownTech)} */}
                                            <Select
                                                placeholder={`Select ${x.value}`}
                                              className={'inputfieldso'}
                                              value={lastTechAtt.length > 0 ? lastTechAtt[0] : null}
                                              options={
                                                (tiersDropdownTech?.find(
                                                (tier) => tier.tierIdTech === x._id,
                                              )?.dropdown
                                                ? tiersDropdownTech?.find(
                                                    (tier) => tier.tierIdTech === x._id,
                                                  )?.dropdown
                                                : []
                                              ).filter(
                                                (x) =>
                                                  myData.filter(
                                                    (data) =>
                                                      data?.singleTechVariableId === x.value 
                                                      && data?.taskDescriptionId === descriptionId?.value,
                                                  ).length === 0,
                                              )}
                                              displayValue="key"
                                              onChange={(e) => {
                                                console.log('MULTI12312', e)
                                                setLastTechAtt([e])
                                                setEnableAddDatabtn(false)
                                              }}
                                            />
                                          </>
                                        ) : (
                                          <Select
                                            placeholder={`${x.value}`}
                                            options={
                                              tiersDropdownTech.find(
                                                (tier) => tier.tierIdTech === x._id,
                                              )?.dropdown
                                                ? tiersDropdownTech.find(
                                                    (tier) => tier.tierIdTech === x._id,
                                                  )?.dropdown
                                                : []
                                            }
                                            value={
                                              variableNamesIdTech.filter(
                                                (varName) => varName.index === i,
                                              )?.length > 0
                                                ? variableNamesIdTech.find(
                                                    (varName) => varName.index === i,
                                                  )
                                                : null
                                            }
                                            className="inputfieldso"
                                            onChange={(e) => {
                                              const filterData = variableNamesIdTech.filter(
                                                (n) => n.index !== i && !(n.index > i),
                                              )
                                              setLastTechAtt([])
                                              setEnableAddDatabtn(true)
                                              setVariableNamesIdTech([
                                                ...filterData,
                                                {
                                                  ...e,
                                                  index: i,
                                                  tierIdTech: x._id,
                                                  variableId: e.value,
                                                },
                                              ])
                                              if (tiersNameTech.length === i + 1) {
                                              } else {
                                                TechnicalgetParentDropdown(
                                                  attributeIdTech.value,
                                                  tiersNameTech[i + 1]._id,
                                                  x._id,
                                                  e.value,
                                                  i + 1,
                                                  attributeIdTech?.tiers?.length
                                                )
                                              }
                                            }}
                                          />
                                        )}
                                      </CForm>
                                    </CCol>
                                  </CRow>
                                ))}
                            </CRow>
                          </>
                        )}
                        

                      </>
                    )}

                    <CRow>
                      <CCol className="d-flex flex-row justify-content-end">
                        <button
                          disabled={EnableAddDatabtn}
                          className="loginBtn1 mright"
                          onClick={(e) => {
                            e.preventDefault()
                            setTableShow(true)
                            // setVariableNamesIdTech([])
                            // setPlannedActivityWorkId('')
                            showTable(descriptionId.HTMLValue, descriptionId.value)
                          }}
                        >
                          Add
                        </button>
                        <button
                          className="clear"
                          onClick={(e) => {
                            e.preventDefault()
                            handleCancel()
                          }}
                        >
                          Clear 
                        </button>
                      </CCol>
                    </CRow>
                  </CForm>
                </CCardBody>
              </CCard>
              <br />
              {tableShow && (
                <div className="filterContainer filterContainer_New">
                  {/* <br />
                    <div className="ItemsPerPageMappage">
                      <span className="pageid">No of Rows</span> &nbsp;
                      <TableDropdown
                        onChange={(value) => {
                          setItemsPerPage(value)
                        }}
                      />
                    </div> */}
                  {/* <div className="TableDownloadmapPage">
                      <button onClick={openModal} className="pdfbtns">
                        <ImFilePdf /> PDF
                      </button>
                    </div> */}

                  <CSmartTable
                    activePage={1}
                    clickableRows
                    columns={columns}
                    columnFilter
                    columnSorter
                    items={myData}
                    itemsPerPageSelect
                    itemsPerPageLabel={'No of Rows'}
                    itemsPerPage={5}
                    pagination
                    scopedColumns={{
                      Duration: (item) => {
                        return (
                          <td className="gaponly">
                            <CFormInput
                              type="number"
                              placeholder="Days"
                              className="inputfieldgo"
                              value={
                                scheduleResponse.filter((x) => x.DummyId == item.DummyId).length > 0
                                  ? scheduleResponse.find((x) => x.DummyId == item.DummyId).duration
                                  : ''
                              }
                              onChange={(e) => {
                                ScheduleHandler(
                                  item,
                                  e.target.value,
                                  '',
                                  '',
                                  // scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                  //   .length > 0
                                  //   ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                  //   : '',
                                  // scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                  //   .length > 0
                                  //   ? scheduleResponse.find((x) => x.DummyId == item.DummyId).efd
                                  //   : '',
                                )
                              }}
                            />
                          </td>
                        )
                      },
                      ESD: (item) => {
                        return (
                          <td>
                            <CFormInput
                              type="Date"
                              min={moment().format('YYYY-MM-DD')}
                              // max="9999-01-01"
                              className="inputfieldgo"
                              value={
                                scheduleResponse.filter((x) => x.DummyId == item.DummyId).length > 0
                                  ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                  : ''
                              }
                              onChange={(e) => {
                                // setEsd(e.target.value).utc().toISOString()
                                // .toISOString()
                                // const date = e.target.value
                                // now.toUTCsString()

                                ScheduleHandler(
                                  item,
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                    0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                        .duration
                                    : '',
                                  e.target.value,
                                  // scheduleResponse.filter((x) => x.DummyId == item.DummyId)
                                  //   .length > 0
                                  //   ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                  //       ?.duration
                                  //     ? moment(moment(e.target.value).format('YYYY-MM-DD'))
                                  //         .add(
                                  //           Number(
                                  //             scheduleResponse.find(
                                  //               (x) => x.DummyId == item.DummyId,
                                  //             )?.duration,
                                  //           ) - 1,
                                  //           'days',
                                  //         )
                                  //         .format('YYYY-MM-DD')
                                  //     : ''
                                  //   : '',
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                    0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                        ?.duration
                                      ? moment(
                                          moment(
                                            momentBusinessDays(e.target.value).businessAdd(
                                              scheduleResponse.find(
                                                (x) => x.DummyId == item.DummyId,
                                              )?.duration,
                                            )._d,
                                          )
                                            .add(-1, 'days')
                                            .format('YYYY-MM-DD'),
                                        ).format('dddd') === 'Sunday'
                                        ? moment(
                                            momentBusinessDays(e.target.value).businessAdd(
                                              scheduleResponse.find(
                                                (x) => x.DummyId == item.DummyId,
                                              )?.duration,
                                            )._d,
                                          )
                                            .add(-2, 'days')
                                            .format('YYYY-MM-DD')
                                        : moment(
                                            momentBusinessDays(e.target.value).businessAdd(
                                              scheduleResponse.find(
                                                (x) => x.DummyId == item.DummyId,
                                              )?.duration,
                                            )._d,
                                          )
                                            .add(-1, 'days')
                                            .format('YYYY-MM-DD')
                                      : ''
                                    : '',
                                )
                                setSchedulebtn(true)
                              }}
                            />
                          </td>
                        )
                      },
                      EED: (item) => {
                        return (
                          <td>
                            <CFormInput
                              type="Date"
                              min={moment().format('YYYY-MM-DD')}
                              // max="9999-01-01"
                              className="inputfieldgo date"
                              value={
                                scheduleResponse.filter((x) => x.DummyId == item.DummyId).length > 0
                                  ? scheduleResponse.find((x) => x.DummyId == item.DummyId).efd
                                  : ''
                              }
                              onChange={(e) => {
                                // setEfd(e.target.value)
                                ScheduleHandler(
                                  item,
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                    0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId)
                                        .duration
                                    : '',
                                  scheduleResponse.filter((x) => x.DummyId == item.DummyId).length >
                                    0
                                    ? scheduleResponse.find((x) => x.DummyId == item.DummyId).esd
                                    : '',
                                  e.target.value,
                                )
                              }}
                              disabled={!efd}
                            />
                          </td>
                        )
                      },
                    }}
                    sorterValue={{ column: 'name', state: 'asc' }}
                    // tableFilter
                    // tableHeadProps={{
                    //   color: 'danger',
                    // }}
                    tableProps={{
                      striped: true,
                      hover: true,
                    }}
                  />
                  <br />
                  <div className="d-flex flex-row justify-content-end">
                    {schedulebtn && (
                      <div>
                        <button
                          className="loginBtn1 mright"
                          type="submit"
                          onClick={(e) => {
                            e.preventDefault()
                            savePlanning(e)
                          }}
                        >
                          Schedule
                        </button>
                      </div>
                    )}

                    <div>
                      <button
                        style={{ marginRight: '15px' }}
                        className="clear"
                        onClick={(e) => {
                          e.preventDefault()
                          handleOverallCancel()
                          setTableShow(false)
                        }}
                      >
                        clear
                      </button>
                    </div>
                  </div>
                  <br />
                </div>
              )}
            </CCol>
          </CRow>
        </CForm>
      </div>
    </div>
  )
}